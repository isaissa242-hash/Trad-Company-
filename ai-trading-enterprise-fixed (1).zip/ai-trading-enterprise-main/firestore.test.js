const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_owner_01";
const BOB_UID = "bob_other_02";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write any corporate data", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("agents").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("company_state").doc("config").set({
      userId: ALICE_UID,
      killSwitchActive: false,
    })
  );
});

test("Owner can create and update CompanyConfig; cross-user and ghost-field writes fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 2000);

  const configRef = aliceDb.collection("users").doc(ALICE_UID).collection("company_state").doc("config");
  await assertSucceeds(
    configRef.set({
      userId: ALICE_UID,
      killSwitchActive: false,
      tradingPaused: false,
      tradingMode: "PAPER",
      liveTradingApprovedByOwner: false,
      allocatedCapital: 100000,
      maxRiskPerTradePct: 1.5,
      dailyLossLimitPct: 3.0,
      weeklyLossLimitPct: 7.0,
      maxOpenPositions: 5,
      maxLeverage: 3.0,
      paperBalance: 100000,
      safetyVaultBalance: 0,
      safetyVaultTotalDeposited: 0,
      safetyVaultAllocationPct: 10.0,
      profitTargetUsd: 0,
      profitTargetBaselinePnl: 0,
      sniperEnabled: true,
      cloudEngineEnabled: false,
      executionLocation: "LOCAL",
      cloudEngineStatus: "STANDBY",
      cloudLastHeartbeatMillis: 0,
      cloudLastSummary: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Partial update: activate Kill Switch + auto-deposit 10% profit to Safety Vault + toggle Sniper + set Profit Target
  await assertSucceeds(
    configRef.update({
      killSwitchActive: true,
      sniperEnabled: false,
      safetyVaultBalance: 100.0,
      safetyVaultTotalDeposited: 100.0,
      profitTargetUsd: 2999.0,
      profitTargetBaselinePnl: 12.45,
      cloudEngineEnabled: true,
      executionLocation: "CLOUD_24_7",
      cloudEngineStatus: "RUNNING",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Invalid non-bool sniperEnabled must fail
  await assertFails(
    configRef.update({
      sniperEnabled: "YES",
      updatedAt: new Date(Date.now() - 950),
    })
  );

  // Negative Safety Vault balance must fail
  await assertFails(
    configRef.update({
      safetyVaultBalance: -10.0,
      updatedAt: new Date(Date.now() - 900),
    })
  );

  // Invalid executionLocation must fail
  await assertFails(
    configRef.update({
      executionLocation: "INVALID_CLUSTER",
      updatedAt: new Date(Date.now() - 800),
    })
  );

  // Shadow update with ghost field must fail
  await assertFails(
    configRef.update({
      killSwitchActive: false,
      adminOverride: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Future timestamp must fail
  await assertFails(
    configRef.update({
      killSwitchActive: false,
      updatedAt: new Date(Date.now() + 120000),
    })
  );

  // Cross-user read/write must fail
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("company_state").doc("config").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("company_state").doc("config").update({
      killSwitchActive: false,
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Agents, Tasks, Messages, Strategies, Trades, LearningLogs, and AuditLogs enforce schema & ownership", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = new Date(Date.now() - 5000);

  // Agent create & update
  const agentRef = aliceDb.collection("users").doc(ALICE_UID).collection("agents").doc("ceo_01");
  await assertSucceeds(
    agentRef.set({
      userId: ALICE_UID,
      name: "Apex CEO",
      nameAr: "الرئيس التنفيذي",
      role: "Chief Executive Officer",
      roleAr: "الرئيس التنفيذي",
      department: "EXECUTIVE",
      managerId: "OWNER",
      modelId: "gemini-3.8-flash",
      status: "Waiting",
      currentTask: "Standing by for Owner command",
      tasksCompleted: 0,
      successRate: 100.0,
      performanceScore: 95.0,
      confidenceScore: 90.0,
      blockedByOwner: false,
      approvedByOwner: true,
      candidatePending: false,
      backtestPassRate: 100.0,
      specialization: "Executive planning & delegation",
      rankLevel: 1,
      rankXp: 0,
      successfulWinsCount: 0,
      totalProfitGeneratedUsd: 0.0,
      intelligenceScore: 105.0,
      reprimandsCount: 0,
      lastReprimandReason: "",
      candidateExpertise: "",
      candidateCompanyBenefit: "",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    agentRef.update({
      status: "Working",
      currentTask: "Delegating Gold analysis",
      modelId: "gemini-4-argon",
      rankLevel: 2,
      rankXp: 75,
      successfulWinsCount: 1,
      totalProfitGeneratedUsd: 254.38,
      intelligenceScore: 118.5,
      reprimandsCount: 1,
      lastReprimandReason: "تأخير سابق في مراجعة السيولة",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Rank level outside 1..10 or intelligenceScore > 500 must fail
  await assertFails(
    agentRef.update({
      rankLevel: 15,
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(
    agentRef.update({
      intelligenceScore: 999.0,
      updatedAt: new Date(Date.now() - 450),
    })
  );

  // Task create, update, and terminal state lock
  const taskRef = aliceDb.collection("users").doc(ALICE_UID).collection("tasks").doc("task_01");
  await assertSucceeds(
    taskRef.set({
      userId: ALICE_UID,
      ownerOrder: "Analyze Gold market",
      stage: "CEO_PLANNING",
      status: "ACTIVE",
      assignedAgentId: "ceo_01",
      targetAsset: "PAXGUSDT",
      ceoPlan: "Delegate to Market Intelligence",
      unifiedReportSummary: "",
      tradingPlanSummary: "",
      riskVerdict: "",
      outcomeSummary: "",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    taskRef.update({
      stage: "COMPLETED",
      status: "CLOSED",
      outcomeSummary: "Report delivered",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Terminal state lock: updating a CLOSED task must fail
  await assertFails(
    taskRef.update({
      stage: "REOPENED",
      status: "ACTIVE",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Message immutable after creation
  const msgRef = aliceDb.collection("users").doc(ALICE_UID).collection("messages").doc("msg_01");
  await assertSucceeds(
    msgRef.set({
      userId: ALICE_UID,
      taskId: "task_01",
      senderId: "ceo_01",
      senderName: "CEO Agent",
      senderRole: "CEO",
      recipientId: "mid_01",
      channel: "CEO_OWNER",
      content: "Plan initiated",
      evidenceCited: "Live PAXGUSDT feed",
      decisionReached: "Approved research",
      createdAt: ts,
    })
  );
  await assertFails(msgRef.update({ content: "Tampered" }));

  // Strategy create & backtest metrics update
  const stratRef = aliceDb.collection("users").doc(ALICE_UID).collection("strategies").doc("strat_01");
  await assertSucceeds(
    stratRef.set({
      userId: ALICE_UID,
      name: "EMA Liquidity Sweep",
      suitableMarkets: "PAXGUSDT, BTCUSDT",
      entryConditions: "EMA20 > EMA50 & RSI < 65",
      exitConditions: "TP hit or EMA cross down",
      stopLossRule: "1.5x ATR",
      takeProfitRule: "3.0x ATR",
      timeframes: "15m, 1h",
      worksInConditions: "Trending with clear liquidity pools",
      failsInConditions: "Tight choppy ranges",
      backtestReturnPct: 12.4,
      walkForwardReturnPct: 8.2,
      outOfSampleWinRate: 58.0,
      maxDrawdownPct: 6.5,
      profitFactor: 1.75,
      feesAndSlippagePct: 0.15,
      approvedForLive: false,
      paperTradesCount: 0,
      liveTradesCount: 0,
      realizedPnl: 0.0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Trade create, partial close, and terminal lock
  const tradeRef = aliceDb.collection("users").doc(ALICE_UID).collection("trades").doc("trade_01");
  await assertSucceeds(
    tradeRef.set({
      userId: ALICE_UID,
      symbol: "BTCUSDT",
      side: "BUY",
      mode: "PAPER",
      status: "OPEN",
      strategyId: "strat_01",
      strategyName: "EMA Liquidity Sweep",
      traderId: "trd_short_01",
      traderName: "Trader A",
      entryPrice: 92500.0,
      exitPrice: 0.0,
      quantity: 0.1,
      stopLoss: 91000.0,
      takeProfit: 95500.0,
      feesPaid: 9.25,
      slippageCost: 4.62,
      realizedPnl: 0.0,
      rationale: "Liquidity sweep + RSI recovery",
      riskApprovalId: "risk_ok_01",
      brokerOrderId: "PAPER-1001",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    tradeRef.update({
      status: "CLOSED",
      exitPrice: 94000.0,
      realizedPnl: 136.13,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Terminal trade cannot be reopened
  await assertFails(
    tradeRef.update({
      status: "OPEN",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Learning log & Audit log create + list
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("learning_logs").doc("log_01").set({
      userId: ALICE_UID,
      agentId: "ana_tech_01",
      agentName: "Technical Analyst",
      taskId: "task_01",
      tradeId: "trade_01",
      errorType: "INSIGHT",
      decisionSummary: "Identified key demand zone",
      evidenceUsed: "1h Binance OHLCV",
      actualOutcome: "Price bounced +1.6%",
      rootCause: "Valid structure confirmation",
      financialImpact: 136.13,
      correctiveAction: "Keep confluence filter",
      recurred: false,
      knowledgeRuleAdded: "Require volume spike > 1.2x on sweep",
      createdAt: ts,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("audit_logs").doc("aud_01").set({
      userId: ALICE_UID,
      actor: "CRO",
      actionType: "RISK_APPROVAL",
      details: "Approved PAPER trade within 1.5% risk limit",
      severity: "INFO",
      createdAt: ts,
    })
  );

  // List queries succeed for owner, fail for Bob
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("trades").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("trades").get());
});
