package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties

enum class AgentStatus(val label: String, val labelAr: String) {
    WORKING("Working", "يعمل"),
    RESEARCHING("Researching", "يبحث"),
    ANALYZING("Analyzing", "يحلل"),
    TRADING("Trading", "يتداول"),
    REVIEWING("Reviewing", "يراجع"),
    WAITING("Waiting", "بانتظار"),
    COMPLETED("Completed", "مكتمل"),
    ERROR("Error", "خطأ");

    companion object {
        fun fromRaw(raw: String): AgentStatus =
            entries.firstOrNull { it.label.equals(raw, ignoreCase = true) || it.name.equals(raw, ignoreCase = true) }
                ?: WAITING
    }
}

enum class Department(val titleEn: String, val titleAr: String) {
    EXECUTIVE("Executive Suite", "مكتب الرئيس التنفيذي"),
    MARKET_INTEL("Market Intelligence", "إدارة تحليل السوق"),
    LIVE_TRADING("Live Trading", "إدارة التداول المباشر"),
    RISK("Independent Risk", "قسم المخاطر المستقل"),
    HR("AI Human Resources", "الموارد البشرية للوكلاء");

    companion object {
        fun fromRaw(raw: String): Department =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: EXECUTIVE
    }
}

enum class TradingMode(val labelAr: String) {
    PAPER("تجريبي (Paper)"),
    LIVE("حقيقي (Live)")
}

enum class BrokerPlatform(
    val displayName: String,
    val displayNameAr: String,
    val supportsDirectRestApi: Boolean,
    val noteAr: String
) {
    QUANTCORP_PAPER(
        displayName = "QuantCorp Paper Engine",
        displayNameAr = "محرك التداول التجريبي الداخلي",
        supportsDirectRestApi = true,
        noteAr = "محرك تداول تجريبي مرتبط بالأسعار الحية الفعلية مع احتساب العمولات والانزلاق السعري."
    ),
    BINANCE_SPOT(
        displayName = "Binance Spot / Testnet",
        displayNameAr = "منصة Binance (رسمي / اختبار)",
        supportsDirectRestApi = true,
        noteAr = "اتصال مباشر بواجهة Binance REST API الرسمية عبر توقيع HMAC-SHA256 ومفاتيح API محدودة الصلاحية."
    ),
    ALPACA_TRADING(
        displayName = "Alpaca Paper / Live API",
        displayNameAr = "منصة Alpaca للأسهم والعملات",
        supportsDirectRestApi = true,
        noteAr = "اتصال رسمي عبر مفاتيح APCA-API-KEY-ID / SECRET على بيئة Paper أو Live."
    ),
    BYBIT_V5(
        displayName = "Bybit V5 Testnet / Live",
        displayNameAr = "منصة Bybit V5 الرسمية",
        supportsDirectRestApi = true,
        noteAr = "اتصال رسمي بواجهة Bybit V5 REST API بتوقيع HMAC-SHA256."
    ),
    METATRADER_5(
        displayName = "MetaTrader 5 (REST Bridge)",
        displayNameAr = "MetaTrader 5 عبر جسر API",
        supportsDirectRestApi = false,
        noteAr = "تنبيه تقني: لا توفر MT5 واجهة REST سحابية عامة مباشرة لتطبيقات أندرويد دون خادم وسيط (مثل MetaAPI أو Python MT5 Bridge). يمكنك ربط عنوان جسر MT5 الآمن الخاص بك هنا دون محاكاة نقر غير موثوقة."
    )
}

@Keep
@IgnoreExtraProperties
data class CompanyConfig(
    @DocumentId val id: String = "config",
    val userId: String = "",
    val killSwitchActive: Boolean = false,
    val tradingPaused: Boolean = false,
    val tradingMode: String = "PAPER",
    val liveTradingApprovedByOwner: Boolean = false,
    val allocatedCapital: Double = 100_000.0,
    val maxRiskPerTradePct: Double = 1.5,
    val dailyLossLimitPct: Double = 3.0,
    val weeklyLossLimitPct: Double = 7.0,
    val maxOpenPositions: Long = 5L,
    val maxLeverage: Double = 3.0,
    val paperBalance: Double = 100_000.0,
    val safetyVaultBalance: Double = 0.0,
    val safetyVaultTotalDeposited: Double = 0.0,
    val safetyVaultAllocationPct: Double = 10.0,
    val profitTargetUsd: Double = 0.0,
    val profitTargetBaselinePnl: Double = 0.0,
    val sniperEnabled: Boolean = true,
    val cloudEngineEnabled: Boolean = false,
    val executionLocation: String = "LOCAL",
    val cloudEngineStatus: String = "STANDBY",
    val cloudLastHeartbeatMillis: Long = 0L,
    val cloudLastSummary: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "killSwitchActive" to killSwitchActive,
        "tradingPaused" to tradingPaused,
        "tradingMode" to tradingMode,
        "liveTradingApprovedByOwner" to liveTradingApprovedByOwner,
        "allocatedCapital" to allocatedCapital,
        "maxRiskPerTradePct" to maxRiskPerTradePct,
        "dailyLossLimitPct" to dailyLossLimitPct,
        "weeklyLossLimitPct" to weeklyLossLimitPct,
        "maxOpenPositions" to maxOpenPositions,
        "maxLeverage" to maxLeverage,
        "paperBalance" to paperBalance,
        "safetyVaultBalance" to safetyVaultBalance.coerceAtLeast(0.0),
        "safetyVaultTotalDeposited" to safetyVaultTotalDeposited.coerceAtLeast(0.0),
        "safetyVaultAllocationPct" to safetyVaultAllocationPct.coerceIn(0.0, 50.0),
        "profitTargetUsd" to profitTargetUsd.coerceAtLeast(0.0),
        "profitTargetBaselinePnl" to profitTargetBaselinePnl,
        "sniperEnabled" to sniperEnabled,
        "cloudEngineEnabled" to cloudEngineEnabled,
        "executionLocation" to executionLocation,
        "cloudEngineStatus" to cloudEngineStatus,
        "cloudLastHeartbeatMillis" to cloudLastHeartbeatMillis,
        "cloudLastSummary" to cloudLastSummary.take(1000),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class AgentProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val nameAr: String = "",
    val role: String = "",
    val roleAr: String = "",
    val department: String = "EXECUTIVE",
    val managerId: String = "",
    val modelId: String = "gemini-3.8-flash",
    val status: String = "Waiting",
    val currentTask: String = "",
    val tasksCompleted: Long = 0L,
    val successRate: Double = 100.0,
    val performanceScore: Double = 90.0,
    val confidenceScore: Double = 85.0,
    val blockedByOwner: Boolean = false,
    val approvedByOwner: Boolean = true,
    val candidatePending: Boolean = false,
    val backtestPassRate: Double = 100.0,
    val specialization: String = "",
    val rankLevel: Long = 1L,
    val rankXp: Long = 0L,
    val successfulWinsCount: Long = 0L,
    val totalProfitGeneratedUsd: Double = 0.0,
    val intelligenceScore: Double = 100.0,
    val reprimandsCount: Long = 0L,
    val lastReprimandReason: String = "",
    val candidateExpertise: String = "",
    val candidateCompanyBenefit: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "name" to name.take(100),
        "nameAr" to nameAr.take(100),
        "role" to role.take(100),
        "roleAr" to roleAr.take(100),
        "department" to department.take(80),
        "managerId" to managerId.take(100),
        "modelId" to modelId.take(60),
        "status" to status.take(30),
        "currentTask" to currentTask.take(500),
        "tasksCompleted" to tasksCompleted,
        "successRate" to successRate.coerceIn(0.0, 100.0),
        "performanceScore" to performanceScore.coerceIn(0.0, 100.0),
        "confidenceScore" to confidenceScore.coerceIn(0.0, 100.0),
        "blockedByOwner" to blockedByOwner,
        "approvedByOwner" to approvedByOwner,
        "candidatePending" to candidatePending,
        "backtestPassRate" to backtestPassRate.coerceIn(0.0, 100.0),
        "specialization" to specialization.take(400),
        "rankLevel" to rankLevel.coerceIn(1L, 10L),
        "rankXp" to rankXp.coerceAtLeast(0L),
        "successfulWinsCount" to successfulWinsCount.coerceAtLeast(0L),
        "totalProfitGeneratedUsd" to totalProfitGeneratedUsd,
        "intelligenceScore" to intelligenceScore.coerceIn(0.0, 500.0),
        "reprimandsCount" to reprimandsCount.coerceAtLeast(0L),
        "lastReprimandReason" to lastReprimandReason.take(500),
        "candidateExpertise" to candidateExpertise.take(1000),
        "candidateCompanyBenefit" to candidateCompanyBenefit.take(1000),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class CorporateTask(
    @DocumentId val id: String = "",
    val userId: String = "",
    val ownerOrder: String = "",
    val stage: String = "CEO_PLANNING",
    val status: String = "ACTIVE",
    val assignedAgentId: String = "ceo_01",
    val targetAsset: String = "PAXGUSDT",
    val ceoPlan: String = "",
    val unifiedReportSummary: String = "",
    val tradingPlanSummary: String = "",
    val riskVerdict: String = "",
    val outcomeSummary: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "ownerOrder" to ownerOrder.take(2000),
        "stage" to stage.take(80),
        "status" to status.take(40),
        "assignedAgentId" to assignedAgentId.take(100),
        "targetAsset" to targetAsset.take(40),
        "ceoPlan" to ceoPlan.take(4000),
        "unifiedReportSummary" to unifiedReportSummary.take(8000),
        "tradingPlanSummary" to tradingPlanSummary.take(4000),
        "riskVerdict" to riskVerdict.take(2000),
        "outcomeSummary" to outcomeSummary.take(2000),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class CorporateMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val taskId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderRole: String = "",
    val recipientId: String = "",
    val channel: String = "CEO_OWNER",
    val content: String = "",
    val evidenceCited: String = "",
    val decisionReached: String = "",
    val createdAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "taskId" to taskId.take(128),
        "senderId" to senderId.take(100),
        "senderName" to senderName.take(120),
        "senderRole" to senderRole.take(120),
        "recipientId" to recipientId.take(100),
        "channel" to channel.take(40),
        "content" to content.take(12000),
        "evidenceCited" to evidenceCited.take(2000),
        "decisionReached" to decisionReached.take(1000),
        "createdAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class TradingStrategy(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val suitableMarkets: String = "",
    val entryConditions: String = "",
    val exitConditions: String = "",
    val stopLossRule: String = "",
    val takeProfitRule: String = "",
    val timeframes: String = "",
    val worksInConditions: String = "",
    val failsInConditions: String = "",
    val backtestReturnPct: Double = 0.0,
    val walkForwardReturnPct: Double = 0.0,
    val outOfSampleWinRate: Double = 0.0,
    val maxDrawdownPct: Double = 0.0,
    val profitFactor: Double = 0.0,
    val feesAndSlippagePct: Double = 0.15,
    val approvedForLive: Boolean = false,
    val paperTradesCount: Long = 0L,
    val liveTradesCount: Long = 0L,
    val realizedPnl: Double = 0.0,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "name" to name.take(150),
        "suitableMarkets" to suitableMarkets.take(300),
        "entryConditions" to entryConditions.take(1000),
        "exitConditions" to exitConditions.take(1000),
        "stopLossRule" to stopLossRule.take(400),
        "takeProfitRule" to takeProfitRule.take(400),
        "timeframes" to timeframes.take(120),
        "worksInConditions" to worksInConditions.take(500),
        "failsInConditions" to failsInConditions.take(500),
        "backtestReturnPct" to backtestReturnPct,
        "walkForwardReturnPct" to walkForwardReturnPct,
        "outOfSampleWinRate" to outOfSampleWinRate.coerceIn(0.0, 100.0),
        "maxDrawdownPct" to maxDrawdownPct.coerceIn(0.0, 100.0),
        "profitFactor" to profitFactor.coerceAtLeast(0.0),
        "feesAndSlippagePct" to feesAndSlippagePct.coerceAtLeast(0.0),
        "approvedForLive" to approvedForLive,
        "paperTradesCount" to paperTradesCount.coerceAtLeast(0L),
        "liveTradesCount" to liveTradesCount.coerceAtLeast(0L),
        "realizedPnl" to realizedPnl,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class TradeRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val symbol: String = "",
    val side: String = "BUY",
    val mode: String = "PAPER",
    val status: String = "OPEN",
    val strategyId: String = "",
    val strategyName: String = "",
    val traderId: String = "",
    val traderName: String = "",
    val entryPrice: Double = 0.0,
    val exitPrice: Double = 0.0,
    val quantity: Double = 0.0,
    val stopLoss: Double = 0.0,
    val takeProfit: Double = 0.0,
    val feesPaid: Double = 0.0,
    val slippageCost: Double = 0.0,
    val realizedPnl: Double = 0.0,
    val rationale: String = "",
    val riskApprovalId: String = "",
    val brokerOrderId: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "symbol" to symbol.take(30),
        "side" to if (side == "SELL") "SELL" else "BUY",
        "mode" to if (mode == "LIVE") "LIVE" else "PAPER",
        "status" to if (status in listOf("OPEN", "CLOSED", "REJECTED")) status else "OPEN",
        "strategyId" to strategyId.take(128),
        "strategyName" to strategyName.take(150),
        "traderId" to traderId.take(100),
        "traderName" to traderName.take(120),
        "entryPrice" to entryPrice.coerceAtLeast(0.0),
        "exitPrice" to exitPrice.coerceAtLeast(0.0),
        "quantity" to quantity.coerceAtLeast(0.0),
        "stopLoss" to stopLoss.coerceAtLeast(0.0),
        "takeProfit" to takeProfit.coerceAtLeast(0.0),
        "feesPaid" to feesPaid.coerceAtLeast(0.0),
        "slippageCost" to slippageCost.coerceAtLeast(0.0),
        "realizedPnl" to realizedPnl,
        "rationale" to rationale.take(2000),
        "riskApprovalId" to riskApprovalId.take(128),
        "brokerOrderId" to brokerOrderId.take(128),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class LearningLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val agentId: String = "",
    val agentName: String = "",
    val taskId: String = "",
    val tradeId: String = "",
    val errorType: String = "INSIGHT",
    val decisionSummary: String = "",
    val evidenceUsed: String = "",
    val actualOutcome: String = "",
    val rootCause: String = "",
    val financialImpact: Double = 0.0,
    val correctiveAction: String = "",
    val recurred: Boolean = false,
    val knowledgeRuleAdded: String = "",
    val createdAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "agentId" to agentId.take(100),
        "agentName" to agentName.take(120),
        "taskId" to taskId.take(128),
        "tradeId" to tradeId.take(128),
        "errorType" to if (errorType in listOf("ANALYSIS_ERROR", "EXECUTION_ERROR", "NORMAL_STRATEGY_LOSS", "INSIGHT")) errorType else "INSIGHT",
        "decisionSummary" to decisionSummary.take(1500),
        "evidenceUsed" to evidenceUsed.take(1500),
        "actualOutcome" to actualOutcome.take(1500),
        "rootCause" to rootCause.take(1500),
        "financialImpact" to financialImpact,
        "correctiveAction" to correctiveAction.take(1500),
        "recurred" to recurred,
        "knowledgeRuleAdded" to knowledgeRuleAdded.take(1500),
        "createdAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val actor: String = "",
    val actionType: String = "",
    val details: String = "",
    val severity: String = "INFO",
    val createdAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "actor" to actor.take(120),
        "actionType" to actionType.take(80),
        "details" to details.take(2000),
        "severity" to if (severity in listOf("INFO", "WARNING", "CRITICAL")) severity else "INFO",
        "createdAt" to FieldValue.serverTimestamp()
    )
}

data class BrokerCredentials(
    val platform: BrokerPlatform = BrokerPlatform.QUANTCORP_PAPER,
    val accountType: String = "Spot / Paper",
    val apiKey: String = "",
    val apiSecret: String = "",
    val customEndpoint: String = "",
    val useTestnet: Boolean = true,
    val withdrawalDisabledConfirmed: Boolean = true
)

data class BrokerAccountSnapshot(
    val platform: BrokerPlatform = BrokerPlatform.QUANTCORP_PAPER,
    val connected: Boolean = true,
    val modeLabel: String = "Paper",
    val balance: Double = 100_000.0,
    val equity: Double = 100_000.0,
    val openOrdersCount: Int = 0,
    val statusMessage: String = "Connected to live feed",
    val fetchedAtMillis: Long = System.currentTimeMillis()
)

data class MarketTicker(
    val symbol: String,
    val displayNameAr: String,
    val lastPrice: Double,
    val change24hPct: Double,
    val high24h: Double,
    val low24h: Double,
    val volume24hQuote: Double,
    val source: String,
    val fetchedAtMillis: Long
)

data class CandleBar(
    val openTimeMillis: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class TechnicalSnapshot(
    val symbol: String,
    val timeframe: String,
    val currentPrice: Double,
    val ema20: Double,
    val ema50: Double,
    val rsi14: Double,
    val atr14: Double,
    val bollingerUpper: Double,
    val bollingerLower: Double,
    val supportLevel: Double,
    val resistanceLevel: Double,
    val volumeSpikeRatio: Double,
    val orderbookBidAskRatio: Double,
    val trendBias: String,
    val fetchedAtMillis: Long,
    val source: String
)

data class BacktestReport(
    val strategyId: String,
    val symbol: String,
    val barsTested: Int,
    val inSampleReturnPct: Double,
    val walkForwardReturnPct: Double,
    val outOfSampleWinRate: Double,
    val maxDrawdownPct: Double,
    val profitFactor: Double,
    val totalTrades: Int,
    val feesAndSlippagePct: Double,
    val passedCriteria: Boolean,
    val summaryAr: String
)

data class RiskEvaluation(
    val approved: Boolean,
    val approvalId: String,
    val reasonsAr: List<String>,
    val computedPositionQty: Double,
    val computedRiskUsd: Double
)

data class PnLSummary(
    val mode: String,
    val totalRealizedProfit: Double,
    val totalRealizedLoss: Double,
    val totalFeesAndSlippage: Double,
    val netRealizedProfit: Double,
    val unrealizedPnl: Double,
    val balance: Double,
    val equity: Double,
    val roiPct: Double,
    val winRatePct: Double,
    val winningTrades: Int,
    val losingTrades: Int,
    val avgWin: Double,
    val avgLoss: Double,
    val largestWin: Double,
    val largestLoss: Double,
    val maxDrawdownPct: Double,
    val equityCurve: List<Double>
)

data class SniperEvidenceCheck(
    val titleAr: String,
    val passed: Boolean,
    val metricSummary: String
)

data class SniperSetupReport(
    val symbol: String,
    val preferredSide: String,
    val entryPrice: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val rewardToRisk: Double,
    val matchedCount: Int,
    val totalCriteria: Int,
    val evidenceScorePct: Double,
    val isFullSniperMatch: Boolean,
    val checks: List<SniperEvidenceCheck>,
    val forwardCatalystAr: String,
    val invalidationRuleAr: String,
    val h1Snapshot: TechnicalSnapshot,
    val fetchedAtMillis: Long,
    val dataSource: String
)
