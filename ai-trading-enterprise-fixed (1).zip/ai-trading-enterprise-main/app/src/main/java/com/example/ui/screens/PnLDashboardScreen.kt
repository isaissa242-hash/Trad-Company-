package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CandleBar
import com.example.model.CompanyConfig
import com.example.model.MarketTicker
import com.example.model.PnLSummary
import com.example.model.TechnicalSnapshot
import com.example.model.TradeRecord
import com.example.model.TradingStrategy
import com.example.model.formatUsdCents
import com.example.ui.components.CandlestickChart
import com.example.ui.components.EquityCurveChart
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldProfit
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated

@Composable
fun PnLDashboardScreen(
    config: CompanyConfig? = null,
    pnlSummary: PnLSummary,
    pnlModeFilter: String,
    onModeFilterChange: (String) -> Unit,
    trades: List<TradeRecord>,
    strategies: List<TradingStrategy>,
    tickers: List<MarketTicker>,
    selectedSymbol: String,
    selectedCandles: List<CandleBar>,
    selectedTechSnapshot: TechnicalSnapshot?,
    onSelectSymbol: (String) -> Unit,
    onCloseTrade: (TradeRecord) -> Unit,
    onWithdrawSafetyVault: (Double, Boolean, String) -> Unit = { _, _, _ -> }
) {
    val modeTrades = trades.filter { it.mode == pnlModeFilter }
    val openTrades = modeTrades.filter { it.status == "OPEN" }
    val closedTrades = modeTrades.filter { it.status == "CLOSED" }
    val tickerMap = tickers.associateBy { it.symbol }

    var showVaultWithdrawDialog by remember { mutableStateOf(false) }
    var withdrawAmountStr by remember { mutableStateOf("") }
    var returnToTradingCapital by remember { mutableStateOf(false) }
    var ownerWithdrawReason by remember { mutableStateOf("تدخل شخصي من المالك") }
    var ownerConfirmedCheckbox by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("لوحة الأرباح والخسائر (P&L)", style = MaterialTheme.typography.headlineSmall, color = ChampagneGold)
                    Text("فصل تام بين نتائج التداول التجريبي والحساب الحقيقي", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = pnlModeFilter == "PAPER",
                    onClick = { onModeFilterChange("PAPER") },
                    shape = SegmentedButtonDefaults.itemShape(0, 2)
                ) {
                    Text("التداول التجريبي (PAPER)")
                }
                SegmentedButton(
                    selected = pnlModeFilter == "LIVE",
                    onClick = { onModeFilterChange("LIVE") },
                    shape = SegmentedButtonDefaults.itemShape(1, 2)
                ) {
                    Text("الحساب الحقيقي (LIVE)")
                }
            }
        }

        // Main Live Profit & Equity Card (Every single cent visible live)
        item {
            val liveCombinedProfit = pnlSummary.netRealizedProfit + pnlSummary.unrealizedPnl
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("صافي الربح المباشر (${pnlSummary.mode})", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = formatUsdCents(liveCombinedProfit, signed = true),
                                style = MaterialTheme.typography.displaySmall,
                                color = if (liveCombinedProfit >= 0.0) EmeraldProfit else CrimsonRisk,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("pnl_live_cents_total")
                            )
                            Text(
                                text = "رأس المال الحي: ${formatUsdCents(pnlSummary.equity)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = ChampagneGold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("العائد ROI", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "${"%+.2f".format(pnlSummary.roiPct)}%",
                                style = MaterialTheme.typography.headlineSmall,
                                color = if (pnlSummary.roiPct >= 0) EmeraldProfit else CrimsonRisk,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    EquityCurveChart(
                        points = pnlSummary.equityCurve,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("الرصيد (Balance): ${formatUsdCents(pnlSummary.balance)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "العائم المباشر: ${formatUsdCents(pnlSummary.unrealizedPnl, signed = true)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (pnlSummary.unrealizedPnl >= 0) EmeraldProfit else CrimsonRisk,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (config != null && config.profitTargetUsd > 0.0) {
                        val gainedTowardGoal = liveCombinedProfit - config.profitTargetBaselinePnl
                        val goalPct = (gainedTowardGoal / config.profitTargetUsd).toFloat().coerceIn(0f, 1f)
                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = ObsidianBorder)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "هدف المالك: ${formatUsdCents(config.profitTargetUsd)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${formatUsdCents(gainedTowardGoal, signed = true)} (${"%.2f".format(goalPct * 100f)}%)",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (gainedTowardGoal >= 0.0) EmeraldProfit else CrimsonRisk,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { goalPct },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = EmeraldProfit,
                            trackColor = ObsidianBorder
                        )
                    }
                }
            }
        }

        // Company Safety Vault (10% Profit Shield - Owner-Only Withdrawal)
        item {
            val vaultBal = config?.safetyVaultBalance ?: 0.0
            val vaultTotalDeposited = config?.safetyVaultTotalDeposited ?: 0.0
            val allocationPct = config?.safetyVaultAllocationPct ?: 10.0
            val totalCompanyEquityWithVault = pnlSummary.equity + vaultBal
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ChampagneGold.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
                    .testTag("company_safety_vault_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = "خزنة أمان الشركة",
                                tint = ChampagneGold
                            )
                            Column {
                                Text(
                                    text = "خزنة أمان الشركة (${allocationPct.toInt()}% Shield Vault)",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ChampagneGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "مضادة للإفلاس • معزولة عن الوكلاء والتداول",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldProfit
                                )
                            }
                        }
                        Text(
                            text = formatUsdCents(vaultBal),
                            style = MaterialTheme.typography.headlineSmall,
                            color = EmeraldProfit,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("safety_vault_balance_text")
                        )
                    }
                    Text(
                        text = "يُحجز تلقائياً ${allocationPct.toInt()}% من صافي ربح كل صفقة رابحة في الخزنة. لا تُصرف أو تُسحب أموال الخزنة أبداً إلا بتدخل شخصي مباشر من المالك.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "إجمالي المحجوز تاريخياً: ${formatUsdCents(vaultTotalDeposited)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan
                        )
                        Text(
                            text = "إجمالي أصول الشركة (مع الخزنة): ${formatUsdCents(totalCompanyEquityWithVault)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ChampagneGold,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Button(
                        onClick = {
                            withdrawAmountStr = if (vaultBal > 0.0) "%.2f".format(java.util.Locale.US, vaultBal) else ""
                            ownerConfirmedCheckbox = false
                            showVaultWithdrawDialog = true
                        },
                        enabled = vaultBal > 0.0,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ChampagneGold,
                            contentColor = ObsidianBg,
                            disabledContainerColor = ObsidianSurfaceElevated,
                            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("vault_owner_withdraw_button")
                    ) {
                        Icon(imageVector = Icons.Filled.Security, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (vaultBal > 0.0) "سحب بتدخل المالك فقط" else "الخزنة تنتظر أول ربح لتأمين 10%",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Comprehensive Financial Metrics Grid (Exact cents on every cell)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiCell("صافي الربح المحقق", formatUsdCents(pnlSummary.netRealizedProfit, signed = true), if (pnlSummary.netRealizedProfit >= 0) EmeraldProfit else CrimsonRisk, Modifier.weight(1f))
                    KpiCell("إجمالي الأرباح", formatUsdCents(pnlSummary.totalRealizedProfit, signed = true), EmeraldProfit, Modifier.weight(1f))
                    KpiCell("إجمالي الخسائر", formatUsdCents(-pnlSummary.totalRealizedLoss, signed = true), CrimsonRisk, Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiCell("نسبة النجاح (Win Rate)", "${"%.1f".format(pnlSummary.winRatePct)}%", ElectricCyan, Modifier.weight(1f))
                    KpiCell("ناجحة / خاسرة", "${pnlSummary.winningTrades} / ${pnlSummary.losingTrades}", ChampagneGold, Modifier.weight(1f))
                    KpiCell("أقصى تراجع DD", "${"%.2f".format(pnlSummary.maxDrawdownPct)}%", CrimsonRisk, Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiCell("متوسط الربح", formatUsdCents(pnlSummary.avgWin, signed = true), EmeraldProfit, Modifier.weight(1f))
                    KpiCell("متوسط الخسارة", formatUsdCents(-pnlSummary.avgLoss, signed = true), CrimsonRisk, Modifier.weight(1f))
                    KpiCell("أكبر ربح / خسارة", "${formatUsdCents(pnlSummary.largestWin, signed = true)} / ${formatUsdCents(pnlSummary.largestLoss, signed = true)}", ChampagneGold, Modifier.weight(1f))
                }
            }
        }

        // Live Candlestick Chart & Technical Telemetry
        item {
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("الرسوم البيانية الحية والمؤشرات (1H)", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("PAXGUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT", "EURUSDT").forEach { sym ->
                            FilterChip(
                                selected = selectedSymbol == sym,
                                onClick = { onSelectSymbol(sym) },
                                label = { Text(sym.replace("USDT", ""), style = MaterialTheme.typography.labelMedium) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    CandlestickChart(
                        bars = selectedCandles,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                    )
                    selectedTechSnapshot?.let { snap ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "السعر: $${"%.2f".format(snap.currentPrice)} | RSI(14): ${"%.1f".format(snap.rsi14)} | EMA20: ${"%.2f".format(snap.ema20)} | الاتجاه: ${snap.trendBias}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ChampagneGold
                        )
                        Text(
                            text = "المصدر: ${snap.source} | توازن دفتر الأوامر Bid/Ask: ${"%.2f".format(snap.orderbookBidAskRatio)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Strategy & Trader Performance Breakdown
        item {
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("أداء الاستراتيجيات والموظفين", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                    strategies.forEach { st ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(st.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                            Text(
                                text = "${"%+.2f".format(st.realizedPnl)} $ (${st.paperTradesCount + st.liveTradesCount})",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (st.realizedPnl >= 0) EmeraldProfit else CrimsonRisk
                            )
                        }
                    }
                    val byTrader = closedTrades.groupBy { it.traderName.ifBlank { it.traderId } }
                    if (byTrader.isNotEmpty()) {
                        HorizontalDivider(color = ObsidianBorder, modifier = Modifier.padding(vertical = 4.dp))
                        byTrader.forEach { (traderName, list) ->
                            val pnl = list.sumOf { it.realizedPnl }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(traderName, style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                                Text(
                                    text = "${"%+.2f".format(pnl)} $ (${list.size} صفقة)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (pnl >= 0) EmeraldProfit else CrimsonRisk
                                )
                            }
                        }
                    }
                }
            }
        }

        // Open Positions Section
        item {
            Text("الصفقات المفتوحة (${openTrades.size})", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
        }
        if (openTrades.isEmpty()) {
            item {
                Text("لا توجد صفقات مفتوحة في وضع $pnlModeFilter.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(openTrades, key = { it.id }) { trade ->
                val mark = tickerMap[trade.symbol]?.lastPrice ?: trade.entryPrice
                val unrl = if (trade.side == "BUY") (mark - trade.entryPrice) * trade.quantity else (trade.entryPrice - mark) * trade.quantity
                Surface(
                    color = ObsidianSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${trade.symbol} • ${trade.side} (${trade.traderName})", style = MaterialTheme.typography.titleSmall, color = ChampagneGold)
                            Text("الدخول: $${"%.2f".format(trade.entryPrice)} | الحالي: $${"%.2f".format(mark)}", style = MaterialTheme.typography.bodySmall)
                            Text("SL: ${"%.2f".format(trade.stopLoss)} | TP: ${"%.2f".format(trade.takeProfit)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "الربح العائم: ${"%+.2f".format(unrl)} USD",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (unrl >= 0) EmeraldProfit else CrimsonRisk
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onCloseTrade(trade) },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRisk, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إغلاق", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }

        // Closed Trades History
        item {
            Text("سجل الصفقات المغلقة (${closedTrades.size})", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
        }
        items(closedTrades.take(20), key = { it.id }) { trade ->
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${trade.symbol} (${trade.side}) — ${trade.strategyName}", style = MaterialTheme.typography.titleSmall)
                        Text("دخول ${"%.2f".format(trade.entryPrice)} ← خروج ${"%.2f".format(trade.exitPrice)} | الرسوم: ${"%.2f".format(trade.feesPaid + trade.slippageCost)}$", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        text = "${"%+.2f".format(trade.realizedPnl)} $",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (trade.realizedPnl >= 0) EmeraldProfit else CrimsonRisk,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showVaultWithdrawDialog) {
        val vaultBalance = config?.safetyVaultBalance ?: 0.0
        val parsedAmount = withdrawAmountStr.replace(",", ".").toDoubleOrNull() ?: 0.0
        val amountValid = parsedAmount > 0.0 && parsedAmount <= vaultBalance + 0.001
        AlertDialog(
            onDismissRequest = { showVaultWithdrawDialog = false },
            containerColor = ObsidianSurface,
            title = {
                Text(
                    text = "تدخل شخصي من المالك — سحب من خزنة الأمان",
                    color = ChampagneGold,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "الرصيد المحمي المتاح في الخزنة: ${formatUsdCents(vaultBalance)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = EmeraldProfit,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(
                        value = withdrawAmountStr,
                        onValueChange = { withdrawAmountStr = it },
                        label = { Text("المبلغ المطلوب سحبه ($)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("vault_withdraw_amount_input")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.25 to "25%", 0.50 to "50%", 1.0 to "100%").forEach { (ratio, label) ->
                            FilterChip(
                                selected = false,
                                onClick = {
                                    val preset = (vaultBalance * ratio)
                                    withdrawAmountStr = "%.2f".format(java.util.Locale.US, preset)
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                    Text("وجهة الأموال بعد تدخل المالك:", style = MaterialTheme.typography.labelMedium, color = ElectricCyan)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !returnToTradingCapital,
                            onClick = { returnToTradingCapital = false },
                            label = { Text("سحب شخصي للمالك") }
                        )
                        FilterChip(
                            selected = returnToTradingCapital,
                            onClick = { returnToTradingCapital = true },
                            label = { Text("ضخ لإنقاذ رأس المال") }
                        )
                    }
                    OutlinedTextField(
                        value = ownerWithdrawReason,
                        onValueChange = { ownerWithdrawReason = it },
                        label = { Text("سبب تدخل المالك") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = ownerConfirmedCheckbox,
                            onCheckedChange = { ownerConfirmedCheckbox = it },
                            modifier = Modifier.testTag("vault_owner_confirm_checkbox")
                        )
                        Text(
                            text = "أؤكد بصفتي المالك الشخصي استخراج هذا المبلغ من خزنة أمان الشركة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AmberWarn
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showVaultWithdrawDialog = false
                        onWithdrawSafetyVault(
                            parsedAmount.coerceAtMost(vaultBalance),
                            returnToTradingCapital,
                            ownerWithdrawReason.ifBlank { "تدخل شخصي من المالك" }
                        )
                    },
                    enabled = amountValid && ownerConfirmedCheckbox,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRisk, contentColor = Color.White),
                    modifier = Modifier.testTag("vault_confirm_withdraw_button")
                ) {
                    Text("تأكيد السحب الشخصي")
                }
            },
            dismissButton = {
                TextButton(onClick = { showVaultWithdrawDialog = false }) {
                    Text("إلغاء وإبقاء الخزنة مؤمّنة")
                }
            }
        )
    }
}

@Composable
private fun KpiCell(title: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Surface(
        color = ObsidianSurface,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.border(1.dp, ObsidianBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = valueColor, fontWeight = FontWeight.Bold)
        }
    }
}
