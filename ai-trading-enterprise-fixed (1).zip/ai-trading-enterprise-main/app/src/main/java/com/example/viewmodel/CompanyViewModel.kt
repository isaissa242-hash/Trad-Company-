package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AgentOrchestrator
import com.example.data.ai.CommandOutbox
import com.example.data.ai.OwnerCommandException
import com.example.data.ai.PendingOwnerCommand
import com.example.data.broker.BrokerConnector
import com.example.data.firebase.CompanyRepository
import com.example.data.market.BacktestEngine
import com.example.data.market.MarketDataService
import com.example.data.market.TechnicalIndicatorEngine
import com.example.model.AgentProfile
import com.example.model.AgentStatus
import com.example.model.AuditLog
import com.example.model.BacktestReport
import com.example.model.BrokerAccountSnapshot
import com.example.model.BrokerCredentials
import com.example.model.CandleBar
import com.example.model.CompanyConfig
import com.example.model.CorporateMessage
import com.example.model.CorporateTask
import com.example.model.LearningLog
import com.example.model.MarketTicker
import com.example.model.PnLSummary
import com.example.model.TechnicalSnapshot
import com.example.model.TradeRecord
import com.example.model.TradingStrategy
import com.example.security.EncryptedVault
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import com.example.model.formatUsdCents
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max

sealed interface StreamState<out T> {
    data object Loading : StreamState<Nothing>
    data class Ready<T>(val data: T) : StreamState<T>
    data class Error(val message: String) : StreamState<Nothing>
}

private const val MAX_QUEUED_COMMANDS = 20
private const val MAX_AUTO_COMMAND_ATTEMPTS = 6
private const val STALE_COMMAND_MS = 10 * 60 * 1000L

class CompanyViewModel(
    private val repository: CompanyRepository,
    private val marketService: MarketDataService,
    private val brokerConnector: BrokerConnector,
    private val encryptedVault: EncryptedVault,
    private val currentUserId: String,
    private val commandOutbox: CommandOutbox? = null
) : ViewModel() {

    private val orchestrator = AgentOrchestrator(repository, marketService, brokerConnector)

    val configState: StateFlow<StreamState<CompanyConfig>> = repository.observeConfig()
        .map<CompanyConfig, StreamState<CompanyConfig>> { StreamState.Ready(it) }
        .catch { emit(StreamState.Error(unwrapFirestoreError(it, "company_state"))) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), StreamState.Loading)

    val agentsState: StateFlow<List<AgentProfile>> = repository.observeAgents()
        .catch { unwrapFirestoreError(it, "agents"); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val tasksState: StateFlow<List<CorporateTask>> = repository.observeTasks()
        .catch { unwrapFirestoreError(it, "tasks"); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val messagesState: StateFlow<List<CorporateMessage>> = repository.observeMessages()
        .catch { unwrapFirestoreError(it, "messages"); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val strategiesState: StateFlow<List<TradingStrategy>> = repository.observeStrategies()
        .catch { unwrapFirestoreError(it, "strategies"); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val tradesState: StateFlow<List<TradeRecord>> = repository.observeTrades()
        .catch { unwrapFirestoreError(it, "trades"); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val learningLogsState: StateFlow<List<LearningLog>> = repository.observeLearningLogs()
        .catch { unwrapFirestoreError(it, "learning_logs"); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val auditLogsState: StateFlow<List<AuditLog>> = repository.observeAuditLogs()
        .catch { unwrapFirestoreError(it, "audit_logs"); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val isNetworkOnline: StateFlow<Boolean> = repository.observeNetworkOnline()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

    private val _liveTickers = MutableStateFlow<List<MarketTicker>>(emptyList())
    val liveTickers: StateFlow<List<MarketTicker>> = _liveTickers.asStateFlow()

    private val _marketError = MutableStateFlow<String?>(null)
    val marketError: StateFlow<String?> = _marketError.asStateFlow()

    private val _selectedSymbol = MutableStateFlow("PAXGUSDT")
    val selectedSymbol: StateFlow<String> = _selectedSymbol.asStateFlow()

    private val _selectedCandles = MutableStateFlow<List<CandleBar>>(emptyList())
    val selectedCandles: StateFlow<List<CandleBar>> = _selectedCandles.asStateFlow()

    private val _selectedTechSnapshot = MutableStateFlow<TechnicalSnapshot?>(null)
    val selectedTechSnapshot: StateFlow<TechnicalSnapshot?> = _selectedTechSnapshot.asStateFlow()

    private val _isCommandRunning = MutableStateFlow(false)
    val isCommandRunning: StateFlow<Boolean> = _isCommandRunning.asStateFlow()

    private val _commandStatusMessage = MutableStateFlow<String?>(null)
    val commandStatusMessage: StateFlow<String?> = _commandStatusMessage.asStateFlow()

    // ---- Owner-command outbox: one message is enough; it is saved, queued and retried automatically ----
    private val _queuedCommandCount = MutableStateFlow(0)
    val queuedCommandCount: StateFlow<Int> = _queuedCommandCount.asStateFlow()

    private val _failedCommand = MutableStateFlow<PendingOwnerCommand?>(null)
    val failedCommand: StateFlow<PendingOwnerCommand?> = _failedCommand.asStateFlow()

    private val commandQueueLock = Any()
    private val commandQueue = ArrayDeque<PendingOwnerCommand>()
    private var commandWorkerRunning = false

    private val _bannerMessage = MutableStateFlow<String?>(null)
    val bannerMessage: StateFlow<String?> = _bannerMessage.asStateFlow()

    private val _brokerCreds = MutableStateFlow(BrokerCredentials())
    val brokerCreds: StateFlow<BrokerCredentials> = _brokerCreds.asStateFlow()

    private val _brokerSnapshot = MutableStateFlow(BrokerAccountSnapshot())
    val brokerSnapshot: StateFlow<BrokerAccountSnapshot> = _brokerSnapshot.asStateFlow()

    private val _lastBacktestReport = MutableStateFlow<BacktestReport?>(null)
    val lastBacktestReport: StateFlow<BacktestReport?> = _lastBacktestReport.asStateFlow()

    private val _isBacktesting = MutableStateFlow(false)
    val isBacktesting: StateFlow<Boolean> = _isBacktesting.asStateFlow()

    private val _pnlFilterMode = MutableStateFlow("PAPER")
    val pnlFilterMode: StateFlow<String> = _pnlFilterMode.asStateFlow()

    val pnlSummary: StateFlow<PnLSummary> = combine(
        configState,
        tradesState,
        liveTickers,
        pnlFilterMode
    ) { cfgState, trades, tickers, mode ->
        val config = (cfgState as? StreamState.Ready)?.data ?: CompanyConfig(userId = currentUserId)
        computePnlSummary(mode, config, trades, tickers)
    }.flowOn(Dispatchers.Default)
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000L),
            PnLSummary("PAPER", 0.0, 0.0, 0.0, 0.0, 0.0, 100_000.0, 100_000.0, 0.0, 0.0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, listOf(100_000.0))
        )

    init {
        viewModelScope.launch {
            val loadedCreds = withContext(Dispatchers.IO) {
                encryptedVault.loadCredentials(currentUserId)
            }
            _brokerCreds.value = loadedCreds
            // Resume owner orders saved before the app was closed (broker credentials are loaded by now).
            restorePendingCommands()
            refreshBrokerAccount()
            repository.ensureCompanyInitialized().onFailure {
                _bannerMessage.value = "تعذر تهيئة الشركة في Firestore: ${it.localizedMessage}"
            }
        }
        startLiveMarketPolling()
        viewModelScope.launch {
            delay(250L)
            refreshSelectedChart("PAXGUSDT")
        }
    }

    fun retryCompanyInitialization() {
        viewModelScope.launch {
            repository.ensureCompanyInitialized()
                .onSuccess {
                    _bannerMessage.value = "تم الاتصال ببيانات الشركة وتهيئة المكتب بنجاح."
                }
                .onFailure {
                    _bannerMessage.value = "تعذر الاتصال بـ Firestore: ${it.localizedMessage}"
                }
        }
    }

    private fun unwrapFirestoreError(error: Throwable, col: String): String {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val root = firestoreError ?: error
        Log.w(TAG, "Stream error on $col", root)
        return root.message ?: "فشل تحميل $col"
    }

    private val closingTradeIds = ConcurrentHashMap.newKeySet<String>()

    private fun startLiveMarketPolling() {
        viewModelScope.launch {
            delay(200L)
            while (isActive) {
                refreshMarketsOnce()
                delay(3_000L)
            }
        }
    }

    fun refreshMarketsOnce() {
        viewModelScope.launch {
            marketService.fetchLiveTickers()
                .onSuccess { tickers ->
                    _liveTickers.value = tickers
                    _marketError.value = null
                    refreshBrokerAccount()
                    autoSettlePaperTargets(tickers)
                }
                .onFailure { err ->
                    _marketError.value = "تعذر جلب الأسعار الحية: ${err.localizedMessage}"
                }
        }
    }

    private fun autoSettlePaperTargets(tickers: List<MarketTicker>) {
        val tickerMap = tickers.associateBy { it.symbol }
        val openPaper = tradesState.value.filter { it.status == "OPEN" && it.mode == "PAPER" }
        for (trade in openPaper) {
            val mark = tickerMap[trade.symbol]?.lastPrice ?: continue
            val hitTp = if (trade.side == "BUY") mark >= trade.takeProfit && trade.takeProfit > 0.0
            else mark <= trade.takeProfit && trade.takeProfit > 0.0
            val hitSl = if (trade.side == "BUY") mark <= trade.stopLoss && trade.stopLoss > 0.0
            else mark >= trade.stopLoss && trade.stopLoss > 0.0
            if (!hitTp && !hitSl) continue
            if (!closingTradeIds.add(trade.id)) continue

            viewModelScope.launch {
                try {
                    val fee = mark * trade.quantity * 0.0010
                    val slip = mark * trade.quantity * 0.0005
                    val gross = if (trade.side == "BUY") (mark - trade.entryPrice) * trade.quantity
                    else (trade.entryPrice - mark) * trade.quantity
                    val netPnl = gross - trade.feesPaid - trade.slippageCost - fee - slip

                    val closedNow = repository.closeTrade(
                        tradeId = trade.id,
                        exitPrice = mark,
                        feesPaid = trade.feesPaid + fee,
                        slippageCost = trade.slippageCost + slip,
                        realizedPnl = netPnl
                    ).getOrDefault(false)
                    if (!closedNow) return@launch

                    val vaultLocked = repository.applyTradeSettlementToTreasury(trade.mode, netPnl, trade.id, trade.symbol).getOrDefault(0.0)
                    updateStrategyTradeStats(trade, netPnl)

                    val lesson = orchestrator.generatePostTradeLesson(
                        trade.copy(exitPrice = mark, realizedPnl = netPnl),
                        tradesState.value.filter { it.status == "CLOSED" },
                        agentsState.value.firstOrNull { it.id == "hr_01" }
                    )
                    repository.addLearningLog(lesson)
                    applyTradeOutcomeRanks(trade, netPnl, lesson)
                    val vaultNote = if (vaultLocked > 0.0) " • خزنة الأمان 10%: +${formatUsdCents(vaultLocked)}" else ""
                    repository.addAuditLog(
                        actor = "Live Profit Monitor",
                        actionType = if (hitTp) "TP_PROFIT_REALIZED" else "SL_CLOSED",
                        details = "إغلاق تلقائي لـ ${trade.symbol} @ ${formatUsdCents(mark)} بصافي ${formatUsdCents(netPnl, signed = true)}$vaultNote",
                        severity = if (netPnl >= 0) "INFO" else "WARNING"
                    )
                } finally {
                    closingTradeIds.remove(trade.id)
                }
            }
        }
    }

    fun selectChartSymbol(symbol: String) {
        _selectedSymbol.value = symbol
        refreshSelectedChart(symbol)
    }

    private fun refreshSelectedChart(symbol: String) {
        viewModelScope.launch {
            marketService.fetchCandles(symbol, "1h", 96).onSuccess { (bars, src) ->
                _selectedCandles.value = bars
                if (bars.size >= 30) {
                    val ratio = marketService.fetchOrderbookBidAskRatio(symbol)
                    _selectedTechSnapshot.value = TechnicalIndicatorEngine.analyze(symbol, "1h", bars, ratio, src)
                }
            }
        }
    }

    /**
     * Accepts an owner order. It is persisted and queued immediately, so the caller can clear the
     * input box at once: the order survives server overload, network loss and process death, and
     * is re-sent automatically (only while it is still safe, i.e. before any trade side-effect).
     */
    fun sendOwnerCommand(commandText: String) {
        val text = commandText.trim()
        if (text.isBlank()) return
        val cmd = PendingOwnerCommand(
            id = UUID.randomUUID().toString(),
            text = text,
            createdAtMs = System.currentTimeMillis()
        )
        val accepted = synchronized(commandQueueLock) {
            if (commandQueue.size >= MAX_QUEUED_COMMANDS || commandQueue.any { it.text == text }) {
                false
            } else {
                commandQueue.addLast(cmd)
                true
            }
        }
        if (!accepted) {
            _bannerMessage.value = "هذا الأمر موجود بالفعل في قائمة الانتظار أو أن القائمة ممتلئة."
            return
        }
        if (_failedCommand.value?.text == text) _failedCommand.value = null
        publishQueueSize()
        persistOutbox()
        startCommandWorker()
    }

    /** Re-sends the last command whose automatic retries were exhausted. */
    fun retryFailedCommand() {
        val failed = _failedCommand.value ?: return
        _failedCommand.value = null
        synchronized(commandQueueLock) {
            commandQueue.addLast(
                failed.copy(
                    // attempts >= 1 => the owner's message is not posted to the chat a second time
                    attempts = maxOf(1, failed.attempts.coerceAtMost(MAX_AUTO_COMMAND_ATTEMPTS - 2)),
                    failed = false,
                    inFlight = false,
                    lastError = "",
                    createdAtMs = System.currentTimeMillis()
                )
            )
        }
        publishQueueSize()
        persistOutbox()
        startCommandWorker()
    }

    fun dismissFailedCommand() {
        _failedCommand.value = null
        persistOutbox()
    }

    private fun publishQueueSize() {
        _queuedCommandCount.value = synchronized(commandQueueLock) { commandQueue.size }
    }

    private fun persistOutbox() {
        val box = commandOutbox ?: return
        val snapshot = synchronized(commandQueueLock) { commandQueue.toList() } +
            listOfNotNull(_failedCommand.value)
        runCatching { box.save(snapshot) }
    }

    private fun updateQueuedCommand(cmd: PendingOwnerCommand) {
        synchronized(commandQueueLock) {
            val idx = commandQueue.indexOfFirst { it.id == cmd.id }
            if (idx >= 0) commandQueue[idx] = cmd
        }
        persistOutbox()
    }

    private fun removeQueuedCommand(id: String) {
        synchronized(commandQueueLock) { commandQueue.removeAll { it.id == id } }
        publishQueueSize()
        persistOutbox()
    }

    private fun restorePendingCommands() {
        val saved = runCatching { commandOutbox?.load() }.getOrNull().orEmpty()
        if (saved.isEmpty()) return
        val now = System.currentTimeMillis()
        var resumed = false
        saved.forEach { item ->
            val stale = now - item.createdAtMs > STALE_COMMAND_MS
            when {
                item.failed -> _failedCommand.value = item
                item.inFlight -> _failedCommand.value = item.copy(
                    failed = true,
                    inFlight = false,
                    lastError = "انقطع التطبيق أثناء تنفيذ هذا الأمر. تحقق من الصفقات والمهام أولاً ثم أعد الإرسال إن أردت."
                )
                stale -> _failedCommand.value = item.copy(
                    failed = true,
                    lastError = "الأمر المحفوظ أقدم من 10 دقائق ولم يُرسل. أعد إرساله يدوياً إن كان ما زال مطلوباً."
                )
                else -> {
                    synchronized(commandQueueLock) { commandQueue.addLast(item) }
                    resumed = true
                }
            }
        }
        publishQueueSize()
        persistOutbox()
        if (resumed) startCommandWorker()
    }

    private fun startCommandWorker() {
        val shouldStart = synchronized(commandQueueLock) {
            if (commandWorkerRunning) false else { commandWorkerRunning = true; true }
        }
        if (!shouldStart) return
        viewModelScope.launch {
            try {
                while (true) {
                    val next = synchronized(commandQueueLock) {
                        val head = commandQueue.firstOrNull()
                        if (head == null) commandWorkerRunning = false
                        head
                    } ?: break
                    try {
                        processQueuedCommand(next)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        Log.e("CompanyViewModel", "Unexpected command failure", e)
                        removeQueuedCommand(next.id)
                        _failedCommand.value = next.copy(failed = true, inFlight = false, lastError = e.localizedMessage ?: "خطأ غير متوقع")
                        persistOutbox()
                        _bannerMessage.value = e.localizedMessage ?: "تعذر معالجة الأمر"
                    }
                }
            } catch (e: CancellationException) {
                synchronized(commandQueueLock) { commandWorkerRunning = false }
                throw e
            }
        }
    }

    private suspend fun processQueuedCommand(initial: PendingOwnerCommand) {
        var cmd = initial
        // Another AI job (HR / audit / IQ upgrade) may be running: wait for it instead of dropping the order.
        while (_isCommandRunning.value) delay(400L)
        _isCommandRunning.value = true
        try {
            // Make sure the company data (agents incl. the CEO block flag) has loaded before routing.
            withTimeoutOrNull(20_000L) { agentsState.first { it.isNotEmpty() } }
            while (true) {
                val attemptNo = cmd.attempts
                _commandStatusMessage.value = if (attemptNo == 0) {
                    "جاري إرسال أمرك للرئيس التنفيذي..."
                } else {
                    "إعادة إرسال أمرك للرئيس التنفيذي (محاولة ${attemptNo + 1})..."
                }
                cmd = cmd.copy(inFlight = true)
                updateQueuedCommand(cmd)

                val config = (configState.value as? StreamState.Ready)?.data ?: CompanyConfig(userId = currentUserId)
                val result: Result<String> = try {
                    orchestrator.processOwnerCommand(
                        ownerCommand = cmd.text,
                        config = config,
                        agents = agentsState.value,
                        strategies = strategiesState.value,
                        openTrades = tradesState.value.filter { it.status == "OPEN" },
                        closedTrades = tradesState.value.filter { it.status == "CLOSED" },
                        learningLogs = learningLogsState.value,
                        liveTickers = _liveTickers.value,
                        brokerCreds = _brokerCreds.value,
                        onStatusUpdate = { status -> _commandStatusMessage.value = status },
                        postOwnerMessage = attemptNo == 0
                    )
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    Result.failure(e)
                }

                if (result.isSuccess) {
                    removeQueuedCommand(cmd.id)
                    if (_failedCommand.value?.text == cmd.text) _failedCommand.value = null
                    return
                }

                val error = result.exceptionOrNull()
                val retryable = (error as? OwnerCommandException)?.retryable == true
                val nextAttempts = attemptNo + 1
                if (retryable && nextAttempts < MAX_AUTO_COMMAND_ATTEMPTS) {
                    cmd = cmd.copy(attempts = nextAttempts, inFlight = false, lastError = error?.localizedMessage.orEmpty())
                    updateQueuedCommand(cmd)
                    var left = (5L shl (nextAttempts - 1)).coerceAtMost(60L) // 5s, 10s, 20s, 40s, 60s
                    while (left > 0L) {
                        _commandStatusMessage.value =
                            "ضغط على الخادم — إعادة إرسال أمرك تلقائياً بعد ${left}ث (${nextAttempts}/${MAX_AUTO_COMMAND_ATTEMPTS - 1})"
                        delay(1_000L)
                        left--
                    }
                } else {
                    val message = error?.localizedMessage ?: "تعذر معالجة الأمر"
                    removeQueuedCommand(cmd.id)
                    _failedCommand.value = cmd.copy(attempts = nextAttempts, failed = true, inFlight = false, lastError = message)
                    persistOutbox()
                    _bannerMessage.value = message
                    return
                }
            }
        } finally {
            _isCommandRunning.value = false
            _commandStatusMessage.value = null
        }
    }

    fun setPnlModeFilter(mode: String) {
        _pnlFilterMode.value = mode
    }

    fun toggleKillSwitch(activate: Boolean) {
        viewModelScope.launch {
            repository.updateConfigFields(
                mapOf(
                    "killSwitchActive" to activate,
                    "tradingPaused" to if (activate) true else (configState.value as? StreamState.Ready)?.data?.tradingPaused ?: false
                )
            )
            repository.addAuditLog(
                actor = "OWNER",
                actionType = if (activate) "KILL_SWITCH_ON" else "KILL_SWITCH_OFF",
                details = if (activate) "تفعيل مفتاح الإيقاف الكلي للطوارئ (Kill Switch)" else "إعادة تفعيل جاهزية الشركة من المالك",
                severity = "CRITICAL"
            )
            _bannerMessage.value = if (activate) "تم تفعيل Kill Switch: جميع الأوامر الجديدة موقوفة تماماً" else "تم فك القفل الطارئ"
        }
    }

    fun toggleTradingPause(paused: Boolean) {
        viewModelScope.launch {
            repository.updateConfigFields(mapOf("tradingPaused" to paused))
            repository.addAuditLog("OWNER", "TRADING_PAUSE_TOGGLE", "حالة إيقاف التداول: $paused", "WARNING")
        }
    }

    fun emergencyCloseAllOpenTrades() {
        viewModelScope.launch {
            val openTrades = tradesState.value.filter { it.status == "OPEN" }
            val tickers = _liveTickers.value.associateBy { it.symbol }
            var closedCount = 0
            for (trade in openTrades) {
                val markPrice = tickers[trade.symbol]?.lastPrice ?: trade.entryPrice
                val fee = markPrice * trade.quantity * 0.0010
                val slip = markPrice * trade.quantity * 0.0005
                val gross = if (trade.side == "BUY") (markPrice - trade.entryPrice) * trade.quantity
                else (trade.entryPrice - markPrice) * trade.quantity
                val netPnl = gross - trade.feesPaid - trade.slippageCost - fee - slip

                val closedNow = repository.closeTrade(
                    tradeId = trade.id,
                    exitPrice = markPrice,
                    feesPaid = trade.feesPaid + fee,
                    slippageCost = trade.slippageCost + slip,
                    realizedPnl = netPnl
                ).getOrDefault(false)
                if (!closedNow) continue

                repository.applyTradeSettlementToTreasury(trade.mode, netPnl, trade.id, trade.symbol)
                updateStrategyTradeStats(trade, netPnl)
                val lesson = orchestrator.generatePostTradeLesson(
                    trade.copy(exitPrice = markPrice, realizedPnl = netPnl),
                    tradesState.value.filter { it.status == "CLOSED" },
                    agentsState.value.firstOrNull { it.id == "hr_01" }
                )
                repository.addLearningLog(lesson)
                applyTradeOutcomeRanks(trade, netPnl, lesson)
                closedCount++
            }
            repository.updateConfigFields(mapOf("tradingPaused" to true))
            repository.addAuditLog("OWNER", "EMERGENCY_CLOSE_ALL", "إغلاق طوارئ لعدد $closedCount صفقة مفتوحة وإيقاف التداول.", "CRITICAL")
            _bannerMessage.value = "تم تنفيذ إغلاق الطوارئ ($closedCount صفقة) وإيقاف التداول."
        }
    }

    fun closeSingleTrade(trade: TradeRecord) {
        if (!closingTradeIds.add(trade.id)) return
        viewModelScope.launch {
            try {
                val markPrice = _liveTickers.value.firstOrNull { it.symbol == trade.symbol }?.lastPrice ?: trade.entryPrice
                val fee = markPrice * trade.quantity * 0.0010
                val slip = markPrice * trade.quantity * 0.0005
                val gross = if (trade.side == "BUY") (markPrice - trade.entryPrice) * trade.quantity
                else (trade.entryPrice - markPrice) * trade.quantity
                val netPnl = gross - trade.feesPaid - trade.slippageCost - fee - slip

                val closedNow = repository.closeTrade(
                    tradeId = trade.id,
                    exitPrice = markPrice,
                    feesPaid = trade.feesPaid + fee,
                    slippageCost = trade.slippageCost + slip,
                    realizedPnl = netPnl
                ).getOrDefault(false)
                if (!closedNow) return@launch

                val vaultLocked = repository.applyTradeSettlementToTreasury(trade.mode, netPnl, trade.id, trade.symbol).getOrDefault(0.0)
                updateStrategyTradeStats(trade, netPnl)
                val lesson = orchestrator.generatePostTradeLesson(
                    trade.copy(exitPrice = markPrice, realizedPnl = netPnl),
                    tradesState.value.filter { it.status == "CLOSED" },
                    agentsState.value.firstOrNull { it.id == "hr_01" }
                )
                repository.addLearningLog(lesson)
                applyTradeOutcomeRanks(trade, netPnl, lesson)
                val vaultNote = if (vaultLocked > 0.0) " (تم تأمين ${formatUsdCents(vaultLocked)} في خزنة الأمان)" else ""
                repository.addAuditLog("Head of Trading", "TRADE_CLOSED", "إغلاق ${trade.symbol} بنتيجة ${formatUsdCents(netPnl, signed = true)}$vaultNote وتحديث الذاكرة والرتب.", "INFO")
                if (vaultLocked > 0.0) {
                    _bannerMessage.value = "ربح محقق ${formatUsdCents(netPnl, signed = true)} — تم إيداع 10% (${formatUsdCents(vaultLocked)}) تلقائياً في خزنة الأمان!"
                }
            } finally {
                closingTradeIds.remove(trade.id)
            }
        }
    }

    private suspend fun updateStrategyTradeStats(trade: TradeRecord, netPnl: Double) {
        val strat = strategiesState.value.firstOrNull { it.id == trade.strategyId } ?: return
        repository.updateStrategyFields(
            strat.id,
            mapOf(
                "paperTradesCount" to (strat.paperTradesCount + if (trade.mode == "PAPER") 1L else 0L),
                "liveTradesCount" to (strat.liveTradesCount + if (trade.mode == "LIVE") 1L else 0L),
                "realizedPnl" to (strat.realizedPnl + netPnl)
            )
        )
    }

    private suspend fun applyTradeOutcomeRanks(trade: TradeRecord, netPnl: Double, lesson: LearningLog) {
        val currentAgents = agentsState.value
        val trader = currentAgents.firstOrNull { it.id == trade.traderId }
        val isWin = netPnl > 0.0
        val isError = lesson.errorType == "ANALYSIS_ERROR" || lesson.errorType == "EXECUTION_ERROR"

        if (isWin && !isError) {
            if (trader != null) {
                repository.awardProfitPromotion(
                    agent = trader,
                    realizedProfitUsd = netPnl,
                    roleShare = 1.0,
                    incrementTaskCount = true,
                    incrementWinCount = true,
                    newStatus = AgentStatus.COMPLETED.label,
                    currentTaskText = "جنى ربحاً حقيقياً ${formatUsdCents(netPnl, signed = true)} على ${trade.symbol}",
                    reasonAr = "ربح محقق ${formatUsdCents(netPnl, signed = true)} (${trade.symbol})"
                )
            }
            val leadershipIds = listOf("ceo_01", "hot_01", "mid_01", "cro_01")
            leadershipIds.forEach { mgrId ->
                currentAgents.firstOrNull { it.id == mgrId }?.let { mgr ->
                    repository.awardProfitPromotion(
                        agent = mgr,
                        realizedProfitUsd = netPnl,
                        roleShare = 0.60,
                        incrementWinCount = true,
                        reasonAr = "ربح مؤسسي محقق على ${trade.symbol} (${formatUsdCents(netPnl, signed = true)})"
                    )
                }
            }
            val analystIds = listOf("ana_fund_01", "ana_tech_01", "ana_liq_01")
            analystIds.forEach { anaId ->
                currentAgents.firstOrNull { it.id == anaId }?.let { ana ->
                    repository.awardProfitPromotion(
                        agent = ana,
                        realizedProfitUsd = netPnl,
                        roleShare = 0.40,
                        incrementWinCount = true,
                        reasonAr = "تحليل مربح على ${trade.symbol} (${formatUsdCents(netPnl, signed = true)})"
                    )
                }
            }
        } else if (isError && trader != null) {
            repository.penalizeExecutionError(
                agent = trader,
                xpPenalty = 10L,
                reasonAr = "خسارة بسبب خطأ في ${trade.symbol} (${formatUsdCents(netPnl, signed = true)})"
            )
        }
    }

    fun clearProfitTarget() {
        viewModelScope.launch {
            repository.updateConfigFields(mapOf("profitTargetUsd" to 0.0, "profitTargetBaselinePnl" to 0.0))
        }
    }

    fun withdrawFromSafetyVaultByOwner(
        amountUsd: Double,
        returnToTradingCapital: Boolean,
        ownerReason: String
    ) {
        viewModelScope.launch {
            repository.withdrawFromSafetyVaultByOwner(amountUsd, returnToTradingCapital, ownerReason)
                .onSuccess { withdrawn ->
                    _bannerMessage.value = "تم سحب ${formatUsdCents(withdrawn)} من خزنة الأمان بتدخل شخصي من المالك."
                }
                .onFailure { err ->
                    _bannerMessage.value = err.localizedMessage ?: "تعذر السحب من خزنة الأمان"
                }
        }
    }

    fun toggleCloudAutonomousEngine(enableCloud24_7: Boolean) {
        viewModelScope.launch {
            val location = if (enableCloud24_7) "CLOUD_24_7" else "LOCAL"
            val status = if (enableCloud24_7) "RUNNING" else "STANDBY"
            val summary = if (enableCloud24_7) {
                "المحرك السحابي 24/7 مفعّل — يدير الدورات تلقائياً كل 5 دقائق عبر Cloud Scheduler"
            } else {
                "التشغيل المحلي مفعّل — الأوامر تعمل مباشرة من جهاز المالك"
            }
            repository.updateConfigFields(
                mapOf(
                    "cloudEngineEnabled" to enableCloud24_7,
                    "executionLocation" to location,
                    "cloudEngineStatus" to status,
                    "cloudLastSummary" to summary
                )
            )
            repository.addAuditLog(
                actor = "OWNER",
                actionType = "CLOUD_ENGINE_TOGGLE",
                details = summary,
                severity = "INFO"
            )
            _bannerMessage.value = summary
        }
    }

    fun updateRiskSettings(
        allocatedCapital: Double,
        maxRiskPct: Double,
        dailyLossPct: Double,
        maxPositions: Long
    ) {
        viewModelScope.launch {
            repository.updateConfigFields(
                mapOf(
                    "allocatedCapital" to allocatedCapital.coerceIn(100.0, 100_000_000.0),
                    "maxRiskPerTradePct" to maxRiskPct.coerceIn(0.1, 10.0),
                    "dailyLossLimitPct" to dailyLossPct.coerceIn(0.5, 25.0),
                    "maxOpenPositions" to maxPositions.coerceIn(1L, 25L)
                )
            )
            repository.addAuditLog("OWNER", "RISK_PARAMS_UPDATED", "Capital=$allocatedCapital, MaxRisk=$maxRiskPct%, DailyLoss=$dailyLossPct%", "INFO")
            _bannerMessage.value = "تم حفظ حدود رأس المال والمخاطر"
        }
    }

    fun setTradingMode(mode: String, explicitOwnerLiveApproval: Boolean) {
        viewModelScope.launch {
            if (mode == "LIVE" && !explicitOwnerLiveApproval) {
                _bannerMessage.value = "يتطلب التداول الحقيقي موافقة صريحة من المالك."
                return@launch
            }
            repository.updateConfigFields(
                mapOf(
                    "tradingMode" to mode,
                    "liveTradingApprovedByOwner" to (mode == "LIVE" && explicitOwnerLiveApproval)
                )
            )
            repository.addAuditLog("OWNER", "MODE_SWITCH", "تغيير وضع التداول إلى $mode", if (mode == "LIVE") "CRITICAL" else "INFO")
            _pnlFilterMode.value = mode
            _bannerMessage.value = if (mode == "LIVE") "تم تفعيل وضع التداول الحقيقي بإذن المالك" else "تم الرجوع لوضع التداول التجريبي (Paper)"
        }
    }

    fun toggleSniperOperations(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateConfigFields(mapOf("sniperEnabled" to enabled))
            repository.updateAgentFields(
                "sniper_01",
                mapOf(
                    "blockedByOwner" to !enabled,
                    "status" to if (enabled) AgentStatus.WAITING.label else AgentStatus.ERROR.label,
                    "currentTask" to if (enabled) {
                        "رصْد صامت بدقة 100%: انتظار تطابق 5/5 مؤشرات تأكيد"
                    } else {
                        "عمليات القناص معطلة من لوحة الإدارة (Admin Panel)"
                    }
                )
            )
            repository.addAuditLog(
                actor = "OWNER",
                actionType = "SNIPER_OPERATIONS_TOGGLE",
                details = if (enabled) {
                    "تفعيل عمليات القناص 🎯 (دخول 100% / 5 مؤشرات تأكيد) من لوحة الإدارة."
                } else {
                    "تعطيل عمليات القناص 🎯 من لوحة الإدارة."
                },
                severity = "WARNING"
            )
            _bannerMessage.value = if (enabled) {
                "تم تفعيل عمليات القناص 🎯 (دلائل تأكيد 100% فقط)"
            } else {
                "تم تعطيل عمليات القناص 🎯 من لوحة الإدارة"
            }
        }
    }

    fun setAgentBlocked(agentId: String, blocked: Boolean) {
        viewModelScope.launch {
            if (agentId == "sniper_01") {
                toggleSniperOperations(!blocked)
                return@launch
            }
            repository.updateAgentFields(
                agentId,
                mapOf(
                    "blockedByOwner" to blocked,
                    "status" to if (blocked) AgentStatus.ERROR.label else AgentStatus.WAITING.label,
                    "currentTask" to if (blocked) "موقوف بأمر المالك" else "أعيد تفعيله من المالك"
                )
            )
            repository.addAuditLog("OWNER", "AGENT_ACCESS_CHANGE", "Agent=$agentId blocked=$blocked", "WARNING")
        }
    }

    fun updateAgentModel(agentId: String, modelId: String) {
        viewModelScope.launch {
            repository.updateAgentFields(agentId, mapOf("modelId" to modelId))
            repository.addAuditLog("OWNER", "AGENT_MODEL_CHANGED", "تغيير نموذج $agentId إلى $modelId", "INFO")
        }
    }

    fun runStrategyBacktest(strategy: TradingStrategy, symbol: String) {
        if (_isBacktesting.value) return
        viewModelScope.launch {
            _isBacktesting.value = true
            try {
                marketService.fetchCandles(symbol, "1h", 240)
                    .onSuccess { (bars, _) ->
                        val report = BacktestEngine.runWalkForwardBacktest(strategy, symbol, bars)
                        _lastBacktestReport.value = report
                        repository.updateStrategyFields(
                            strategy.id,
                            mapOf(
                                "backtestReturnPct" to report.inSampleReturnPct,
                                "walkForwardReturnPct" to report.walkForwardReturnPct,
                                "outOfSampleWinRate" to report.outOfSampleWinRate,
                                "maxDrawdownPct" to report.maxDrawdownPct,
                                "profitFactor" to report.profitFactor,
                                "feesAndSlippagePct" to report.feesAndSlippagePct
                            )
                        )
                        repository.addAuditLog("Strategy Lab", "BACKTEST_COMPLETED", "${strategy.name} on $symbol -> WF=${"%.2f".format(report.walkForwardReturnPct)}%", "INFO")
                        _bannerMessage.value = report.summaryAr
                    }
                    .onFailure { err ->
                        _bannerMessage.value = "فشل الاختبار التاريخي: ${err.localizedMessage}"
                    }
            } finally {
                _isBacktesting.value = false
            }
        }
    }

    fun approveStrategyForLive(strategy: TradingStrategy, approve: Boolean) {
        viewModelScope.launch {
            if (approve && (strategy.walkForwardReturnPct <= 0.0 || strategy.profitFactor < 1.05)) {
                _bannerMessage.value = "لا يمكن اعتماد استراتيجية للحقيقي قبل اجتياز اختبار Walk-Forward بنجاح!"
                return@launch
            }
            repository.updateStrategyFields(strategy.id, mapOf("approvedForLive" to approve))
            repository.addAuditLog("OWNER", "STRATEGY_LIVE_APPROVAL", "${strategy.name} approvedForLive=$approve", "WARNING")
        }
    }

    fun runCollectiveIntelligenceUpgrade() {
        if (_isCommandRunning.value || _isBacktesting.value) return
        val config = (configState.value as? StreamState.Ready)?.data ?: CompanyConfig(userId = currentUserId)
        viewModelScope.launch {
            _isCommandRunning.value = true
            _commandStatusMessage.value = "جاري تطوير الذكاء الجماعي ودمج الذاكرة التراكمية لجميع الموظفين..."
            try {
                orchestrator.runCollectiveIntelligenceUpgrade(
                    config = config,
                    agents = agentsState.value,
                    closedTrades = tradesState.value.filter { it.status == "CLOSED" },
                    learningLogs = learningLogsState.value,
                    tickers = _liveTickers.value,
                    onStatusUpdate = { _commandStatusMessage.value = it }
                ).onSuccess {
                    _bannerMessage.value = "تم رفع ذكاء (IQ) جميع الموظفين وحفظ القاعدة الذهبية في الذاكرة الجماعية!"
                }.onFailure { err ->
                    _bannerMessage.value = "تعذر تطوير الذكاء الجماعي: ${err.localizedMessage}"
                }
            } finally {
                _isCommandRunning.value = false
                _commandStatusMessage.value = null
            }
        }
    }

    fun runStrictDisciplineAudit() {
        if (_isCommandRunning.value || _isBacktesting.value) return
        val config = (configState.value as? StreamState.Ready)?.data ?: CompanyConfig(userId = currentUserId)
        viewModelScope.launch {
            _isCommandRunning.value = true
            _commandStatusMessage.value = "المفتش حازم ⚖️ يجري تفتيشاً صارماً لأداء وأرباح الموظفين..."
            try {
                orchestrator.runStrictPerformanceAudit(
                    config = config,
                    agents = agentsState.value,
                    openTrades = tradesState.value.filter { it.status == "OPEN" },
                    closedTrades = tradesState.value.filter { it.status == "CLOSED" },
                    learningLogs = learningLogsState.value,
                    ownerInitiated = true,
                    onStatusUpdate = { _commandStatusMessage.value = it }
                ).onSuccess {
                    _bannerMessage.value = "أصدر المفتش حازم ⚖️ التوبيخات العلنية والتوجيهات الحاسمة للمتقاعسين!"
                }.onFailure { err ->
                    _bannerMessage.value = "تعذر تنفيذ التفتيش الصارم: ${err.localizedMessage}"
                }
            } finally {
                _isCommandRunning.value = false
                _commandStatusMessage.value = null
            }
        }
    }

    fun summonUncleSaabForEvaluation() {
        if (_isBacktesting.value) return
        viewModelScope.launch {
            _isBacktesting.value = true
            _commandStatusMessage.value = "HR تستدعي الخبير المخضرم العم صعب 🛡️ لإعداد بطاقة التقييم..."
            try {
                val preset = com.example.model.InitialCompanyRoster.uncleSaabPreset()
                orchestrator.evaluateHrCandidate(
                    nameAr = preset.nameAr,
                    roleAr = preset.roleAr,
                    department = preset.department,
                    specializationNotes = preset.specialization,
                    modelId = preset.modelId,
                    currentAgents = agentsState.value,
                    strategies = strategiesState.value,
                    learningLogs = learningLogsState.value,
                    fixedId = "uncle_saab",
                    onStatusUpdate = { _commandStatusMessage.value = it }
                ).onSuccess { cand ->
                    _bannerMessage.value = "بطاقة تقييم ${cand.nameAr} جاهزة (اختبار ${"%.1f".format(cand.backtestPassRate)}% | IQ ${"%.0f".format(cand.intelligenceScore)}) — اضغط اعتماد التعيين الفوري!"
                }.onFailure { err ->
                    _bannerMessage.value = "تعذر تقييم العم صعب: ${err.localizedMessage}"
                }
            } finally {
                _isBacktesting.value = false
                _commandStatusMessage.value = null
            }
        }
    }

    fun recruitAndTestHrCandidate(
        nameAr: String,
        roleAr: String,
        department: String,
        specialization: String,
        modelId: String
    ) {
        if (_isBacktesting.value) return
        viewModelScope.launch {
            _isBacktesting.value = true
            try {
                orchestrator.evaluateHrCandidate(
                    nameAr = nameAr,
                    roleAr = roleAr,
                    department = department,
                    specializationNotes = specialization,
                    modelId = modelId,
                    currentAgents = agentsState.value,
                    strategies = strategiesState.value,
                    learningLogs = learningLogsState.value,
                    onStatusUpdate = { _commandStatusMessage.value = it }
                ).onSuccess { cand ->
                    _bannerMessage.value = "بطاقة تقييم (${cand.nameAr}) جاهزة في HR: اختبار ${"%.1f".format(cand.backtestPassRate)}% — بانتظار زر التعيين الفوري."
                }.onFailure { err ->
                    _bannerMessage.value = "تعذر تقييم المرشح: ${err.localizedMessage}"
                }
            } finally {
                _isBacktesting.value = false
                _commandStatusMessage.value = null
            }
        }
    }

    fun approveHrCandidate(agentId: String, approve: Boolean) {
        viewModelScope.launch {
            val candidate = agentsState.value.firstOrNull { it.id == agentId }
            if (approve) {
                repository.updateAgentFields(
                    agentId,
                    mapOf(
                        "approvedByOwner" to true,
                        "candidatePending" to false,
                        "blockedByOwner" to false,
                        "status" to AgentStatus.WORKING.label,
                        "currentTask" to "تم التعيين الفوري: باشر عمله ضمن الفريق"
                    )
                )
                repository.addMessage(
                    CorporateMessage(
                        taskId = "onboard_$agentId",
                        senderId = "hr_01",
                        senderName = "د. سارة الناصر (HR)",
                        senderRole = "AI HR Director",
                        recipientId = "ceo_01",
                        channel = "WAR_ROOM",
                        content = "✅ تم اعتماد التعيين الفوري لـ **${candidate?.nameAr ?: agentId}** (${candidate?.roleAr ?: ""}) وانضم مباشرةً للمكتب الافتراضي والمكتب 3D.",
                        evidenceCited = "اعتماد المالك | اختبار ${"%.1f".format(candidate?.backtestPassRate ?: 0.0)}%",
                        decisionReached = "انضمام رسمي لمنظومة QuantCorp AI"
                    )
                )
                repository.addAuditLog("OWNER", "HR_CANDIDATE_APPROVED", "موافقة المالك على التعيين الفوري للموظف ${candidate?.nameAr ?: agentId}", "INFO")
                _bannerMessage.value = "تم التعيين الفوري لـ ${candidate?.nameAr ?: agentId} — ظهر الآن في المكتب والمكتب 3D!"
            } else {
                repository.updateAgentFields(
                    agentId,
                    mapOf(
                        "approvedByOwner" to false,
                        "candidatePending" to false,
                        "blockedByOwner" to true,
                        "status" to AgentStatus.ERROR.label,
                        "currentTask" to "مرفوض من المالك"
                    )
                )
                repository.addAuditLog("OWNER", "HR_CANDIDATE_REJECTED", "رفض تعيين المرشح ${candidate?.nameAr ?: agentId}", "WARNING")
            }
        }
    }

    fun saveAndTestBrokerConnection(creds: BrokerCredentials) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                encryptedVault.saveCredentials(currentUserId, creds)
            }
            _brokerCreds.value = creds
            refreshBrokerAccount()
            repository.addAuditLog("Broker Security Vault", "CONNECTION_TESTED", "Platform=${creds.platform.displayName} Testnet=${creds.useTestnet}", "INFO")
        }
    }

    fun refreshBrokerAccount() {
        viewModelScope.launch {
            val cfg = (configState.value as? StreamState.Ready)?.data ?: CompanyConfig(userId = currentUserId)
            val openPaper = tradesState.value.filter { it.mode == "PAPER" && it.status == "OPEN" }
            val unrealized = computeUnrealized(openPaper, _liveTickers.value)
            val snap = brokerConnector.fetchAccountSnapshot(
                creds = _brokerCreds.value,
                paperBalance = cfg.paperBalance,
                paperOpenCount = openPaper.size,
                paperUnrealizedPnl = unrealized
            )
            _brokerSnapshot.value = snap
        }
    }

    fun clearBanner() {
        _bannerMessage.value = null
    }

    private fun computeUnrealized(openTrades: List<TradeRecord>, tickers: List<MarketTicker>): Double {
        val map = tickers.associateBy { it.symbol }
        return openTrades.sumOf { t ->
            val mark = map[t.symbol]?.lastPrice ?: t.entryPrice
            if (t.side == "BUY") (mark - t.entryPrice) * t.quantity
            else (t.entryPrice - mark) * t.quantity
        }
    }

    private fun computePnlSummary(
        mode: String,
        config: CompanyConfig,
        allTrades: List<TradeRecord>,
        tickers: List<MarketTicker>
    ): PnLSummary {
        val closed = allTrades.filter { it.mode == mode && it.status == "CLOSED" }
        val open = allTrades.filter { it.mode == mode && it.status == "OPEN" }

        val wins = closed.filter { it.realizedPnl > 0.0 }
        val losses = closed.filter { it.realizedPnl < 0.0 }

        val totalProfit = wins.sumOf { it.realizedPnl }
        val totalLoss = losses.sumOf { abs(it.realizedPnl) }
        val totalFees = closed.sumOf { it.feesPaid + it.slippageCost } + open.sumOf { it.feesPaid + it.slippageCost }
        val netRealized = closed.sumOf { it.realizedPnl }
        val unrealized = computeUnrealized(open, tickers)

        val baseCap = if (mode == "LIVE") config.allocatedCapital else 100_000.0
        val balance = if (mode == "LIVE") {
            if (_brokerSnapshot.value.connected && _brokerSnapshot.value.balance > 0.0) _brokerSnapshot.value.balance else config.allocatedCapital + netRealized
        } else {
            config.paperBalance
        }
        val equity = balance + unrealized
        val roiPct = if (baseCap > 0.0) ((equity - baseCap) / baseCap) * 100.0 else 0.0
        val winRate = if (closed.isNotEmpty()) (wins.size.toDouble() / closed.size) * 100.0 else 0.0

        val avgWin = if (wins.isNotEmpty()) totalProfit / wins.size else 0.0
        val avgLoss = if (losses.isNotEmpty()) totalLoss / losses.size else 0.0
        val largestWin = wins.maxOfOrNull { it.realizedPnl } ?: 0.0
        val largestLoss = losses.minOfOrNull { it.realizedPnl } ?: 0.0

        // Equity curve chronologically
        val chrono = closed.reversed()
        val curve = mutableListOf(baseCap)
        var running = baseCap
        var peak = baseCap
        var maxDd = 0.0
        for (t in chrono) {
            running += t.realizedPnl
            curve.add(running)
            peak = max(peak, running)
            val dd = if (peak > 0.0) ((peak - running) / peak) * 100.0 else 0.0
            maxDd = max(maxDd, dd)
        }
        if (open.isNotEmpty()) curve.add(equity)

        return PnLSummary(
            mode = mode,
            totalRealizedProfit = totalProfit,
            totalRealizedLoss = totalLoss,
            totalFeesAndSlippage = totalFees,
            netRealizedProfit = netRealized,
            unrealizedPnl = unrealized,
            balance = balance,
            equity = equity,
            roiPct = roiPct,
            winRatePct = winRate,
            winningTrades = wins.size,
            losingTrades = losses.size,
            avgWin = avgWin,
            avgLoss = avgLoss,
            largestWin = largestWin,
            largestLoss = largestLoss,
            maxDrawdownPct = maxDd,
            equityCurve = curve
        )
    }

    private companion object {
        const val TAG = "CompanyViewModel"
    }
}
