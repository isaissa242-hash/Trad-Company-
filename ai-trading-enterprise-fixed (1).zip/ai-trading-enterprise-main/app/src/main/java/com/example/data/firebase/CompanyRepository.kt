package com.example.data.firebase

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.example.R
import com.example.data.market.TechnicalIndicatorEngine
import com.example.model.AgentProfile
import com.example.model.AgentRankSystem
import com.example.model.AgentStatus
import com.example.model.AuditLog
import com.example.model.CompanyConfig
import com.example.model.CorporateMessage
import com.example.model.CorporateTask
import com.example.model.InitialCompanyRoster
import com.example.model.LearningLog
import com.example.model.TradeRecord
import com.example.model.TradingStrategy
import com.example.model.formatUsdCents
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.firestoreSettings
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

class CompanyRepository {
    private val auth: FirebaseAuth
    private val appContext: Context?

    @Volatile
    private var cachedDb: FirebaseFirestore?
    private val dbMutex = Mutex()

    constructor(
        db: FirebaseFirestore,
        auth: FirebaseAuth = Firebase.auth,
        appContext: Context? = null
    ) {
        this.cachedDb = db
        this.auth = auth
        this.appContext = appContext
    }

    constructor(context: Context) {
        this.cachedDb = null
        this.auth = Firebase.auth
        this.appContext = context.applicationContext
    }

    private suspend fun resolveDb(): FirebaseFirestore {
        cachedDb?.let { return it }
        return dbMutex.withLock {
            cachedDb?.let { return it }
            val ctx = appContext
                ?: throw IllegalStateException("Application context missing for Firestore initialization.")
            withContext(Dispatchers.IO) {
                createConfiguredFirestore(ctx)
            }.also { cachedDb = it }
        }
    }

    companion object {
        private fun createConfiguredFirestore(appContext: Context): FirebaseFirestore {
            val instance = FirebaseFirestore.getInstance(
                appContext.getString(R.string.firestore_database_id)
            )
            try {
                instance.firestoreSettings = firestoreSettings {
                    setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                }
            } catch (_: IllegalStateException) {
                // Persistence settings were already locked after initial Firestore use
            }
            return instance
        }
    }

    fun observeNetworkOnline(): Flow<Boolean> = callbackFlow {
        val ctx = appContext
        val cm = ctx?.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm == null) {
            trySend(true)
            close()
            return@callbackFlow
        }

        fun checkCurrent(): Boolean {
            val active = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(active) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }

        trySend(checkCurrent())

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(true)
            }

            override fun onLost(network: Network) {
                trySend(checkCurrent())
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                trySend(networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
            }
        }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching { cm.registerNetworkCallback(request, callback) }
        awaitClose { runCatching { cm.unregisterNetworkCallback(callback) } }
    }.distinctUntilChanged().flowOn(Dispatchers.IO)

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول بحساب Google قبل الوصول إلى بيانات الشركة.")

    private fun userRoot(firestore: FirebaseFirestore, uid: String) =
        firestore.collection("users").document(uid)

    private fun <T> safeSnapshotError(error: Throwable, op: OperationType, path: String, uid: String): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
        throw error
    }

    suspend fun ensureCompanyInitialized(): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val rootPath = "users/$uid"
        return try {
            val firestore = resolveDb()
            val configRef = userRoot(firestore, uid).collection("company_state").document("config")
            val configSnap = configRef.get().await()
            val configUpdates = mutableMapOf<String, Any>()
            if (!configSnap.exists()) {
                val defaultConfig = CompanyConfig(userId = uid)
                configRef.set(defaultConfig.toCreateMap(uid)).await()
            } else {
                if (!configSnap.contains("cloudEngineEnabled")) {
                    configUpdates["cloudEngineEnabled"] = false
                    configUpdates["executionLocation"] = "LOCAL"
                    configUpdates["cloudEngineStatus"] = "STANDBY"
                    configUpdates["cloudLastHeartbeatMillis"] = 0L
                    configUpdates["cloudLastSummary"] = ""
                }
                if (!configSnap.contains("profitTargetUsd")) {
                    configUpdates["profitTargetUsd"] = 0.0
                    configUpdates["profitTargetBaselinePnl"] = 0.0
                }
                if (!configSnap.contains("safetyVaultBalance")) {
                    configUpdates["safetyVaultBalance"] = 0.0
                    configUpdates["safetyVaultTotalDeposited"] = 0.0
                    configUpdates["safetyVaultAllocationPct"] = 10.0
                }
                if (!configSnap.contains("sniperEnabled")) {
                    configUpdates["sniperEnabled"] = true
                }
                if (configUpdates.isNotEmpty()) {
                    configUpdates["updatedAt"] = FieldValue.serverTimestamp()
                    configRef.update(configUpdates).await()
                }
            }

            val agentsSnap = userRoot(firestore, uid).collection("agents").get().await()
            if (agentsSnap.isEmpty) {
                val batch = firestore.batch()
                InitialCompanyRoster.defaultAgents(uid).forEach { (agentId, profile) ->
                    val ref = userRoot(firestore, uid).collection("agents").document(agentId)
                    batch.set(ref, profile.toCreateMap(uid))
                }
                InitialCompanyRoster.defaultStrategies(uid).forEach { (stratId, strat) ->
                    val ref = userRoot(firestore, uid).collection("strategies").document(stratId)
                    batch.set(ref, strat.toCreateMap(uid))
                }
                val welcomeMsgRef = userRoot(firestore, uid).collection("messages").document("msg_welcome_01")
                val welcomeMsg = CorporateMessage(
                    userId = uid,
                    taskId = "init_01",
                    senderId = "ceo_01",
                    senderName = "د. طارق المنصور (CEO)",
                    senderRole = "الرئيس التنفيذي",
                    recipientId = "OWNER",
                    channel = "CEO_OWNER",
                    content = "مرحباً بك يا مالك الشركة في مقر QuantCorp AI. جميع الإدارات والفريق بما فيهم القناص 🎯 يعملون بالتحليل الحي المستقبلي وليس بالبيانات القديمة. يتم تحويل 10% من صافي أرباح كل صفقة رابحة تلقائياً إلى خزنة أمان الشركة (لا تُسحب إلا بتدخلك الشخصي)، والترقيات تُمنح حصراً مقابل الربح الفعلي.",
                    evidenceCited = "جاهزية 12 وكيل ذكاء اصطناعي (بينهم القناص 🎯) + خزنة الأمان 10% + نظام ترقيات بالربح فقط",
                    decisionReached = "بدء التشغيل المؤسسي الآمن"
                )
                batch.set(welcomeMsgRef, welcomeMsg.toCreateMap(uid))
                batch.commit().await()
            } else {
                val existingIds = agentsSnap.documents.map { it.id }.toSet()
                val missingDefaultAgents = InitialCompanyRoster.defaultAgents(uid).filter { (id, _) -> id !in existingIds }
                val missingFieldsDocs = agentsSnap.documents.filter {
                    !it.contains("rankXp") || !it.contains("rankLevel") || !it.contains("totalProfitGeneratedUsd") ||
                        !it.contains("intelligenceScore") || !it.contains("reprimandsCount") ||
                        !it.contains("lastReprimandReason") || !it.contains("candidateExpertise") ||
                        !it.contains("candidateCompanyBenefit")
                }
                if (missingDefaultAgents.isNotEmpty() || missingFieldsDocs.isNotEmpty()) {
                    val patchBatch = firestore.batch()
                    missingDefaultAgents.forEach { (agentId, profile) ->
                        val ref = userRoot(firestore, uid).collection("agents").document(agentId)
                        patchBatch.set(ref, profile.toCreateMap(uid))
                    }
                    missingFieldsDocs.forEach { doc ->
                        val wins = (doc.getLong("successfulWinsCount") ?: 0L).coerceAtLeast(0L)
                        val existingXp = if (wins > 0L) (doc.getLong("rankXp") ?: 0L).coerceAtLeast(0L) else 0L
                        val rankInfo = AgentRankSystem.evaluate(existingXp)
                        patchBatch.update(
                            doc.reference,
                            mapOf(
                                "rankXp" to existingXp,
                                "rankLevel" to rankInfo.level.toLong(),
                                "successfulWinsCount" to wins,
                                "totalProfitGeneratedUsd" to (doc.getDouble("totalProfitGeneratedUsd") ?: 0.0),
                                "intelligenceScore" to (doc.getDouble("intelligenceScore") ?: 105.0).coerceIn(0.0, 500.0),
                                "reprimandsCount" to (doc.getLong("reprimandsCount") ?: 0L).coerceAtLeast(0L),
                                "lastReprimandReason" to (doc.getString("lastReprimandReason") ?: ""),
                                "candidateExpertise" to (doc.getString("candidateExpertise") ?: ""),
                                "candidateCompanyBenefit" to (doc.getString("candidateCompanyBenefit") ?: ""),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    patchBatch.commit().await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, rootPath)
            Result.failure(e)
        }
    }

    fun observeConfig(): Flow<CompanyConfig> = flow {
        val uid = requireUserId()
        val path = "users/$uid/company_state/config"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("company_state").document("config")
                .snapshots()
                .map { snap ->
                    snap.toObject(CompanyConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?: CompanyConfig(userId = uid)
                }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.GET, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    fun observeAgents(): Flow<List<AgentProfile>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/agents"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("agents")
                .snapshots()
                .map { snap ->
                    snap.toObjects(AgentProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.department }
                }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.LIST, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    fun observeTasks(): Flow<List<CorporateTask>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/tasks"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("tasks")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(40)
                .snapshots()
                .map { snap -> snap.toObjects(CorporateTask::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.LIST, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    fun observeMessages(): Flow<List<CorporateMessage>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/messages"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .limitToLast(150)
                .snapshots()
                .map { snap -> snap.toObjects(CorporateMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.LIST, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    fun observeStrategies(): Flow<List<TradingStrategy>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/strategies"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("strategies")
                .snapshots()
                .map { snap -> snap.toObjects(TradingStrategy::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.LIST, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    fun observeTrades(): Flow<List<TradeRecord>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/trades"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("trades")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(200)
                .snapshots()
                .map { snap -> snap.toObjects(TradeRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.LIST, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    fun observeLearningLogs(): Flow<List<LearningLog>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/learning_logs"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("learning_logs")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(100)
                .snapshots()
                .map { snap -> snap.toObjects(LearningLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.LIST, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    fun observeAuditLogs(): Flow<List<AuditLog>> = flow {
        val uid = requireUserId()
        val path = "users/$uid/audit_logs"
        val firestore = resolveDb()
        emitAll(
            userRoot(firestore, uid).collection("audit_logs")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(100)
                .snapshots()
                .map { snap -> snap.toObjects(AuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error -> safeSnapshotError<Unit>(error, OperationType.LIST, path, uid) }
        )
    }.flowOn(Dispatchers.Default)

    suspend fun updateConfigFields(fields: Map<String, Any>): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val path = "users/$uid/company_state/config"
        return try {
            val firestore = resolveDb()
            val payload = fields.toMutableMap().apply {
                put("updatedAt", FieldValue.serverTimestamp())
            }
            userRoot(firestore, uid).collection("company_state").document("config").update(payload).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateAgentStatus(agentId: String, status: String, currentTask: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val path = "users/$uid/agents/$agentId"
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("agents").document(agentId).update(
                mapOf(
                    "status" to status.take(30),
                    "currentTask" to currentTask.take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateAgentFields(agentId: String, fields: Map<String, Any>): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val path = "users/$uid/agents/$agentId"
        return try {
            val firestore = resolveDb()
            val payload = fields.toMutableMap().apply { put("updatedAt", FieldValue.serverTimestamp()) }
            userRoot(firestore, uid).collection("agents").document(agentId).update(payload).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun recordAgentTaskCompletionOnly(
        agent: AgentProfile,
        newStatus: String? = null,
        currentTaskText: String? = null,
        iqGain: Double = 0.8
    ): Result<Unit> {
        val nextIq = (agent.intelligenceScore + iqGain).coerceIn(50.0, 500.0)
        val fields = mutableMapOf<String, Any>(
            "tasksCompleted" to (agent.tasksCompleted + 1L),
            "intelligenceScore" to nextIq
        )
        if (newStatus != null) fields["status"] = newStatus.take(30)
        if (currentTaskText != null) fields["currentTask"] = currentTaskText.take(500)
        return updateAgentFields(agent.id, fields)
    }

    /**
     * Strictly profit-gated badge & rank promotion:
     * XP, wins, and promotions are ONLY granted when realizedProfitUsd > 0.0.
     * Also compounds the employee's Intelligence & Mastery IQ score.
     */
    suspend fun awardProfitPromotion(
        agent: AgentProfile,
        realizedProfitUsd: Double,
        roleShare: Double = 1.0,
        incrementTaskCount: Boolean = false,
        incrementWinCount: Boolean = true,
        newStatus: String? = null,
        currentTaskText: String? = null,
        reasonAr: String = ""
    ): Result<AgentProfile> {
        auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        if (realizedProfitUsd <= 0.0) {
            return Result.success(agent)
        }
        val xpDelta = AgentRankSystem.calculateProfitXp(realizedProfitUsd, roleShare)
        if (xpDelta <= 0L) {
            return Result.success(agent)
        }

        val prevLevel = AgentRankSystem.evaluateAgent(agent).level
        val (newXp, newLevel) = AgentRankSystem.applyXpDelta(agent.rankXp, xpDelta)
        val updatedTasks = agent.tasksCompleted + if (incrementTaskCount) 1L else 0L
        val updatedWins = agent.successfulWinsCount + if (incrementWinCount) 1L else 0L
        val updatedProfit = agent.totalProfitGeneratedUsd + (realizedProfitUsd * roleShare)
        val updatedIq = (agent.intelligenceScore + (3.5 * roleShare).coerceAtLeast(1.0)).coerceIn(50.0, 500.0)
        val updatedPerf = (agent.performanceScore + 1.2).coerceIn(0.0, 100.0)

        val fields = mutableMapOf<String, Any>(
            "rankXp" to newXp,
            "rankLevel" to newLevel,
            "tasksCompleted" to updatedTasks,
            "successfulWinsCount" to updatedWins,
            "totalProfitGeneratedUsd" to updatedProfit,
            "intelligenceScore" to updatedIq,
            "performanceScore" to updatedPerf
        )
        if (newStatus != null) fields["status"] = newStatus.take(30)
        if (currentTaskText != null) fields["currentTask"] = currentTaskText.take(500)

        return updateAgentFields(agent.id, fields).map {
            val newInfo = AgentRankSystem.evaluate(newXp)
            if (newLevel > prevLevel) {
                addAuditLog(
                    actor = "AI HR • نظام الترقيات",
                    actionType = "AGENT_PROMOTED_BY_PROFIT",
                    details = "تمت ترقية ${agent.nameAr} إلى المستوى ${newInfo.level} (${newInfo.badge} ${newInfo.titleAr}) مقابل ربح فعلي محقّق${if (reasonAr.isNotBlank()) " — $reasonAr" else ""}",
                    severity = "INFO"
                )
            }
            agent.copy(
                rankXp = newXp,
                rankLevel = newLevel,
                tasksCompleted = updatedTasks,
                successfulWinsCount = updatedWins,
                totalProfitGeneratedUsd = updatedProfit,
                intelligenceScore = updatedIq,
                performanceScore = updatedPerf,
                status = newStatus ?: agent.status,
                currentTask = currentTaskText ?: agent.currentTask
            )
        }
    }

    suspend fun upgradeCollectiveTeamIntelligence(
        agents: List<AgentProfile>,
        iqDelta: Double = 3.5,
        statusNote: String = "تم استيعاب قواعد الذكاء الجديدة وتحديث الخبرة"
    ): Result<Int> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val active = agents.filter { it.approvedByOwner && !it.candidatePending && !it.blockedByOwner }
        if (active.isEmpty()) return Result.success(0)
        return try {
            val firestore = resolveDb()
            val batch = firestore.batch()
            active.forEach { ag ->
                val ref = userRoot(firestore, uid).collection("agents").document(ag.id)
                val nextIq = (ag.intelligenceScore + iqDelta).coerceIn(50.0, 500.0)
                val nextConf = (ag.confidenceScore + 1.5).coerceIn(0.0, 100.0)
                batch.update(
                    ref,
                    mapOf(
                        "intelligenceScore" to nextIq,
                        "confidenceScore" to nextConf,
                        "currentTask" to statusNote.take(500),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(active.size)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid/agents")
            Result.failure(e)
        }
    }

    suspend fun applyStrictDisciplineReprimand(
        agent: AgentProfile,
        xpPenalty: Long = 15L,
        reprimandReason: String,
        enforcedTask: String
    ): Result<AgentProfile> {
        auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val safePenalty = kotlin.math.abs(xpPenalty)
        val (newXp, newLevel) = AgentRankSystem.applyXpDelta(agent.rankXp, -safePenalty)
        val nextReprimands = agent.reprimandsCount + 1L
        val nextPerf = (agent.performanceScore - 4.0).coerceIn(40.0, 100.0)
        val bubbleTask = "⚠️ توبيخ مشدّد: $enforcedTask".take(500)
        return updateAgentFields(
            agent.id,
            mapOf(
                "rankXp" to newXp,
                "rankLevel" to newLevel,
                "reprimandsCount" to nextReprimands,
                "lastReprimandReason" to reprimandReason.take(500),
                "performanceScore" to nextPerf,
                "status" to AgentStatus.REVIEWING.label,
                "currentTask" to bubbleTask
            )
        ).map {
            agent.copy(
                rankXp = newXp,
                rankLevel = newLevel,
                reprimandsCount = nextReprimands,
                lastReprimandReason = reprimandReason.take(500),
                performanceScore = nextPerf,
                status = AgentStatus.REVIEWING.label,
                currentTask = bubbleTask
            )
        }
    }

    suspend fun penalizeExecutionError(
        agent: AgentProfile,
        xpPenalty: Long = 10L,
        reasonAr: String = ""
    ): Result<AgentProfile> {
        auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val safePenalty = kotlin.math.abs(xpPenalty)
        val (newXp, newLevel) = AgentRankSystem.applyXpDelta(agent.rankXp, -safePenalty)
        return updateAgentFields(
            agent.id,
            mapOf("rankXp" to newXp, "rankLevel" to newLevel)
        ).map {
            if (reasonAr.isNotBlank()) {
                addAuditLog(
                    actor = "AI HR • مراجعة الأخطاء",
                    actionType = "AGENT_XP_DEDUCTED",
                    details = "خصم $safePenalty XP من ${agent.nameAr}: $reasonAr",
                    severity = "WARNING"
                )
            }
            agent.copy(rankXp = newXp, rankLevel = newLevel)
        }
    }

    suspend fun createAgent(agentId: String, agent: AgentProfile): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val safeId = agentId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(100)
        val path = "users/$uid/agents/$safeId"
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("agents").document(safeId).set(agent.toCreateMap(uid)).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun createTask(task: CorporateTask): Result<String> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val docId = "task_${UUID.randomUUID().toString().take(12).replace("-", "")}"
        val path = "users/$uid/tasks/$docId"
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("tasks").document(docId).set(task.toCreateMap(uid)).awaitWriteOrQueue()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateTask(taskId: String, fields: Map<String, Any>): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val path = "users/$uid/tasks/$taskId"
        return try {
            val firestore = resolveDb()
            val payload = fields.toMutableMap().apply { put("updatedAt", FieldValue.serverTimestamp()) }
            userRoot(firestore, uid).collection("tasks").document(taskId).update(payload).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun addMessage(message: CorporateMessage): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val docId = "msg_${UUID.randomUUID().toString().take(12).replace("-", "")}"
        val path = "users/$uid/messages/$docId"
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("messages").document(docId).set(message.toCreateMap(uid)).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun createStrategy(strategy: TradingStrategy): Result<String> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val docId = "strat_${UUID.randomUUID().toString().take(12).replace("-", "")}"
        val path = "users/$uid/strategies/$docId"
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("strategies").document(docId).set(strategy.toCreateMap(uid)).awaitWriteOrQueue()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateStrategyFields(strategyId: String, fields: Map<String, Any>): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val path = "users/$uid/strategies/$strategyId"
        return try {
            val firestore = resolveDb()
            val payload = fields.toMutableMap().apply { put("updatedAt", FieldValue.serverTimestamp()) }
            userRoot(firestore, uid).collection("strategies").document(strategyId).update(payload).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun createTrade(trade: TradeRecord): Result<String> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val docId = "trd_${UUID.randomUUID().toString().take(12).replace("-", "")}"
        val path = "users/$uid/trades/$docId"
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("trades").document(docId).set(trade.toCreateMap(uid)).awaitWriteOrQueue()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun closeTrade(
        tradeId: String,
        exitPrice: Double,
        feesPaid: Double,
        slippageCost: Double,
        realizedPnl: Double
    ): Result<Boolean> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        if (tradeId.isBlank()) return Result.success(false)
        val path = "users/$uid/trades/$tradeId"
        return try {
            val firestore = resolveDb()
            val tradeRef = userRoot(firestore, uid).collection("trades").document(tradeId)
            val closedNow = firestore.runTransaction { tx ->
                val snap = tx.get(tradeRef)
                if (!snap.exists() || snap.getString("status") != "OPEN") {
                    false
                } else {
                    tx.update(
                        tradeRef,
                        mapOf(
                            "status" to "CLOSED",
                            "exitPrice" to exitPrice.coerceAtLeast(0.0),
                            "feesPaid" to feesPaid.coerceAtLeast(0.0),
                            "slippageCost" to slippageCost.coerceAtLeast(0.0),
                            "realizedPnl" to realizedPnl,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    true
                }
            }.await()
            Result.success(closedNow)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    /**
     * Atomically settles closed trade P&L into company treasury:
     * - Automatically locks 10% (safetyVaultAllocationPct) of every net positive profit into the Safety Vault.
     * - Credits remaining 90% (or full loss, floored at 0) to operational paperBalance in PAPER mode.
     * - Safety Vault reserve can NEVER decrease here (bankruptcy shield).
     */
    suspend fun applyTradeSettlementToTreasury(
        mode: String,
        realizedNetPnl: Double,
        tradeId: String,
        symbol: String
    ): Result<Double> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val path = "users/$uid/company_state/config"
        return try {
            val firestore = resolveDb()
            val configRef = userRoot(firestore, uid).collection("company_state").document("config")
            val vaultDeposit = firestore.runTransaction { tx ->
                val snap = tx.get(configRef)
                val currentBalance = (snap.getDouble("paperBalance") ?: 100_000.0).coerceAtLeast(0.0)
                val currentVault = (snap.getDouble("safetyVaultBalance") ?: 0.0).coerceAtLeast(0.0)
                val currentDeposited = (snap.getDouble("safetyVaultTotalDeposited") ?: 0.0).coerceAtLeast(0.0)
                val allocPct = (snap.getDouble("safetyVaultAllocationPct") ?: 10.0).coerceIn(0.0, 50.0)

                val lockedToVault = TechnicalIndicatorEngine.calculateVaultDepositUsd(realizedNetPnl, allocPct)
                val newVault = currentVault + lockedToVault
                val newDeposited = currentDeposited + lockedToVault

                val updates = mutableMapOf<String, Any>(
                    "safetyVaultBalance" to newVault,
                    "safetyVaultTotalDeposited" to newDeposited,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (mode == "PAPER") {
                    val activeDelta = realizedNetPnl - lockedToVault
                    updates["paperBalance"] = (currentBalance + activeDelta).coerceAtLeast(0.0)
                }
                tx.update(configRef, updates)
                lockedToVault
            }.await()

            if (vaultDeposit > 0.0) {
                addAuditLog(
                    actor = "خزنة الأمان (10% Auto-Lock)",
                    actionType = "SAFETY_VAULT_DEPOSIT",
                    details = "تم تأمين ${formatUsdCents(vaultDeposit)} (10% من صافي ربح $symbol في الصفقة $tradeId) داخل خزنة أمان الشركة.",
                    severity = "INFO"
                )
            }
            Result.success(vaultDeposit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    /**
     * Strictly Owner-Only Personal Intervention Withdrawal from the Company Safety Vault.
     * No AI agent or autonomous task can invoke this operation.
     */
    suspend fun withdrawFromSafetyVaultByOwner(
        amountUsd: Double,
        returnToTradingCapital: Boolean,
        ownerReason: String
    ): Result<Double> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        if (amountUsd <= 0.0) return Result.failure(IllegalArgumentException("مبلغ السحب يجب أن يكون أكبر من صفر."))
        val path = "users/$uid/company_state/config"
        return try {
            val firestore = resolveDb()
            val configRef = userRoot(firestore, uid).collection("company_state").document("config")
            val withdrawn = firestore.runTransaction { tx ->
                val snap = tx.get(configRef)
                val currentVault = (snap.getDouble("safetyVaultBalance") ?: 0.0).coerceAtLeast(0.0)
                val currentBalance = (snap.getDouble("paperBalance") ?: 100_000.0).coerceAtLeast(0.0)
                if (amountUsd > currentVault + 0.0001) {
                    throw IllegalStateException("المبلغ المطلوب يتجاوز رصيد خزنة الأمان (${formatUsdCents(currentVault)}).")
                }
                val actual = amountUsd.coerceAtMost(currentVault)
                val newVault = (currentVault - actual).coerceAtLeast(0.0)
                val updates = mutableMapOf<String, Any>(
                    "safetyVaultBalance" to newVault,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (returnToTradingCapital) {
                    updates["paperBalance"] = currentBalance + actual
                }
                tx.update(configRef, updates)
                actual
            }.await()

            val modeDesc = if (returnToTradingCapital) "إعادة ضخ إلى رأس مال التداول" else "سحب شخصي للمالك خارج المحفظة"
            addAuditLog(
                actor = "OWNER (تدخل شخصي)",
                actionType = "SAFETY_VAULT_OWNER_WITHDRAWAL",
                details = "سحب المالك شخصياً ${formatUsdCents(withdrawn)} من خزنة الأمان ($modeDesc) — السبب: ${ownerReason.ifBlank { "قرار شخصي للمالك" }}",
                severity = "CRITICAL"
            )
            Result.success(withdrawn)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun addLearningLog(log: LearningLog): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val docId = "lrn_${UUID.randomUUID().toString().take(12).replace("-", "")}"
        val path = "users/$uid/learning_logs/$docId"
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("learning_logs").document(docId).set(log.toCreateMap(uid)).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun addAuditLog(actor: String, actionType: String, details: String, severity: String = "INFO"): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Unauthenticated"))
        val docId = "aud_${UUID.randomUUID().toString().take(12).replace("-", "")}"
        val path = "users/$uid/audit_logs/$docId"
        val log = AuditLog(userId = uid, actor = actor, actionType = actionType, details = details, severity = severity)
        return try {
            val firestore = resolveDb()
            userRoot(firestore, uid).collection("audit_logs").document(docId).set(log.toCreateMap(uid)).awaitWriteOrQueue()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }
}

/** Max time to wait for the server to acknowledge a Firestore write before treating it as "queued locally". */
private const val WRITE_ACK_TIMEOUT_MS = 8_000L

/**
 * Firestore write Tasks only complete after the SERVER acknowledges them. With persistent
 * offline cache enabled, a weak/absent connection therefore makes a plain `.await()` hang
 * forever, which froze the whole CEO command pipeline (the command "stops" and the send
 * button spins indefinitely). The write is already applied to the local cache and queued
 * for sync, so after the timeout we simply continue.
 */
private suspend fun <T> Task<T>.awaitWriteOrQueue(timeoutMs: Long = WRITE_ACK_TIMEOUT_MS) {
    val task = this
    withTimeoutOrNull(timeoutMs) { task.await() }
}
