package com.example.data.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * An owner order that has been accepted by the app but not yet fully handled by the CEO.
 *
 * @property attempts how many times the order has been sent to the CEO pipeline so far.
 * @property failed   automatic retries are exhausted (or it is too old): waits for the owner's decision.
 * @property inFlight an attempt was started and its outcome was never recorded (e.g. the app was
 *                    killed mid-run). Such an order may already have had side effects, so it is
 *                    never re-run automatically.
 */
data class PendingOwnerCommand(
    val id: String,
    val text: String,
    val createdAtMs: Long,
    val attempts: Int = 0,
    val failed: Boolean = false,
    val inFlight: Boolean = false,
    val lastError: String = ""
)

/**
 * Tiny durable outbox (SharedPreferences) so an order typed once is never lost: not on server
 * overload, not on a network drop and not when Android kills the process.
 */
class CommandOutbox(context: Context?, userId: String) {

    private val prefs = context?.applicationContext
        ?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val key = "pending_${userId.take(64)}"

    fun load(): List<PendingOwnerCommand> {
        val raw = prefs?.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val text = o.optString("text", "")
                if (text.isBlank()) {
                    null
                } else {
                    PendingOwnerCommand(
                        id = o.optString("id", "cmd_$i"),
                        text = text,
                        createdAtMs = o.optLong("createdAtMs", 0L),
                        attempts = o.optInt("attempts", 0),
                        failed = o.optBoolean("failed", false),
                        inFlight = o.optBoolean("inFlight", false),
                        lastError = o.optString("lastError", "")
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(items: List<PendingOwnerCommand>) {
        val store = prefs ?: return
        val arr = JSONArray()
        items.takeLast(MAX_ITEMS).forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("text", c.text)
                    .put("createdAtMs", c.createdAtMs)
                    .put("attempts", c.attempts)
                    .put("failed", c.failed)
                    .put("inFlight", c.inFlight)
                    .put("lastError", c.lastError.take(300))
            )
        }
        store.edit().putString(key, arr.toString()).apply()
    }

    private companion object {
        const val PREFS_NAME = "quantcorp_command_outbox"
        const val MAX_ITEMS = 25
    }
}
