package com.example.model

import java.util.Locale
import kotlin.math.abs

data class AgentRankTier(
    val level: Int,
    val badge: String,
    val titleAr: String,
    val minXp: Long
)

data class AgentRankInfo(
    val level: Int,
    val badge: String,
    val titleAr: String,
    val currentXp: Long,
    val currentTierMinXp: Long,
    val nextTierXp: Long?,
    val nextBadge: String?,
    val progressToNext: Float,
    val xpRemainingForNext: Long,
    val isMaxRank: Boolean
)

/**
 * Formats USD amounts with exact 2-decimal cent precision in US numerals
 * so every single cent ($0.01) is clearly visible across all screens.
 */
fun formatUsdCents(amount: Double, signed: Boolean = false): String {
    val safe = if (amount.isNaN() || amount.isInfinite()) 0.0 else amount
    val prefix = when {
        signed && safe > 0.00001 -> "+$"
        signed && safe < -0.00001 -> "-$"
        !signed && safe < 0.0 -> "-$"
        else -> "$"
    }
    return prefix + String.format(Locale.US, "%,.2f", abs(safe))
}

object AgentRankSystem {

    val tiers: List<AgentRankTier> = listOf(
        AgentRankTier(level = 1, badge = "⭐", titleAr = "نجمة واحدة • مبتدئ تداول", minXp = 0L),
        AgentRankTier(level = 2, badge = "⭐⭐", titleAr = "نجمتان • محلل متمرس", minXp = 50L),
        AgentRankTier(level = 3, badge = "⭐⭐⭐", titleAr = "ثلاث نجمات • محلل معتمد", minXp = 120L),
        AgentRankTier(level = 4, badge = "🦅", titleAr = "نسر واحد • قناص الفرص", minXp = 220L),
        AgentRankTier(level = 5, badge = "🦅🦅", titleAr = "نسران • خبير استراتيجي", minXp = 350L),
        AgentRankTier(level = 6, badge = "🦅🦅🦅", titleAr = "ثلاثة نسور • قائد قسم", minXp = 520L),
        AgentRankTier(level = 7, badge = "⚔️", titleAr = "سيف • مبارز الأسواق", minXp = 740L),
        AgentRankTier(level = 8, badge = "⚔️⚔️", titleAr = "سيفان • تكتيكي نخبوي", minXp = 1000L),
        AgentRankTier(level = 9, badge = "⚔️⚔️⚔️", titleAr = "ثلاثة سيوف • أسطورة المؤسسة", minXp = 1350L),
        AgentRankTier(level = 10, badge = "🐋", titleAr = "شارة الحوت • رتبة حوت السوق", minXp = 1800L)
    )

    fun evaluate(rankXp: Long): AgentRankInfo {
        val safeXp = rankXp.coerceAtLeast(0L)
        val tierIndex = tiers.indexOfLast { safeXp >= it.minXp }.coerceAtLeast(0)
        val current = tiers[tierIndex]
        val next = tiers.getOrNull(tierIndex + 1)

        if (next == null) {
            return AgentRankInfo(
                level = current.level,
                badge = current.badge,
                titleAr = current.titleAr,
                currentXp = safeXp,
                currentTierMinXp = current.minXp,
                nextTierXp = null,
                nextBadge = null,
                progressToNext = 1f,
                xpRemainingForNext = 0L,
                isMaxRank = true
            )
        }

        val span = (next.minXp - current.minXp).coerceAtLeast(1L)
        val gainedInTier = (safeXp - current.minXp).coerceIn(0L, span)
        val progress = (gainedInTier.toFloat() / span.toFloat()).coerceIn(0f, 1f)
        val remaining = (next.minXp - safeXp).coerceAtLeast(0L)

        return AgentRankInfo(
            level = current.level,
            badge = current.badge,
            titleAr = current.titleAr,
            currentXp = safeXp,
            currentTierMinXp = current.minXp,
            nextTierXp = next.minXp,
            nextBadge = next.badge,
            progressToNext = progress,
            xpRemainingForNext = remaining,
            isMaxRank = false
        )
    }

    fun evaluateAgent(agent: AgentProfile): AgentRankInfo {
        val effectiveXp = maxOf(
            agent.rankXp.coerceAtLeast(0L),
            tiers.firstOrNull { it.level == agent.rankLevel.toInt() }?.minXp ?: 0L
        )
        return evaluate(effectiveXp)
    }

    /**
     * Strictly profit-gated XP calculation:
     * Badges & promotions are awarded ONLY when a trade generates real positive net profit (> $0.00).
     * Non-profitable or losing outcomes earn 0 XP.
     */
    fun calculateProfitXp(netProfitUsd: Double, roleShare: Double = 1.0): Long {
        if (netProfitUsd <= 0.0 || roleShare <= 0.0) return 0L
        val rawXp = (netProfitUsd * 0.30).toLong().coerceIn(15L, 300L)
        return (rawXp * roleShare).toLong().coerceAtLeast(5L)
    }

    fun applyXpDelta(currentXp: Long, delta: Long): Pair<Long, Long> {
        val updatedXp = (currentXp + delta).coerceAtLeast(0L)
        val updatedLevel = evaluate(updatedXp).level.toLong()
        return updatedXp to updatedLevel
    }
}
