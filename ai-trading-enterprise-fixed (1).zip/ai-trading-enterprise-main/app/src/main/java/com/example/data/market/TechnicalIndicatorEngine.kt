package com.example.data.market

import com.example.model.CandleBar
import com.example.model.SniperEvidenceCheck
import com.example.model.SniperSetupReport
import com.example.model.TechnicalSnapshot
import com.example.model.formatUsdCents
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.math.sqrt

/**
 * Pure quantitative indicator calculator & forward-looking Sniper confluence evaluator
 * operating strictly on real fetched multi-timeframe OHLCV bars and orderbook liquidity.
 */
object TechnicalIndicatorEngine {

    fun calculateVaultDepositUsd(netProfitUsd: Double, allocationPct: Double = 10.0): Double {
        if (netProfitUsd <= 0.0 || allocationPct <= 0.0) return 0.0
        val pct = allocationPct.coerceIn(0.0, 50.0)
        val rawCents = ((netProfitUsd * (pct / 100.0)) * 100.0).roundToLong()
        return (rawCents / 100.0).coerceIn(0.0, netProfitUsd)
    }

    fun analyze(
        symbol: String,
        timeframe: String,
        bars: List<CandleBar>,
        orderbookBidAskRatio: Double,
        source: String
    ): TechnicalSnapshot {
        require(bars.size >= 30) { "Insufficient candle history (${bars.size} bars) for $symbol" }
        val closes = bars.map { it.close }
        val currentPrice = closes.last()
        val ema20 = ema(closes, 20)
        val ema50 = ema(closes, minOf(50, closes.size))
        val rsi14 = rsi(closes, 14)
        val atr14 = atr(bars, 14)

        val recent20 = closes.takeLast(20)
        val mean20 = recent20.average()
        val std20 = sqrt(recent20.sumOf { (it - mean20).pow(2) } / recent20.size)
        val bbUpper = mean20 + 2.0 * std20
        val bbLower = mean20 - 2.0 * std20

        val lookback = bars.takeLast(30)
        val support = lookback.minOf { it.low }
        val resistance = lookback.maxOf { it.high }

        val avgVol = bars.takeLast(21).dropLast(1).map { it.volume }.average().coerceAtLeast(1e-9)
        val volumeSpikeRatio = bars.last().volume / avgVol

        val trendBias = when {
            currentPrice > ema20 && ema20 > ema50 -> "BULLISH"
            currentPrice < ema20 && ema20 < ema50 -> "BEARISH"
            else -> "NEUTRAL"
        }

        return TechnicalSnapshot(
            symbol = symbol,
            timeframe = timeframe,
            currentPrice = currentPrice,
            ema20 = ema20,
            ema50 = ema50,
            rsi14 = rsi14,
            atr14 = atr14,
            bollingerUpper = bbUpper,
            bollingerLower = bbLower,
            supportLevel = support,
            resistanceLevel = resistance,
            volumeSpikeRatio = volumeSpikeRatio,
            orderbookBidAskRatio = orderbookBidAskRatio,
            trendBias = trendBias,
            fetchedAtMillis = System.currentTimeMillis(),
            source = source
        )
    }

    /**
     * Evaluates forward-looking multi-timeframe confluence across 15m (execution flow),
     * 1h (tactical structure), and 4h (macro direction) + live orderbook imbalance.
     * Achieves 100% (5/5) ONLY when all 5 forward criteria independently confirm the setup.
     */
    fun evaluateForwardSniperConfluence(
        symbol: String,
        m15Bars: List<CandleBar>,
        h1Bars: List<CandleBar>,
        h4Bars: List<CandleBar>,
        orderbookBidAskRatio: Double,
        source: String
    ): SniperSetupReport {
        val m15 = analyze(symbol, "15m", m15Bars, orderbookBidAskRatio, source)
        val h1 = analyze(symbol, "1h", h1Bars, orderbookBidAskRatio, source)
        val h4 = analyze(symbol, "4h", h4Bars, orderbookBidAskRatio, source)

        val bullScore = listOf(m15, h1, h4).count { it.trendBias == "BULLISH" }
        val bearScore = listOf(m15, h1, h4).count { it.trendBias == "BEARISH" }
        val preferredSide = when {
            bullScore > bearScore -> "BUY"
            bearScore > bullScore -> "SELL"
            h4.currentPrice >= h4.ema20 -> "BUY"
            else -> "SELL"
        }

        // Evidence 1: Multi-Timeframe Alignment (15m + 1h + 4h all pointing the same direction)
        val expectedBias = if (preferredSide == "BUY") "BULLISH" else "BEARISH"
        val mtfAligned = m15.trendBias == expectedBias && h1.trendBias == expectedBias && h4.trendBias == expectedBias

        // Evidence 2: Real-Time Orderbook Liquidity Pressure (Buyers > Sellers for BUY or vice versa)
        val orderbookAligned = if (preferredSide == "BUY") orderbookBidAskRatio >= 1.15 else orderbookBidAskRatio <= 0.87

        // Evidence 3: Live Volume & Short-Term Acceleration (Real money stepping in now, not old bars)
        val recent3 = m15Bars.takeLast(3)
        val impulseOk = if (recent3.size >= 3) {
            if (preferredSide == "BUY") recent3.last().close > recent3.first().open else recent3.last().close < recent3.first().open
        } else true
        val volumeStrong = max(m15.volumeSpikeRatio, h1.volumeSpikeRatio) >= 1.20 && impulseOk

        // Evidence 4: Forward Momentum Room (Not exhausted/overbought for BUY, not oversold for SELL)
        val rsiRoomOk = if (preferredSide == "BUY") {
            h1.rsi14 in 42.0..66.0 && m15.rsi14 in 40.0..68.0
        } else {
            h1.rsi14 in 34.0..58.0 && m15.rsi14 in 32.0..60.0
        }

        // Evidence 5: Asymmetric Structural Target Ahead (R:R >= 2.0 before next 4h wall)
        val entry = m15.currentPrice
        val atrUnit = h1.atr14.coerceAtLeast(entry * 0.003)
        val stopLoss = if (preferredSide == "BUY") entry - (1.4 * atrUnit) else entry + (1.4 * atrUnit)
        val structuralRoom = if (preferredSide == "BUY") (h4.resistanceLevel - entry) else (entry - h4.supportLevel)
        val targetDist = max(2.9 * atrUnit, minOf(4.2 * atrUnit, structuralRoom * 0.90))
        val takeProfit = if (preferredSide == "BUY") entry + targetDist else (entry - targetDist).coerceAtLeast(entry * 0.1)
        val rewardToRisk = (abs(takeProfit - entry) / abs(entry - stopLoss).coerceAtLeast(1e-6))
        val asymmetricRrOk = rewardToRisk >= 2.0

        val checks = listOf(
            SniperEvidenceCheck(
                titleAr = "توافق الأطر 15m+1h+4h",
                passed = mtfAligned,
                metricSummary = "15m=${m15.trendBias}, 1h=${h1.trendBias}, 4h=${h4.trendBias}"
            ),
            SniperEvidenceCheck(
                titleAr = "تدفق سيولة دفتر الأوامر",
                passed = orderbookAligned,
                metricSummary = "Bid/Ask=${"%.2f".format(orderbookBidAskRatio)}"
            ),
            SniperEvidenceCheck(
                titleAr = "زخم وحجم تداول فوري",
                passed = volumeStrong,
                metricSummary = "Vol=${"%.2f".format(max(m15.volumeSpikeRatio, h1.volumeSpikeRatio))}x"
            ),
            SniperEvidenceCheck(
                titleAr = "مساحة زخم قادمة (RSI غير متشبع)",
                passed = rsiRoomOk,
                metricSummary = "1h=${"%.1f".format(h1.rsi14)} | 15m=${"%.1f".format(m15.rsi14)}"
            ),
            SniperEvidenceCheck(
                titleAr = "عائد لمخاطرة هيكلي ≥ 2:1",
                passed = asymmetricRrOk,
                metricSummary = "R:R=${"%.2f".format(rewardToRisk)}:1"
            )
        )

        val matchedCount = checks.count { it.passed }
        val scorePct = (matchedCount.toDouble() / checks.size) * 100.0

        val catalyst = if (preferredSide == "BUY") {
            "محفز الصعود القادم: اختراق سيولة الطلب (${"%.2f".format(orderbookBidAskRatio)}x) مع مساحة مفتوحة نحو مقاومة 4H (${formatUsdCents(h4.resistanceLevel)})."
        } else {
            "محفز الهبوط القادم: ضغط بيعي مؤسسي (Bid/Ask=${"%.2f".format(orderbookBidAskRatio)}) مع مسار هبوط نحو دعم 4H (${formatUsdCents(h4.supportLevel)})."
        }
        val invalidation = "إبطال فوري للسيناريو القادم عند كسر ${formatUsdCents(stopLoss)} وإغلاق شمعة 15m عكس الاتجاه."

        return SniperSetupReport(
            symbol = symbol,
            preferredSide = preferredSide,
            entryPrice = entry,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
            rewardToRisk = rewardToRisk,
            matchedCount = matchedCount,
            totalCriteria = checks.size,
            evidenceScorePct = scorePct,
            isFullSniperMatch = matchedCount == checks.size,
            checks = checks,
            forwardCatalystAr = catalyst,
            invalidationRuleAr = invalidation,
            h1Snapshot = h1,
            fetchedAtMillis = max(m15.fetchedAtMillis, h1.fetchedAtMillis),
            dataSource = source
        )
    }

    fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val k = 2.0 / (period + 1)
        var result = values.first()
        for (i in 1 until values.size) {
            result = values[i] * k + result * (1.0 - k)
        }
        return result
    }

    fun rsi(closes: List<Double>, period: Int = 14): Double {
        if (closes.size <= period) return 50.0
        var gainSum = 0.0
        var lossSum = 0.0
        for (i in closes.size - period until closes.size) {
            val diff = closes[i] - closes[i - 1]
            if (diff > 0) gainSum += diff else lossSum += abs(diff)
        }
        val avgGain = gainSum / period
        val avgLoss = lossSum / period
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun atr(bars: List<CandleBar>, period: Int = 14): Double {
        if (bars.size <= period) return 0.0
        val trs = mutableListOf<Double>()
        for (i in 1 until bars.size) {
            val cur = bars[i]
            val prevClose = bars[i - 1].close
            val tr = max(
                cur.high - cur.low,
                max(abs(cur.high - prevClose), abs(cur.low - prevClose))
            )
            trs.add(tr)
        }
        return trs.takeLast(period).average()
    }
}
