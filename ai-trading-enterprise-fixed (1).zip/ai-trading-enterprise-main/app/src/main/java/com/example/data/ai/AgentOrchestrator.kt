package com.example.data.ai

import android.util.Log
import com.example.data.broker.BrokerConnector
import com.example.data.firebase.CompanyRepository
import com.example.data.market.MarketDataService
import com.example.data.market.TechnicalIndicatorEngine
import com.example.data.risk.RiskEngine
import com.example.model.AgentProfile
import com.example.model.AgentStatus
import com.example.model.BrokerCredentials
import com.example.model.CompanyConfig
import com.example.model.CorporateMessage
import com.example.model.CorporateTask
import com.example.model.LearningLog
import com.example.model.MarketTicker
import com.example.model.SniperSetupReport
import com.example.model.TechnicalSnapshot
import com.example.model.TradeRecord
import com.example.model.TradingStrategy
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import com.example.model.formatUsdCents
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

private const val TAG = "AgentOrchestrator"

const val AI_RETRY_USER_MESSAGE = "جاري إعادة محاولة الاتصال بالخادم بسبب الضغط المؤقت..."

val MODEL_FALLBACK_LADDER = listOf(
    "gemini-4-argon",
    "gemini-3.8-flash",
    "gemini-3.5-flash-lite"
)

fun resolveFallbackChain(primaryModel: String): List<String> {
    val idx = MODEL_FALLBACK_LADDER.indexOf(primaryModel)
    return if (idx >= 0) {
        MODEL_FALLBACK_LADDER.drop(idx)
    } else {
        listOf(primaryModel, "gemini-3.8-flash", "gemini-3.5-flash-lite").distinct()
    }
}

fun selectModelForAttempt(primaryModel: String, attempt: Int): String {
    val chain = resolveFallbackChain(primaryModel)
    return chain[attempt.coerceIn(0, chain.lastIndex)]
}

fun normalizeArabicNumerals(input: String): String {
    val sb = StringBuilder(input.length)
    for (ch in input) {
        when (ch) {
            in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
            in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            '٬', '،' -> sb.append(',')
            '٫' -> sb.append('.')
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}

fun extractProfitTargetUsd(command: String): Double? {
    val normalized = normalizeArabicNumerals(command).lowercase(Locale.US)
    val profitKeywords = listOf(
        "جني", "ربح", "ارباح", "أرباح", "اكسب", "كسب", "تحقيق", "حقق",
        "هدف", "دخل", "عائد", "دولار", "$", "usd", "profit", "earn", "target", "make", "goal"
    )
    if (profitKeywords.none { normalized.contains(it) }) return null
    val cleaned = normalized.replace(Regex("(?<=\\d),(?=\\d{3}\\b)"), "")
    val match = Regex("(?:\\$|usd\\s*)?(\\d+(?:\\.\\d{1,2})?)\\s*(?:%|دولار|dollar|usd|\\$)?")
        .findAll(cleaned)
        .firstOrNull { m ->
            val raw = m.value
            val num = m.groupValues[1].toDoubleOrNull() ?: 0.0
            !raw.contains("%") && num >= 1.0
        }
    return match?.groupValues?.get(1)?.toDoubleOrNull()
}

/**
 * Classifies transient AI / server overload errors eligible for automatic retry with backoff:
 * HTTP 503 Service Unavailable, 429 Rate Limit / Quota / Resource Exhausted, High Demand, and timeouts.
 */
fun isTransientAiError(error: Throwable): Boolean {
    if (error is TimeoutCancellationException || error is IOException) return true
    val chain = generateSequence(error) { it.cause }.take(6).toList()
    // Malformed / truncated JSON from the model is a transient failure: asking again usually fixes it.
    if (chain.any { it::class.java.simpleName == "JSONException" }) return true
    return chain.any { t ->
        val simpleName = t::class.java.simpleName.lowercase(Locale.US)
        val msg = (t.message ?: "").lowercase(Locale.US)
        simpleName.contains("serviceunavailable") ||
            simpleName.contains("quotaexceeded") ||
            simpleName.contains("requesttimeout") ||
            simpleName.contains("serverexception") ||
            msg.contains("503") ||
            msg.contains("429") ||
            msg.contains("high demand") ||
            msg.contains("overloaded") ||
            msg.contains("rate limit") ||
            msg.contains("quota") ||
            msg.contains("too many requests") ||
            msg.contains("resource_exhausted") ||
            msg.contains("resource exhausted") ||
            msg.contains("service unavailable") ||
            msg.contains("unavailable") ||
            msg.contains("temporarily") ||
            msg.contains("try again") ||
            msg.contains("timed out") ||
            msg.contains("timeout") ||
            // A model that is retired / not enabled for this project: move down the fallback ladder.
            (msg.contains("model") && (msg.contains("not found") || msg.contains("not supported") || msg.contains("no longer available") || msg.contains("deprecated"))) ||
            msg.contains("404")
    }
}

/**
 * Executes an AI call with Automatic Retry, Smart Model Fallback, and Exponential Backoff
 * (default: 3s, 6s, 12s up to 3 retries).
 * Never swallows cooperative coroutine cancellation (except TimeoutCancellationException).
 */
suspend fun <T> executeWithAiRetry(
    maxRetries: Int = 3,
    baseDelayMs: Long = 3_000L,
    onRetryStatus: (String) -> Unit = {},
    nextModelForAttempt: ((Int) -> String)? = null,
    block: suspend (attempt: Int) -> T
): T {
    var lastError: Throwable? = null
    for (attempt in 0..maxRetries) {
        try {
            return block(attempt)
        } catch (e: CancellationException) {
            if (e !is TimeoutCancellationException) throw e
            lastError = e
            if (attempt >= maxRetries) throw e
            val waitMs = baseDelayMs * (1L shl attempt)
            val waitSec = (waitMs / 1000L).coerceAtLeast(1L)
            val nextModel = nextModelForAttempt?.invoke(attempt + 1)
            val fallbackSuffix = if (nextModel != null) " • التحويل التلقائي إلى $nextModel" else ""
            onRetryStatus("$AI_RETRY_USER_MESSAGE (محاولة ${attempt + 1}/$maxRetries خلال ${waitSec}ث$fallbackSuffix)")
            runCatching { Log.w(TAG, "AI call timed out (attempt ${attempt + 1}); retrying in ${waitMs}ms$fallbackSuffix", e) }
            delay(waitMs)
        } catch (e: Throwable) {
            lastError = e
            if (attempt < maxRetries && isTransientAiError(e)) {
                val waitMs = baseDelayMs * (1L shl attempt)
                val waitSec = (waitMs / 1000L).coerceAtLeast(1L)
                val nextModel = nextModelForAttempt?.invoke(attempt + 1)
                val fallbackSuffix = if (nextModel != null) " • التحويل التلقائي إلى $nextModel" else ""
                onRetryStatus("$AI_RETRY_USER_MESSAGE (محاولة ${attempt + 1}/$maxRetries خلال ${waitSec}ث$fallbackSuffix)")
                runCatching { Log.w(TAG, "Transient AI server error (attempt ${attempt + 1}): ${e.message}; retrying in ${waitMs}ms$fallbackSuffix", e) }
                delay(waitMs)
            } else {
                throw e
            }
        }
    }
    throw (lastError ?: IllegalStateException("فشل الاتصال بالخادم بعد $maxRetries محاولات."))
}


/**
 * Failure of an owner command.
 * [retryable] = the command failed BEFORE any side effect (no task, config change or order),
 * so it is safe to re-run automatically without risking duplicated trades.
 */
class OwnerCommandException(
    message: String,
    val retryable: Boolean,
    cause: Throwable? = null
) : Exception(message, cause)

private val STOP_VERBS = setOf(
    "أوقف", "اوقف", "أوقفوا", "اوقفوا", "إيقاف", "ايقاف", "وقف", "وقّف", "جمد", "جمّد",
    "stop", "halt", "pause", "freeze"
)
private val TRADING_NOUNS = setOf(
    "التداول", "تداول", "بالتداول", "الصفقات", "صفقات", "عمليات", "trading", "trades", "trade"
)
private val NEGATION_TOKENS = setOf("لا", "لن", "ما", "dont", "not", "never", "no")
private val QUESTION_STARTERS = setOf("لماذا", "ليش", "هل", "كيف", "ماذا", "why", "how", "did", "is", "what")

private fun tokenizeCommand(command: String): List<String> =
    normalizeArabicNumerals(command)
        .lowercase(Locale.US)
        .replace("'", "")
        .replace("’", "")
        .split(Regex("[^\\p{L}\\p{M}\\p{N}.]+"))
        .map { it.trim('.') }
        .filter { it.isNotEmpty() }

/**
 * True only for a clear, short, non-negated, non-question "stop trading" order. This is evaluated
 * locally (no AI) so the owner's emergency stop can never be blocked by AI server overload.
 */
fun isExplicitStopTradingCommand(command: String): Boolean {
    val raw = command.trim()
    if (raw.isEmpty() || raw.length > 200) return false
    if (raw.contains('؟') || raw.contains('?')) return false
    val tokens = tokenizeCommand(raw)
    if (tokens.isEmpty() || tokens.size > 14) return false
    if (tokens.first() in QUESTION_STARTERS) return false
    val verbIdx = tokens.indexOfFirst { it in STOP_VERBS }
    if (verbIdx < 0) return false
    if (tokens.none { it in TRADING_NOUNS }) return false
    val before = tokens.subList(maxOf(0, verbIdx - 2), verbIdx)
    if (before.any { it in NEGATION_TOKENS }) return false
    return true
}

/** Extracts an explicit risk-per-trade percentage (0.1..10) from a risk-update order, or null. */
fun extractRiskPctFromCommand(command: String): Double? {
    val normalized = normalizeArabicNumerals(command).lowercase(Locale.US)
    if (!(normalized.contains("مخاطر") || normalized.contains("risk"))) return null
    return Regex("(\\d+(?:\\.\\d+)?)")
        .findAll(normalized)
        .mapNotNull { it.groupValues[1].toDoubleOrNull() }
        .firstOrNull { it in 0.1..10.0 }
}

/** Best-effort asset detection from plain text, used only when the AI router is unreachable. */
fun detectSymbolFromCommand(command: String): String {
    val t = normalizeArabicNumerals(command).lowercase(Locale.US)
    return when {
        listOf("بيتكوين", "بتكوين", "btc", "bitcoin").any { t.contains(it) } -> "BTCUSDT"
        listOf("ايثيريوم", "إيثيريوم", "ايثريوم", "eth", "ethereum").any { t.contains(it) } -> "ETHUSDT"
        listOf("سولانا", "sol", "solana").any { t.contains(it) } -> "SOLUSDT"
        listOf("يورو", "eur", "euro").any { t.contains(it) } -> "EURUSDT"
        else -> "PAXGUSDT"
    }
}

class AgentOrchestrator(
    private val repository: CompanyRepository,
    private val marketService: MarketDataService,
    private val brokerConnector: BrokerConnector
) {
    private val validModels = setOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-4-argon")

    private val modelCache = ConcurrentHashMap<String, GenerativeModel>()

    private fun resolveModelName(agent: AgentProfile?, fallback: String = "gemini-3.8-flash"): String {
        return agent?.modelId?.takeIf { it in validModels } ?: fallback
    }

    private fun getCachedModel(
        modelName: String,
        schemaKey: String,
        jsonSchema: Schema?,
        maxTokens: Int
    ): GenerativeModel {
        val cacheKey = "$modelName|$schemaKey|$maxTokens"
        return modelCache.getOrPut(cacheKey) {
            Firebase.ai.generativeModel(
                modelName = modelName,
                generationConfig = generationConfig {
                    temperature = if (jsonSchema != null) 0.2f else 0.35f
                    maxOutputTokens = maxTokens
                    if (jsonSchema != null) {
                        responseMimeType = "application/json"
                        responseSchema = jsonSchema
                    }
                }
            )
        }
    }

    private suspend fun generateStreamedTextWithRetry(
        primaryModelName: String,
        schemaKey: String,
        maxTokens: Int,
        prompt: String,
        timeoutMs: Long = 60_000L,
        onStatusUpdate: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        executeWithAiRetry(
            maxRetries = 3,
            baseDelayMs = 3_000L,
            onRetryStatus = onStatusUpdate,
            nextModelForAttempt = { attempt -> selectModelForAttempt(primaryModelName, attempt) }
        ) { attempt ->
            val activeModelName = selectModelForAttempt(primaryModelName, attempt)
            val model = getCachedModel(activeModelName, schemaKey, null, maxTokens)
            val buffer = StringBuilder()
            try {
                withTimeout(timeoutMs) {
                    model.generateContentStream(prompt).collect { chunk ->
                        chunk.text?.let { buffer.append(it) }
                    }
                }
                val text = buffer.toString()
                if (text.isBlank()) throw IOException("503 Service Unavailable: empty AI stream response")
                text
            } catch (e: TimeoutCancellationException) {
                if (buffer.length >= 80) {
                    Log.w(TAG, "Stream reached ${timeoutMs}ms after receiving ${buffer.length} chars; using streamed content.")
                    buffer.toString()
                } else {
                    throw e
                }
            }
        }
    }

    private suspend fun generateJsonWithRetry(
        primaryModelName: String,
        schemaKey: String,
        schema: Schema,
        maxTokens: Int,
        prompt: String,
        timeoutMs: Long = 60_000L,
        onStatusUpdate: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        executeWithAiRetry(
            maxRetries = 3,
            baseDelayMs = 3_000L,
            onRetryStatus = onStatusUpdate,
            nextModelForAttempt = { attempt -> selectModelForAttempt(primaryModelName, attempt) }
        ) { attempt ->
            val activeModelName = selectModelForAttempt(primaryModelName, attempt)
            val model = getCachedModel(activeModelName, schemaKey, schema, maxTokens)
            val response = withTimeout(timeoutMs) {
                model.generateContent(prompt)
            }
            response.text?.takeIf { it.isNotBlank() }
                ?: throw IOException("503 Service Unavailable: empty JSON response")
        }
    }

    private val ceoRoutingSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "intent" to Schema.enumeration(
                    values = listOf(
                        "SNIPER_STRIKE",
                        "PROFIT_TARGET_CAMPAIGN",
                        "ANALYZE_AND_TRADE",
                        "MARKET_BRIEF",
                        "QA_REPORT",
                        "STOP_TRADING",
                        "RISK_UPDATE",
                        "EVOLVE_INTELLIGENCE",
                        "STRICT_DISCIPLINE_AUDIT",
                        "SUMMON_UNCLE_SAAB"
                    ),
                    description = "Classified owner intent"
                ),
                "targetSymbol" to Schema.enumeration(
                    values = listOf("PAXGUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT", "EURUSDT"),
                    description = "Primary financial asset symbol requested"
                ),
                "allowTradeExecution" to Schema.boolean(description = "True if owner asked to earn profit, activate Sniper, prepare, or execute a trade plan"),
                "requestedRiskPct" to Schema.double(description = "New max risk percentage if intent is RISK_UPDATE, else -1.0"),
                "requestedProfitTargetUsd" to Schema.double(description = "USD profit target requested by owner (e.g. 2999.0), else -1.0"),
                "ceoPlanAr" to Schema.string(description = "Clear concise executive plan in Arabic (1-2 sentences)"),
                "ceoDirectAnswerAr" to Schema.string(description = "Direct CEO answer in Arabic for QA/Control intents")
            )
        )
    }

    private val hrEvaluationSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "expertiseSummaryAr" to Schema.string(description = "Detailed Arabic summary of candidate domain expertise and analytical methodology"),
                "companyBenefitAr" to Schema.string(description = "Concrete benefit this specialist adds to QuantCorp AI profits, risk, and workflow"),
                "expectedBoostPct" to Schema.double(description = "Estimated accuracy or efficiency boost percentage between 6.0 and 30.0")
            )
        )
    }

    private val disciplineAuditSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "executiveReportAr" to Schema.string(description = "Sharp Arabic summary contrasting top profitable earners against slackers"),
                "reprimands" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "agentId" to Schema.string(description = "Underperforming or stalled agent ID"),
                            "reasonAr" to Schema.string(description = "Strict direct reason for reprimand in Arabic"),
                            "enforcedTaskAr" to Schema.string(description = "Mandatory immediate corrective task under 42 chars")
                        )
                    ),
                    description = "1 to 3 underperforming employees requiring public reprimand"
                )
            )
        )
    }

    private val tradeProposalSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "shouldTrade" to Schema.boolean(description = "True only if live forward confluence and strategy rules are met"),
                "side" to Schema.enumeration(values = listOf("BUY", "SELL"), description = "Trade direction"),
                "strategyId" to Schema.string(description = "ID of chosen strategy"),
                "traderId" to Schema.enumeration(
                    values = listOf("trd_short_01", "trd_mid_01", "trd_multi_01", "sniper_01"),
                    description = "Designated execution trader or القناص (sniper_01) for 100% confluence"
                ),
                "stopLossMultiplierAtr" to Schema.double(description = "ATR multiplier for stop loss between 1.0 and 2.5"),
                "takeProfitMultiplierAtr" to Schema.double(description = "ATR multiplier for take profit between 2.0 and 4.2"),
                "rationaleAr" to Schema.string(description = "Concise forward-looking rationale in Arabic citing real data and invalidation criteria")
            )
        )
    }

    private val campaignProposalsSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "campaignStrategySummaryAr" to Schema.string(description = "Executive Arabic summary of the multi-asset forward plan"),
                "trades" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "symbol" to Schema.enumeration(
                                values = listOf("PAXGUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT", "EURUSDT"),
                                description = "Asset symbol from the 5-market scan"
                            ),
                            "side" to Schema.enumeration(values = listOf("BUY", "SELL"), description = "Trade direction"),
                            "strategyId" to Schema.string(description = "Strategy ID"),
                            "traderId" to Schema.enumeration(
                                values = listOf("trd_short_01", "trd_mid_01", "trd_multi_01", "sniper_01"),
                                description = "Assigned trader or القناص (sniper_01)"
                            ),
                            "stopLossMultiplierAtr" to Schema.double(description = "ATR stop loss multiplier 1.2..2.2"),
                            "takeProfitMultiplierAtr" to Schema.double(description = "ATR take profit multiplier 2.0..4.2"),
                            "rationaleAr" to Schema.string(description = "Forward-looking Arabic rationale grounded in live metrics")
                        )
                    ),
                    description = "Up to 3 strongest non-duplicate trade setups across the 5 scanned markets"
                )
            )
        )
    }

    private data class RoutingDecision(
        val intent: String,
        val targetSymbol: String,
        val allowTradeExecution: Boolean,
        val requestedRiskPct: Double,
        val requestedProfitTargetUsd: Double,
        val ceoPlanAr: String,
        val ceoDirectAnswerAr: String
    )

    private data class MarketIntelOutcome(
        val unifiedReport: String,
        val techSnap: TechnicalSnapshot,
        val sniperReport: SniperSetupReport?,
        val dataSource: String,
        val timeStr: String
    )

    private data class ScoredMarket(
        val symbol: String,
        val snap: TechnicalSnapshot,
        val sniperReport: SniperSetupReport?,
        val dataSource: String,
        val score: Double,
        val preferredSide: String
    )

    suspend fun processOwnerCommand(
        ownerCommand: String,
        config: CompanyConfig,
        agents: List<AgentProfile>,
        strategies: List<TradingStrategy>,
        openTrades: List<TradeRecord>,
        closedTrades: List<TradeRecord>,
        learningLogs: List<LearningLog>,
        liveTickers: List<MarketTicker>,
        brokerCreds: BrokerCredentials,
        onStatusUpdate: (String) -> Unit = {},
        postOwnerMessage: Boolean = true
    ): Result<String> {
        val ceo = agents.firstOrNull { it.id == "ceo_01" }
        // On automatic re-attempts the owner's message is already in the chat: don't duplicate it.
        if (postOwnerMessage) {
            repository.addMessage(
                CorporateMessage(
                    taskId = "owner_cmd",
                    senderId = "OWNER",
                    senderName = "مالك الشركة",
                    senderRole = "Owner",
                    recipientId = "ceo_01",
                    channel = "CEO_OWNER",
                    content = ownerCommand,
                    evidenceCited = "أمر مباشر من مالك الشركة",
                    decisionReached = "قيد معالجة الرئيس التنفيذي"
                )
            )
        }

        // Emergency stop is handled locally, before (and independent of) any AI call or CEO block.
        if (isExplicitStopTradingCommand(ownerCommand)) {
            return try {
                val stopDecision = RoutingDecision(
                    intent = "STOP_TRADING",
                    targetSymbol = "PAXGUSDT",
                    allowTradeExecution = false,
                    requestedRiskPct = -1.0,
                    requestedProfitTargetUsd = -1.0,
                    ceoPlanAr = "",
                    ceoDirectAnswerAr = ""
                )
                val reply = handleImmediateControlIntent(stopDecision, config, openTrades, closedTrades)
                    ?: "تم إيقاف التداول."
                Result.success(reply)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Local stop-trading handling failed", e)
                Result.failure(OwnerCommandException(e.localizedMessage ?: "تعذر تنفيذ أمر الإيقاف", retryable = true, cause = e))
            }
        }

        if (ceo?.blockedByOwner == true) {
            return Result.failure(IllegalStateException("الرئيس التنفيذي موقوف حالياً من لوحة تحكم المالك."))
        }

        var activeTaskId: String? = null
        return try {
            onStatusUpdate("الرئيس التنفيذي يقرأ أمرك ويجهز الخطة التنفيذية...")
            repository.updateAgentStatus("ceo_01", AgentStatus.WORKING.label, "تحليل أمر المالك وإعداد الخطة التنفيذية")
            val routing = routeOwnerCommand(ceo, ownerCommand, config, openTrades, closedTrades, liveTickers, onStatusUpdate)

            handleImmediateControlIntent(routing, config, openTrades, closedTrades)?.let { immediateReply ->
                return Result.success(immediateReply)
            }

            if (routing.intent == "EVOLVE_INTELLIGENCE") {
                val iqReport = runCollectiveIntelligenceUpgrade(
                    config = config,
                    agents = agents,
                    closedTrades = closedTrades,
                    learningLogs = learningLogs,
                    tickers = liveTickers,
                    onStatusUpdate = onStatusUpdate
                ).getOrThrow()
                return Result.success(iqReport)
            }

            if (routing.intent == "STRICT_DISCIPLINE_AUDIT") {
                val auditReport = runStrictPerformanceAudit(
                    config = config,
                    agents = agents,
                    openTrades = openTrades,
                    closedTrades = closedTrades,
                    learningLogs = learningLogs,
                    ownerInitiated = true,
                    onStatusUpdate = onStatusUpdate
                ).getOrThrow()
                return Result.success(auditReport)
            }

            if (routing.intent == "SUMMON_UNCLE_SAAB") {
                val preset = com.example.model.InitialCompanyRoster.uncleSaabPreset()
                val dossier = evaluateHrCandidate(
                    nameAr = preset.nameAr,
                    roleAr = preset.roleAr,
                    department = preset.department,
                    specializationNotes = preset.specialization,
                    modelId = preset.modelId,
                    currentAgents = agents,
                    strategies = strategies,
                    learningLogs = learningLogs,
                    fixedId = "uncle_saab",
                    onStatusUpdate = onStatusUpdate
                ).getOrThrow()
                val msg = "🛡️ استجابت الموارد البشرية لأمرك وأحضرت **${dossier.nameAr}** للفحص!\n• الخبرة: ${dossier.candidateExpertise}\n• الفائدة للشركة: ${dossier.candidateCompanyBenefit}\n• نتيجة الاختبار: ${"%.1f".format(dossier.backtestPassRate)}% | IQ: ${"%.0f".format(dossier.intelligenceScore)}\n👉 افتح تبويب «الذاكرة ← الموارد البشرية HR» لاعتماد تعيينه فوراً."
                postCeoReply("owner_cmd", msg, "HR Dossier (uncle_saab)", "بطاقة تقييم العم صعب جاهزة")
                return Result.success(msg)
            }

            if (routing.intent == "SNIPER_STRIKE") {
                val sniperReply = runSniperStrikeWorkflow(
                    ownerCommand = ownerCommand,
                    ceoPlanAr = routing.ceoPlanAr,
                    config = config,
                    agents = agents,
                    strategies = strategies,
                    openTrades = openTrades,
                    closedTrades = closedTrades,
                    brokerCreds = brokerCreds,
                    onStatusUpdate = onStatusUpdate
                )
                return Result.success(sniperReply)
            }

            if (routing.intent == "PROFIT_TARGET_CAMPAIGN" || routing.requestedProfitTargetUsd > 0.0) {
                val targetUsd = routing.requestedProfitTargetUsd.coerceAtLeast(100.0)
                val tickerMap = liveTickers.associateBy { it.symbol }
                val unrealizedNow = openTrades.filter { it.mode == config.tradingMode }.sumOf { t ->
                    val mark = tickerMap[t.symbol]?.lastPrice ?: t.entryPrice
                    if (t.side == "BUY") (mark - t.entryPrice) * t.quantity else (t.entryPrice - mark) * t.quantity
                }
                val realizedNow = closedTrades.filter { it.mode == config.tradingMode }.sumOf { it.realizedPnl }
                val baselinePnl = realizedNow + unrealizedNow
                repository.updateConfigFields(
                    mapOf(
                        "profitTargetUsd" to targetUsd,
                        "profitTargetBaselinePnl" to baselinePnl
                    )
                )
                val updatedConfig = config.copy(
                    profitTargetUsd = targetUsd,
                    profitTargetBaselinePnl = baselinePnl
                )
                val campaignReply = runProfitTargetCampaign(
                    ownerCommand = ownerCommand,
                    targetProfitUsd = targetUsd,
                    ceoPlanAr = routing.ceoPlanAr,
                    config = updatedConfig,
                    agents = agents,
                    strategies = strategies,
                    openTrades = openTrades,
                    closedTrades = closedTrades,
                    learningLogs = learningLogs,
                    brokerCreds = brokerCreds,
                    onStatusUpdate = onStatusUpdate
                )
                return Result.success(campaignReply)
            }

            val taskId = repository.createTask(
                CorporateTask(
                    ownerOrder = ownerCommand,
                    stage = "MARKET_INTELLIGENCE",
                    status = "ACTIVE",
                    assignedAgentId = "mid_01",
                    targetAsset = routing.targetSymbol,
                    ceoPlan = routing.ceoPlanAr
                )
            ).getOrThrow()
            activeTaskId = taskId

            postCeoReply(
                taskId = taskId,
                content = "استلمت أمرك: \"$ownerCommand\".\nالخطة التنفيذية: ${routing.ceoPlanAr}\nجاري توجيه إدارة تحليل السوق لجلب البيانات الحية لـ ${routing.targetSymbol} وتوزيع البحث على المحللين الثلاثة.",
                evidence = "إنشاء مهمة مؤسسية رقم $taskId",
                decision = "بدء دورة البحث المؤسسي"
            )

            onStatusUpdate("إدارة تحليل السوق تجلب البيانات الحية لـ ${routing.targetSymbol} وتستشير المحللين...")
            val intelOutcome = runMarketIntelligenceStage(taskId, routing.targetSymbol, agents, learningLogs, onStatusUpdate)
                ?: return Result.success("تم إيقاف التوصية تلقائياً لعدم توفر بيانات سوق حية موثوقة لـ ${routing.targetSymbol}.")

            if (routing.intent == "MARKET_BRIEF" && !routing.allowTradeExecution) {
                repository.updateTask(taskId, mapOf("stage" to "COMPLETED", "status" to "CLOSED", "outcomeSummary" to "تم تسليم التقرير الموحد للسوق"))
                postCeoReply(taskId, intelOutcome.unifiedReport, "${intelOutcome.dataSource} @ ${intelOutcome.timeStr}", "تسليم تقرير تحليل السوق الموحد")
                listOf("ceo_01", "mid_01", "ana_fund_01", "ana_tech_01", "ana_liq_01").forEach { id ->
                    agents.firstOrNull { it.id == id }?.let { ag ->
                        repository.recordAgentTaskCompletionOnly(
                            agent = ag,
                            newStatus = AgentStatus.COMPLETED.label,
                            currentTaskText = "أتم تقرير السوق لـ ${routing.targetSymbol} (بانتظار ربح فعلي للترقية)"
                        )
                    }
                }
                return Result.success(intelOutcome.unifiedReport)
            }

            onStatusUpdate("مدير التداول يناقش الخطة ويرفعها لقسم المخاطر المستقل...")
            val finalReply = runTradingAndRiskStage(
                taskId = taskId,
                intel = intelOutcome,
                config = config,
                agents = agents,
                strategies = strategies,
                openTrades = openTrades,
                closedTrades = closedTrades,
                brokerCreds = brokerCreds,
                onStatusUpdate = onStatusUpdate
            )
            Result.success(finalReply)
        } catch (e: OwnerCommandException) {
            Log.w(TAG, "Owner command failed (retryable=${e.retryable}): ${e.message}")
            if (e.retryable) {
                // Nothing was executed yet: leave the company ready; the app will re-send automatically.
                runCatching {
                    repository.updateAgentStatus("ceo_01", AgentStatus.WAITING.label, "بانتظار إعادة الاتصال لمعالجة أمر المالك")
                }
            } else {
                recoverOnFailure(activeTaskId, e.message ?: "خطأ غير متوقع")
            }
            Result.failure(e)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Orchestration timed out after automatic retries", e)
            recoverOnFailure(activeTaskId, "انتهت مهلة الاستجابة من الخادم بعد 3 محاولات إعادة اتصال تلقائية.")
            Result.failure(
                OwnerCommandException("تعذر إتمام الطلب بعد 3 محاولات إعادة اتصال تلقائية بسبب ضغط الخادم.", retryable = false, cause = e)
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Orchestration failed", e)
            recoverOnFailure(activeTaskId, e.localizedMessage ?: "خطأ غير متوقع")
            Result.failure(OwnerCommandException(e.localizedMessage ?: "خطأ غير متوقع", retryable = false, cause = e))
        }
    }

    private suspend fun recoverOnFailure(taskId: String?, reason: String) {
        try {
            repository.updateAgentStatus("ceo_01", AgentStatus.ERROR.label, reason.take(120))
            listOf("mid_01", "ana_fund_01", "ana_tech_01", "ana_liq_01", "hot_01", "cro_01").forEach { id ->
                repository.updateAgentStatus(id, AgentStatus.WAITING.label, "في وضع الانتظار بعد توقف المهمة")
            }
            if (!taskId.isNullOrBlank()) {
                repository.updateTask(
                    taskId,
                    mapOf("stage" to "TIMED_OUT", "status" to "CLOSED", "outcomeSummary" to reason.take(500))
                )
                postCeoReply(
                    taskId = taskId,
                    content = "تعذر إتمام الدورة التنفيذية: $reason",
                    evidence = "مراقب النظام التنفيذي",
                    decision = "إغلاق المهمة بعد استنفاد محاولات إعادة الاتصال"
                )
            }
        } catch (_: Exception) {
            // Keep failure recovery non-fatal
        }
    }

    private suspend fun routeOwnerCommand(
        ceo: AgentProfile?,
        ownerCommand: String,
        config: CompanyConfig,
        openTrades: List<TradeRecord>,
        closedTrades: List<TradeRecord>,
        liveTickers: List<MarketTicker>,
        onStatusUpdate: (String) -> Unit
    ): RoutingDecision {
        val openSummary = if (openTrades.isEmpty()) "لا توجد صفقات مفتوحة حالياً."
        else openTrades.joinToString("\n") { "- ${it.symbol} (${it.side}) | الدخول: ${it.entryPrice} | SL: ${it.stopLoss} | TP: ${it.takeProfit} | ${it.mode}" }

        val closedPnl = closedTrades.filter { it.mode == config.tradingMode }.sumOf { it.realizedPnl }
        val tickerSummary = if (liveTickers.isEmpty()) "سيتم جلب السعر الحي مباشرة في الخطوة التالية."
        else liveTickers.joinToString("\n") {
            "${it.symbol} (${it.displayNameAr}): $${"%.2f".format(it.lastPrice)} (${"%+.2f".format(it.change24hPct)}%) [${it.source}]"
        }

        val normalizedOrder = normalizeArabicNumerals(ownerCommand)
        val regexTarget = extractProfitTargetUsd(ownerCommand)

        val sniperRequested = listOf("قناص", "القناص", "sniper", "يقين 100", "100%").any {
            normalizedOrder.contains(it, ignoreCase = true)
        }
        val evolveRequested = listOf("تطوير الذكاء", "رفع الذكاء", "تطوير الموظفين", "ترقية الذكاء", "iq", "ذكاء جماعي").any {
            normalizedOrder.contains(it, ignoreCase = true)
        }
        val disciplineRequested = listOf("حازم", "المفتش", "توبيخ", "متقاعس", "تفتيش", "محاسبة", "انضباط").any {
            normalizedOrder.contains(it, ignoreCase = true)
        }
        val uncleSaabRequested = listOf("العم صعب", "عم صعب", "saab").any {
            normalizedOrder.contains(it, ignoreCase = true)
        }

        val routingPrompt = """
            أنت الرئيس التنفيذي (CEO) لشركة QuantCorp AI. هدف الشركة الأول هو جني المال وتحقيق الربح للمالك عبر ذكاء لحظي واستشراف قادم حقيقي (وليس تكرار تحاليل سابقة).
            أمر المالك: "$ownerCommand" (الأرقام المعيارية: "$normalizedOrder")
            الوضع: ${config.tradingMode} | Kill Switch: ${config.killSwitchActive} | إيقاف التداول: ${config.tradingPaused}
            المخاطرة/صفقة: ${config.maxRiskPerTradePct}% | رصيد خزنة الأمان: ${formatUsdCents(config.safetyVaultBalance)} | صافي الربح (${config.tradingMode}): ${formatUsdCents(closedPnl, signed = true)} USD
            الصفقات المفتوحة:
            $openSummary
            الأسعار الحية:
            $tickerSummary
            قواعد التصنيف:
            - إذا طلب المالك استدعاء أو توظيف "العم صعب"، اختر SUMMON_UNCLE_SAAB.
            - إذا طلب المالك محاسبة أو توبيخ المتقاعسين أو تشغيل المفتش حازم، اختر STRICT_DISCIPLINE_AUDIT.
            - إذا طلب المالك تطوير ذكاء الموظفين الجماعي أو رفع IQ، اختر EVOLVE_INTELLIGENCE.
            - إذا طلب المالك تفعيل "القناص" أو صفقة بدلائل يقين 100%، اختر SNIPER_STRIKE.
            - إذا طلب المالك جني أو ربح مبلغ محدد (مثل: أريد جني 2999 دولار)، اختر PROFIT_TARGET_CAMPAIGN وضع requestedProfitTargetUsd بالمبلغ المطلوب و allowTradeExecution=true.
            - الذهب الفوري يرمز له بـ PAXGUSDT.
        """.trimIndent()

        var routingError: Throwable? = null
        val json: JSONObject? = try {
            JSONObject(
                generateJsonWithRetry(
                    primaryModelName = resolveModelName(ceo, fallback = "gemini-3.5-flash-lite"),
                    schemaKey = "ceo_routing_v4",
                    schema = ceoRoutingSchema,
                    maxTokens = 512,
                    prompt = routingPrompt,
                    timeoutMs = 25_000L,
                    onStatusUpdate = onStatusUpdate
                )
            )
        } catch (e: TimeoutCancellationException) {
            routingError = e
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            routingError = e
            null
        }

        if (json == null) {
            // AI router unreachable: the clear-cut keyword intents can still be routed locally.
            val localRisk = extractRiskPctFromCommand(ownerCommand)
            val localIntent = when {
                uncleSaabRequested -> "SUMMON_UNCLE_SAAB"
                disciplineRequested -> "STRICT_DISCIPLINE_AUDIT"
                evolveRequested -> "EVOLVE_INTELLIGENCE"
                sniperRequested && regexTarget == null -> "SNIPER_STRIKE"
                regexTarget != null -> "PROFIT_TARGET_CAMPAIGN"
                localRisk != null -> "RISK_UPDATE"
                else -> null
            }
            if (localIntent != null) {
                Log.w(TAG, "AI routing unavailable; routing locally to $localIntent", routingError)
                onStatusUpdate("تم توجيه أمرك محلياً إلى $localIntent لأن خادم الذكاء الاصطناعي مشغول...")
                return RoutingDecision(
                    intent = localIntent,
                    targetSymbol = detectSymbolFromCommand(ownerCommand),
                    allowTradeExecution = localIntent == "PROFIT_TARGET_CAMPAIGN" || localIntent == "SNIPER_STRIKE",
                    requestedRiskPct = localRisk ?: -1.0,
                    requestedProfitTargetUsd = regexTarget ?: -1.0,
                    ceoPlanAr = "استنفار الإدارات لتنفيذ أمر المالك فوراً (توجيه محلي أثناء ضغط الخادم).",
                    ceoDirectAnswerAr = ""
                )
            }
            val transient = routingError == null || isTransientAiError(routingError)
            throw OwnerCommandException(
                if (transient) "تعذر الوصول للرئيس التنفيذي بسبب ضغط الخادم. أمرك محفوظ وستُعاد المحاولة تلقائياً."
                else "تعذر توجيه الأمر: ${routingError?.localizedMessage ?: "خطأ غير معروف"}",
                retryable = transient,
                cause = routingError
            )
        }

        val aiTarget = json.optDouble("requestedProfitTargetUsd", -1.0)
        val finalTarget = regexTarget ?: if (aiTarget > 0.0) aiTarget else -1.0
        val rawIntent = json.optString("intent", "ANALYZE_AND_TRADE")
        val finalIntent = when {
            uncleSaabRequested -> "SUMMON_UNCLE_SAAB"
            disciplineRequested -> "STRICT_DISCIPLINE_AUDIT"
            evolveRequested -> "EVOLVE_INTELLIGENCE"
            sniperRequested && finalTarget <= 0.0 -> "SNIPER_STRIKE"
            finalTarget > 0.0 && rawIntent != "STOP_TRADING" && rawIntent != "RISK_UPDATE" -> "PROFIT_TARGET_CAMPAIGN"
            else -> rawIntent
        }
        return RoutingDecision(
            intent = finalIntent,
            targetSymbol = json.optString("targetSymbol", "PAXGUSDT"),
            allowTradeExecution = json.optBoolean("allowTradeExecution", finalTarget > 0.0 || finalIntent == "SNIPER_STRIKE") ||
                finalIntent == "PROFIT_TARGET_CAMPAIGN" || finalIntent == "SNIPER_STRIKE",
            requestedRiskPct = json.optDouble("requestedRiskPct", -1.0),
            requestedProfitTargetUsd = finalTarget,
            ceoPlanAr = json.optString("ceoPlanAr", "استنفار الإدارات والقناص بالتحليل اللحظي المستقبلي لتحقيق هدف المالك"),
            ceoDirectAnswerAr = json.optString("ceoDirectAnswerAr", "")
        )
    }

    private suspend fun handleImmediateControlIntent(
        routing: RoutingDecision,
        config: CompanyConfig,
        openTrades: List<TradeRecord>,
        closedTrades: List<TradeRecord>
    ): String? {
        if (routing.intent == "STOP_TRADING") {
            repository.updateConfigFields(mapOf("tradingPaused" to true))
            repository.addAuditLog("CEO -> Owner Command", "TRADING_PAUSED", "أوقف المالك التداول عبر الرئيس التنفيذي.", "WARNING")
            val reply = routing.ceoDirectAnswerAr.ifBlank { "تم تنفيذ أمرك فوراً: إيقاف جميع عمليات التداول الجديدة." }
            postCeoReply("owner_cmd", reply, "CompanyConfig.tradingPaused = true", "إيقاف التداول")
            repository.updateAgentStatus("ceo_01", AgentStatus.COMPLETED.label, "تم تنفيذ أمر الإيقاف")
            return reply
        }

        if (routing.intent == "RISK_UPDATE" && routing.requestedRiskPct in 0.1..10.0) {
            repository.updateConfigFields(mapOf("maxRiskPerTradePct" to routing.requestedRiskPct))
            repository.addAuditLog("CEO -> Risk Config", "RISK_CAP_UPDATED", "تعديل حد المخاطرة إلى ${routing.requestedRiskPct}%.", "WARNING")
            val reply = routing.ceoDirectAnswerAr.ifBlank { "تم تعديل حد المخاطرة في الصفقة إلى ${routing.requestedRiskPct}%." }
            postCeoReply("owner_cmd", reply, "CompanyConfig.maxRiskPerTradePct = ${routing.requestedRiskPct}%", "تعديل سقف المخاطرة")
            repository.updateAgentStatus("ceo_01", AgentStatus.COMPLETED.label, "تم تعديل حدود المخاطرة")
            return reply
        }

        if (routing.intent == "QA_REPORT") {
            val closedPnl = closedTrades.filter { it.mode == config.tradingMode }.sumOf { it.realizedPnl }
            val openTxt = if (openTrades.isEmpty()) "لا توجد صفقات مفتوحة." else openTrades.joinToString("\n") { "• ${it.symbol} ${it.side} @ ${it.entryPrice}" }
            val reply = routing.ceoDirectAnswerAr.ifBlank { "ملخص الشركة (${config.tradingMode}):\n$openTxt\nصافي الربح المحقق: ${"%.2f".format(closedPnl)} USD" }
            postCeoReply("owner_cmd", reply, "بيانات Firestore الحية", "تسليم التقرير الإداري")
            repository.updateAgentStatus("ceo_01", AgentStatus.COMPLETED.label, "تم تسليم التقرير للمالك")
            return reply
        }
        return null
    }

    private suspend fun runMarketIntelligenceStage(
        taskId: String,
        targetSymbol: String,
        agents: List<AgentProfile>,
        learningLogs: List<LearningLog>,
        onStatusUpdate: (String) -> Unit
    ): MarketIntelOutcome? {
        val mid = agents.firstOrNull { it.id == "mid_01" }
        val fundAnalyst = agents.firstOrNull { it.id == "ana_fund_01" }
        val techAnalyst = agents.firstOrNull { it.id == "ana_tech_01" }
        val liqAnalyst = agents.firstOrNull { it.id == "ana_liq_01" }

        val (barsPair, m15Pair, h4Pair, orderbookRatio) = coroutineScope {
            val h1D = async { marketService.fetchCandles(targetSymbol, interval = "1h", limit = 160) }
            val m15D = async { marketService.fetchCandles(targetSymbol, interval = "15m", limit = 90) }
            val h4D = async { marketService.fetchCandles(targetSymbol, interval = "4h", limit = 90) }
            val obD = async { marketService.fetchOrderbookBidAskRatio(targetSymbol) }
            listOf(h1D.await(), m15D.await(), h4D.await(), obD.await())
        }

        @Suppress("UNCHECKED_CAST")
        val candlesRes = barsPair as Result<Pair<List<com.example.model.CandleBar>, String>>
        val candlesPair = candlesRes.getOrElse { err ->
            repository.updateAgentStatus("mid_01", AgentStatus.ERROR.label, "انقطاع مصدر بيانات السوق")
            repository.updateTask(taskId, mapOf("stage" to "ABORTED_DATA_ERROR", "status" to "CLOSED", "outcomeSummary" to (err.message ?: "فشل جلب بيانات السوق")))
            repository.addAuditLog("CRO", "DATA_FEED_HALT", "توقف التحليل لعدم توفر بيانات حية لـ $targetSymbol: ${err.message}", "CRITICAL")
            postCeoReply(taskId, "تم إيقاف التوصية تلقائياً: تعذر جلب بيانات السوق الحية الموثوقة لـ $targetSymbol.", "فحص مزود البيانات", "إيقاف لحماية الموثوقية")
            return null
        }

        val bars = candlesPair.first
        val dataSource = candlesPair.second
        val obRatio = orderbookRatio as Double
        val techSnap = TechnicalIndicatorEngine.analyze(targetSymbol, "1h", bars, obRatio, dataSource)
        @Suppress("UNCHECKED_CAST")
        val m15Bars = (m15Pair as Result<Pair<List<com.example.model.CandleBar>, String>>).getOrNull()?.first
        @Suppress("UNCHECKED_CAST")
        val h4Bars = (h4Pair as Result<Pair<List<com.example.model.CandleBar>, String>>).getOrNull()?.first
        val sniperReport = if (m15Bars != null && m15Bars.size >= 30 && h4Bars != null && h4Bars.size >= 30) {
            TechnicalIndicatorEngine.evaluateForwardSniperConfluence(targetSymbol, m15Bars, bars, h4Bars, obRatio, dataSource)
        } else null
        val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(Date(techSnap.fetchedAtMillis))

        val sniperMatrixLines = sniperReport?.let { sr ->
            val checkSummary = sr.checks.joinToString(" | ") { "${if (it.passed) "✓" else "✗"} ${it.titleAr} (${it.metricSummary})" }
            """
            [فحص القناص متعدد الأطر 15m/1h/4h اللحظي]: تطابق الدلائل ${sr.matchedCount}/${sr.totalCriteria} (${"%.0f".format(sr.evidenceScorePct)}%) — الاتجاه المرجح: ${sr.preferredSide}
            تفاصيل الدلائل الحية: $checkSummary
            محفز الحركة القادمة: ${sr.forwardCatalystAr}
            نقطة إبطال السيناريو القادم: ${sr.invalidationRuleAr}
            """.trimIndent()
        } ?: ""

        val liveDataBlock = """
            الأصل: ${techSnap.symbol} | قياس متعدد الأطر (15m + 1h + 4h) | المصدر: $dataSource | لحظة الرصد: $timeStr
            السعر الحي الفوري: ${formatUsdCents(techSnap.currentPrice)} | EMA20: ${"%.4f".format(techSnap.ema20)} | EMA50: ${"%.4f".format(techSnap.ema50)}
            RSI(14): ${"%.2f".format(techSnap.rsi14)} | ATR(14): ${"%.4f".format(techSnap.atr14)}
            BB Upper/Lower: ${"%.4f".format(techSnap.bollingerUpper)} / ${"%.4f".format(techSnap.bollingerLower)}
            منطقة الطلب (الدعم): ${"%.4f".format(techSnap.supportLevel)} | منطقة العرض (المقاومة): ${"%.4f".format(techSnap.resistanceLevel)}
            تدفق السيولة الآن (Bid/Ask): ${"%.2f".format(techSnap.orderbookBidAskRatio)} | تسارع الحجم: ${"%.2f".format(techSnap.volumeSpikeRatio)}x | الاتجاه: ${techSnap.trendBias}
            $sniperMatrixLines
        """.trimIndent()

        val customIntelSpecialists = agents.filter {
            it.approvedByOwner && !it.candidatePending && !it.blockedByOwner &&
                it.department == com.example.model.Department.MARKET_INTEL.name &&
                it.id !in setOf("mid_01", "ana_fund_01", "ana_tech_01", "ana_liq_01")
        }
        val activeTradersNote = agents.filter {
            it.approvedByOwner && !it.candidatePending && !it.blockedByOwner &&
                it.id !in setOf("ceo_01", "mid_01", "ana_fund_01", "ana_tech_01", "ana_liq_01", "hot_01", "trd_short_01", "trd_mid_01", "trd_multi_01", "sniper_01", "cro_01", "hr_01", "enforcer_01")
        }.joinToString("\n") {
            "- الموظف المعين [${it.nameAr} / ${it.roleAr} | IQ=${"%.0f".format(it.intelligenceScore)}]: ${it.specialization}"
        }

        val uncleSaab = agents.firstOrNull { it.id == "uncle_saab" && it.approvedByOwner && !it.blockedByOwner }
        val uncleSaabLesson = if (uncleSaab != null) {
            "\n[مساهمة الخبير المخضرم العم صعب 🛡️ | IQ=${"%.0f".format(uncleSaab.intelligenceScore)}]: تذكير بكشف مصائد السيولة (Stop-Hunts) والاختراقات الكاذبة قبل الاعتماد."
        } else ""

        val lessons = buildCollectiveMemoryContext(mid, agents, learningLogs) +
            if (activeTradersNote.isNotBlank()) "\nالخبرات المضافة عبر HR:\n$activeTradersNote$uncleSaabLesson" else uncleSaabLesson

        repository.updateAgentStatus("mid_01", AgentStatus.WORKING.label, "تحليل استشرافي متعدد الأطر لـ $targetSymbol")
        repository.updateAgentStatus("ana_fund_01", AgentStatus.RESEARCHING.label, "قراءة المحفزات القادمة لـ $targetSymbol")
        repository.updateAgentStatus("ana_tech_01", AgentStatus.ANALYZING.label, "رسم مسار السعر القادم 15m/1h/4h لـ $targetSymbol")
        repository.updateAgentStatus("ana_liq_01", AgentStatus.ANALYZING.label, "تحليل سيولة دفتر الأوامر الفورية لـ $targetSymbol")
        repository.updateAgentStatus("sniper_01", AgentStatus.ANALYZING.label, "تدقيق 5 دلائل القناص (${sniperReport?.matchedCount ?: 0}/5)")

        val (fundReport, techReport, liqReport) = coroutineScope {
            val f = async { runAnalystPrompt(fundAnalyst, "محلل الماكرو والمحفزات القادمة للأصل $targetSymbol. قدّم رؤية استشرافية لما يتجه إليه السوق تالياً دون تكهن أو اعتماد على تحاليل قديمة.", liveDataBlock, buildCollectiveMemoryContext(fundAnalyst, agents, learningLogs), onStatusUpdate) }
            val t = async { runAnalystPrompt(techAnalyst, "المحللة الفنية الاستشرافية لـ $targetSymbol. اقري مسار السعر القادم بناءً على توافق 15m/1h/4h الحالي والمساحة المتبقية للسيولة مع نقطة الإبطال الفورية.", liveDataBlock, buildCollectiveMemoryContext(techAnalyst, agents, learningLogs), onStatusUpdate) }
            val l = async { runAnalystPrompt(liqAnalyst, "محلل السيولة الفورية لـ $targetSymbol. أين تتجمع سيولة الأوامر القادمة (Liquidity Magnets) بناءً على Bid/Ask=${"%.2f".format(obRatio)} الآن؟", liveDataBlock, buildCollectiveMemoryContext(liqAnalyst, agents, learningLogs), onStatusUpdate) }
            Triple(f.await(), t.await(), l.await())
        }

        val customSpecialistNote = customIntelSpecialists.firstOrNull()?.let { spec ->
            repository.updateAgentStatus(spec.id, AgentStatus.ANALYZING.label, "تطبيق خبرته على $targetSymbol")
            runAnalystPrompt(spec, "أضف زاوية تخصصك (${spec.specialization}) للأصل $targetSymbol.", liveDataBlock, lessons, onStatusUpdate)
        }.orEmpty()

        repository.updateAgentStatus("ana_fund_01", AgentStatus.COMPLETED.label, "سلّم الرؤية الاستشرافية")
        repository.updateAgentStatus("ana_tech_01", AgentStatus.COMPLETED.label, "سلّمت مسار الأطر المتعددة")
        repository.updateAgentStatus("ana_liq_01", AgentStatus.COMPLETED.label, "سلّم خريطة السيولة القادمة")

        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "ana_fund_01", senderName = "د. كريم الخطيب (المحلل الأساسي)", senderRole = "Fundamental Analyst", recipientId = "mid_01", channel = "INTEL_DEBATE", content = fundReport, evidenceCited = "$dataSource Macro/Catalysts @ $timeStr", decisionReached = "تقييم المحفزات القادمة"))
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "ana_tech_01", senderName = "ليلى حداد (المحللة الفنية)", senderRole = "Technical Analyst", recipientId = "mid_01", channel = "INTEL_DEBATE", content = techReport, evidenceCited = "$dataSource (MTF 15m/1h/4h) @ $timeStr", decisionReached = "تحليل استشرافي مرفوع"))
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "ana_liq_01", senderName = "عمر القحطاني (محلل السيولة)", senderRole = "Liquidity Analyst", recipientId = "mid_01", channel = "INTEL_DEBATE", content = liqReport, evidenceCited = "Live Bid/Ask = ${"%.2f".format(obRatio)}", decisionReached = "تقييم السيولة القادمة"))
        if (sniperReport != null) {
            val badgeState = if (sniperReport.isFullSniperMatch) "✅ اكتمال 100% (5/5)" else "⏳ دلائل ${sniperReport.matchedCount}/5 (${"%.0f".format(sniperReport.evidenceScorePct)}%)"
            repository.addMessage(
                CorporateMessage(
                    taskId = taskId,
                    senderId = "sniper_01",
                    senderName = "القناص 🎯",
                    senderRole = "Precision Confluence Sniper",
                    recipientId = "mid_01",
                    channel = "WAR_ROOM",
                    content = "تقرير القناص على ${sniperReport.symbol}: $badgeState | الاتجاه: ${sniperReport.preferredSide}\n${sniperReport.forwardCatalystAr}\n${sniperReport.invalidationRuleAr}",
                    evidenceCited = "MFT 15m/1h/4h + Orderbook ${"%.2f".format(obRatio)} + R:R=${"%.2f".format(sniperReport.rewardToRisk)}:1",
                    decisionReached = if (sniperReport.isFullSniperMatch) "جاهز للقنص 100%" else "بانتظار اكتمال جميع الدلائل"
                )
            )
        }

        onStatusUpdate("مديرة تحليل السوق تدمج الرؤية المستقبلية الثلاثية مع النقد الذاتي والذاكرة الجماعية...")
        repository.updateAgentStatus("mid_01", AgentStatus.REVIEWING.label, "إصدار التقرير الاستشرافي الموحد")
        val unifiedPrompt = """
            أنتِ مديرة تحليل السوق (IQ=${"%.0f".format(mid?.intelligenceScore ?: 100.0)}).
            منهجية التفكير العميق + النقد الذاتي الإلزامية:
            1) يُمنع بناء القرار على تحاليل قديمة أو تكهن عشوائي؛ اعتمدي فقط على البيانات اللحظية الحالية.
            2) طبّقي [نقد ذاتي واختبار السيناريو المعاكس]: ما الذي قد يُفشل هذا الاتجاه (مصيدة سيولة / إبطال)، وهل يبرر R:R الدخول؟
            3) راعي دروس الذاكرة التراكمية والخبراء المعينين أدناه:
            $lessons
            أصدري تقريراً موحداً موجزاً بالعربية (حد أقصى 220 كلمة) يوضح: أين تتجه السيولة تالياً، تطابق دلائل القناص (${sniperReport?.matchedCount ?: 0}/5)، النقد الذاتي، هدف التحرك القادم، ونقطة الإبطال الدقيقة.
            البيانات اللحظية:
            $liveDataBlock
            [الأساسي]: ${fundReport.take(550)}
            [الفني]: ${techReport.take(550)}
            [السيولة]: ${liqReport.take(550)}
            ${if (customSpecialistNote.isNotBlank()) "[متخصص إضافي]: ${customSpecialistNote.take(350)}" else ""}
        """.trimIndent()

        val unifiedReport = generateStreamedTextWithRetry(
            primaryModelName = resolveModelName(mid, fallback = "gemini-3.8-flash"),
            schemaKey = "mid_unified_v3",
            maxTokens = 780,
            prompt = unifiedPrompt,
            timeoutMs = 60_000L,
            onStatusUpdate = onStatusUpdate
        )

        repository.updateAgentStatus("mid_01", AgentStatus.COMPLETED.label, "أصدرت التقرير الاستشرافي الموحد")
        repository.updateTask(taskId, mapOf("stage" to "TRADING_REVIEW", "assignedAgentId" to "hot_01", "unifiedReportSummary" to unifiedReport.take(7900)))
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "mid_01", senderName = "نادية الحربي (مديرة التحليل)", senderRole = "Market Intelligence Director", recipientId = "hot_01", channel = "WAR_ROOM", content = unifiedReport, evidenceCited = "$dataSource MTF | Sniper=${sniperReport?.matchedCount ?: 0}/5", decisionReached = "التقرير الاستشرافي جاهز"))

        return MarketIntelOutcome(unifiedReport, techSnap, sniperReport, dataSource, timeStr)
    }

    private suspend fun runTradingAndRiskStage(
        taskId: String,
        intel: MarketIntelOutcome,
        config: CompanyConfig,
        agents: List<AgentProfile>,
        strategies: List<TradingStrategy>,
        openTrades: List<TradeRecord>,
        closedTrades: List<TradeRecord>,
        brokerCreds: BrokerCredentials,
        onStatusUpdate: (String) -> Unit
    ): String {
        val hot = agents.firstOrNull { it.id == "hot_01" }
        repository.updateAgentStatus("hot_01", AgentStatus.REVIEWING.label, "تقييم السيناريو القادم وتوزيع التنفيذ")

        if (hot?.blockedByOwner == true) {
            val msg = "مدير التداول موقوف من المالك. التقرير الموحد:\n\n${intel.unifiedReport}"
            repository.updateTask(taskId, mapOf("stage" to "BLOCKED_BY_OWNER", "status" to "CLOSED", "outcomeSummary" to "مدير التداول موقوف"))
            postCeoReply(taskId, msg, "صلاحيات المالك", "إيقاف عند مدير التداول")
            return msg
        }

        val strategiesListText = strategies.joinToString("\n") {
            "ID=${it.id} | Name=${it.name} | Markets=${it.suitableMarkets} | LiveApproved=${it.approvedForLive} | Entry=${it.entryConditions}"
        }
        val sniperHint = intel.sniperReport?.let { sr ->
            "تقييم القناص الحي على ${sr.symbol}: ${sr.matchedCount}/5 (${"%.0f".format(sr.evidenceScorePct)}%) — إذا كانت 100% فأسند التنفيذ للقناص (sniper_01) بفضل اكتمال جميع الدلائل."
        } ?: ""

        val hotPrompt = """
            أنت مدير التداول المباشر. اعتمد حصراً على ذكاء الحركة القادمة والخبرة العملية اللحظية من تدفق الأوامر وتوافق الأطر الزمنية (15m/1h/4h) — لا تتكهن ولا تعتمد على قرارات ماضية منقضية.
            السعر الحي الآن لـ ${intel.techSnap.symbol}: ${intel.techSnap.currentPrice}
            $sniperHint
            الاستراتيجيات المتاحة:
            $strategiesListText
            التقرير الاستشرافي الموحد:
            ${intel.unifiedReport.take(1500)}
        """.trimIndent()

        val proposalText = generateJsonWithRetry(
            primaryModelName = resolveModelName(hot, fallback = "gemini-3.8-flash"),
            schemaKey = "hot_proposal_v2",
            schema = tradeProposalSchema,
            maxTokens = 512,
            prompt = hotPrompt,
            timeoutMs = 60_000L,
            onStatusUpdate = onStatusUpdate
        )

        val proposalJson = JSONObject(proposalText)
        val sniperReportRef = intel.sniperReport
        val sniperFullMatch = sniperReportRef?.isFullSniperMatch == true
        val shouldTrade = proposalJson.optBoolean("shouldTrade", sniperFullMatch) || sniperFullMatch
        val side = if (sniperReportRef != null && sniperFullMatch) sniperReportRef.preferredSide else proposalJson.optString("side", "BUY")
        val strategyId = proposalJson.optString("strategyId", strategies.firstOrNull()?.id ?: "strat_ema_sweep")
        val aiTraderId = proposalJson.optString("traderId", "trd_short_01")
        val traderId = if (sniperFullMatch) "sniper_01" else aiTraderId
        val slMult = proposalJson.optDouble("stopLossMultiplierAtr", 1.4).coerceIn(1.0, 2.5)
        val tpMult = proposalJson.optDouble("takeProfitMultiplierAtr", 2.8).coerceIn(2.0, 4.2)
        val rationaleAr = proposalJson.optString("rationaleAr", intel.sniperReport?.forwardCatalystAr ?: "")

        if (!shouldTrade) {
            repository.updateAgentStatus("hot_01", AgentStatus.COMPLETED.label, "أوصى بالانتظار لعدم اكتمال دلائل المستقبل")
            repository.updateTask(taskId, mapOf("stage" to "NO_TRADE_DISCIPLINE", "status" to "CLOSED", "tradingPlanSummary" to rationaleAr.take(3900), "outcomeSummary" to "عدم دخول صفقة — انضباط"))
            val finalMsg = "📊 التقرير الاستشرافي الموحد (${intel.techSnap.symbol}):\n${intel.unifiedReport}\n\n🛡️ قرار مدير التداول:\nتقرر عدم الدخول عشوائياً أو بالتكهن: $rationaleAr"
            postCeoReply(taskId, finalMsg, "${intel.dataSource} @ ${intel.timeStr}", "عدم الدخول — عدم اكتمال الشروط")
            listOf("ceo_01", "mid_01", "hot_01", "sniper_01").forEach { id ->
                agents.firstOrNull { it.id == id }?.let { ag ->
                    repository.recordAgentTaskCompletionOnly(
                        agent = ag,
                        newStatus = AgentStatus.COMPLETED.label,
                        currentTaskText = "انضباط عدم الدخول بدون دلائل مكتملة"
                    )
                }
            }
            return finalMsg
        }

        val chosenStrategy = strategies.firstOrNull { it.id == strategyId } ?: strategies.firstOrNull()
        val chosenTrader = agents.firstOrNull { it.id == traderId } ?: agents.firstOrNull { it.id == "trd_short_01" }
        val entryPrice = intel.techSnap.currentPrice
        val atrVal = intel.techSnap.atr14.coerceAtLeast(entryPrice * 0.0025)
        val stopLoss = if (side == "BUY") entryPrice - (slMult * atrVal) else entryPrice + (slMult * atrVal)
        val takeProfit = if (side == "BUY") entryPrice + (tpMult * atrVal) else entryPrice - (tpMult * atrVal)

        val planSummary = "خطة $side على ${intel.techSnap.symbol} | ${chosenStrategy?.name ?: strategyId} | دخول ${"%.2f".format(entryPrice)} | SL ${"%.2f".format(stopLoss)} | TP ${"%.2f".format(takeProfit)}\n$rationaleAr"
        repository.updateTask(taskId, mapOf("stage" to "RISK_GATE", "assignedAgentId" to "cro_01", "tradingPlanSummary" to planSummary.take(3900)))
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "hot_01", senderName = "فيصل الراشد (مدير التداول)", senderRole = "Head of Trading", recipientId = "cro_01", channel = "WAR_ROOM", content = planSummary, evidenceCited = "سعر حي ${"%.2f".format(entryPrice)}", decisionReached = "مرفوع لقسم المخاطر المستقل"))

        onStatusUpdate("قسم المخاطر المستقل يفحص حدود المخاطرة والرافعة...")
        repository.updateAgentStatus("cro_01", AgentStatus.REVIEWING.label, "فحص المخاطر المستقل لخطة ${intel.techSnap.symbol}")
        val riskEval = RiskEngine.evaluateTradeProposal(
            config = config,
            strategy = chosenStrategy,
            trader = chosenTrader,
            openTrades = openTrades,
            closedTradesInMode = closedTrades.filter { it.mode == config.tradingMode },
            symbol = intel.techSnap.symbol,
            side = side,
            entryPrice = entryPrice,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
            marketDataTimestampMillis = intel.techSnap.fetchedAtMillis
        )

        val riskReportText = riskEval.reasonsAr.joinToString("\n• ", prefix = "• ")
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "cro_01", senderName = "سلطان الغامدي (رئيس المخاطر)", senderRole = "Chief Risk Officer", recipientId = "ceo_01", channel = "RISK_AUDIT", content = "قرار المخاطر [${riskEval.approvalId}]:\n$riskReportText", evidenceCited = "Mode=${config.tradingMode} | RiskCap=${config.maxRiskPerTradePct}%", decisionReached = if (riskEval.approved) "موافقة المخاطر" else "VETO"))

        if (!riskEval.approved) {
            repository.updateTask(taskId, mapOf("stage" to "RISK_VETOED", "status" to "CLOSED", "riskVerdict" to riskReportText.take(1900), "outcomeSummary" to "رفض قسم المخاطر تنفيذ الصفقة"))
            repository.addAuditLog("CRO", "RISK_VETO", "رفض صفقة ${intel.techSnap.symbol}: ${riskEval.reasonsAr.firstOrNull()}", "WARNING")
            val vetoReply = "📊 التقرير الموحد (${intel.techSnap.symbol}):\n${intel.unifiedReport}\n\n⛔ قرار قسم المخاطر المستقل (${riskEval.approvalId}):\n$riskReportText"
            postCeoReply(taskId, vetoReply, riskEval.approvalId, "تم المنع بواسطة قسم المخاطر المستقل")
            agents.firstOrNull { it.id == "cro_01" }?.let { croAgent ->
                repository.recordAgentTaskCompletionOnly(
                    agent = croAgent,
                    newStatus = AgentStatus.COMPLETED.label,
                    currentTaskText = "فحص المخاطر: VETO (الترقية مرتبطة بالأرباح فقط)"
                )
            }
            repository.updateAgentStatus("ceo_01", AgentStatus.COMPLETED.label, "أبلغ المالك برفض المخاطر")
            return vetoReply
        }

        return executeApprovedTradeStage(
            taskId = taskId,
            intel = intel,
            config = config,
            agents = agents,
            chosenStrategy = chosenStrategy,
            chosenTrader = chosenTrader,
            side = side,
            entryPrice = entryPrice,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
            qty = riskEval.computedPositionQty,
            approvalId = riskEval.approvalId,
            riskReportText = riskReportText,
            rationaleAr = rationaleAr,
            brokerCreds = brokerCreds
        )
    }

    private suspend fun executeApprovedTradeStage(
        taskId: String,
        intel: MarketIntelOutcome,
        config: CompanyConfig,
        agents: List<AgentProfile>,
        chosenStrategy: TradingStrategy?,
        chosenTrader: AgentProfile?,
        side: String,
        entryPrice: Double,
        stopLoss: Double,
        takeProfit: Double,
        qty: Double,
        approvalId: String,
        riskReportText: String,
        rationaleAr: String,
        brokerCreds: BrokerCredentials
    ): String {
        val execTraderId = chosenTrader?.id ?: "trd_short_01"
        repository.updateAgentStatus(execTraderId, AgentStatus.TRADING.label, "تنفيذ $side على ${intel.techSnap.symbol}")

        val orderRes = brokerConnector.submitOrder(
            creds = brokerCreds,
            symbol = intel.techSnap.symbol,
            side = side,
            quantity = qty,
            isLiveMode = config.tradingMode == "LIVE"
        )

        val brokerOrderId = orderRes.getOrElse { err ->
            repository.updateAgentStatus(execTraderId, AgentStatus.ERROR.label, "فشل إرسال الأمر للوسيط")
            repository.addAuditLog(execTraderId, "BROKER_ORDER_FAILED", err.message ?: "Error", "CRITICAL")
            repository.updateTask(taskId, mapOf("stage" to "BROKER_ERROR", "status" to "CLOSED", "outcomeSummary" to "خطأ اتصال بالوسيط"))
            val errReply = "وافقت المخاطر ($approvalId) لكن تعذر إرسال الأمر للوسيط: ${err.localizedMessage}"
            postCeoReply(taskId, errReply, "Broker REST API", "فشل تنفيذ الوسيط")
            return errReply
        }

        val notional = entryPrice * qty
        val tradeId = repository.createTrade(
            TradeRecord(
                symbol = intel.techSnap.symbol,
                side = side,
                mode = config.tradingMode,
                status = "OPEN",
                strategyId = chosenStrategy?.id ?: "strat_ema_sweep",
                strategyName = chosenStrategy?.name ?: "Institutional Strategy",
                traderId = execTraderId,
                traderName = chosenTrader?.nameAr ?: "Trader",
                entryPrice = entryPrice,
                exitPrice = 0.0,
                quantity = qty,
                stopLoss = stopLoss,
                takeProfit = takeProfit,
                feesPaid = notional * 0.0010,
                slippageCost = notional * 0.0005,
                realizedPnl = 0.0,
                rationale = rationaleAr,
                riskApprovalId = approvalId,
                brokerOrderId = brokerOrderId
            )
        ).getOrElse { err ->
            repository.updateAgentStatus(execTraderId, AgentStatus.ERROR.label, "فشل حفظ الصفقة في Firestore")
            repository.updateTask(taskId, mapOf("stage" to "FIRESTORE_ERROR", "status" to "CLOSED", "outcomeSummary" to "تعذر حفظ سجل الصفقة"))
            val saveErrMsg = "نُفّذ الأمر لدى الوسيط ($brokerOrderId) ولكن تعذر حفظ السجل في Firestore: ${err.localizedMessage}"
            postCeoReply(taskId, saveErrMsg, "Firestore Trade Persistence", "فشل حفظ السجل")
            return saveErrMsg
        }

        repository.addLearningLog(
            LearningLog(
                agentId = execTraderId,
                agentName = chosenTrader?.nameAr ?: "Trader",
                taskId = taskId,
                tradeId = tradeId,
                errorType = "INSIGHT",
                decisionSummary = "تنفيذ $side على ${intel.techSnap.symbol} بسعر ${"%.2f".format(entryPrice)} (${config.tradingMode})",
                evidenceUsed = "${intel.dataSource} | RSI=${"%.1f".format(intel.techSnap.rsi14)}",
                actualOutcome = "صفقة مفتوحة برقم أمر $brokerOrderId",
                rootCause = "توافق التحليل الموحد + موافقة المخاطر $approvalId",
                financialImpact = 0.0,
                correctiveAction = "مراقبة SL ${"%.2f".format(stopLoss)} و TP ${"%.2f".format(takeProfit)}",
                recurred = false,
                knowledgeRuleAdded = "تحقق من حداثة البيانات وشروط ${chosenStrategy?.name ?: "الاستراتيجية"}."
            )
        )

        repository.addAuditLog(
            actor = "${chosenTrader?.nameAr ?: execTraderId} (${config.tradingMode})",
            actionType = "TRADE_EXECUTED",
            details = "$side ${"%.4f".format(qty)} ${intel.techSnap.symbol} @ ${"%.2f".format(entryPrice)} | CRO=$approvalId | Order=$brokerOrderId",
            severity = if (config.tradingMode == "LIVE") "WARNING" else "INFO"
        )

        listOf("ceo_01", "mid_01", "ana_fund_01", "ana_tech_01", "ana_liq_01", "hot_01", "cro_01", execTraderId)
            .distinct()
            .forEach { id ->
                val ag = agents.firstOrNull { it.id == id }
                if (ag != null) {
                    repository.recordAgentTaskCompletionOnly(
                        agent = ag,
                        newStatus = AgentStatus.TRADING.label,
                        currentTaskText = "صفقة مفتوحة على ${intel.techSnap.symbol} — الترقية تُحتسب عند إغلاق الربح"
                    )
                }
            }

        repository.updateTask(taskId, mapOf("stage" to "EXECUTED_AND_MONITORED", "status" to "CLOSED", "riskVerdict" to riskReportText.take(1900), "outcomeSummary" to "تم التنفيذ برقم $brokerOrderId"))

        val estWinUsd = abs(takeProfit - entryPrice) * qty - (notional * 0.003)
        val finalCeoMsg = """
            ✅ تم تنفيذ الدورة المؤسسية للأصل **${intel.techSnap.symbol}** (${config.tradingMode}):
            
            1️⃣ **التقرير الموحد:**
            ${intel.unifiedReport}
            
            2️⃣ **التنفيذ (${chosenTrader?.nameAr ?: execTraderId}):**
            • الاتجاه: **$side** | الكمية: **${"%.4f".format(qty)}**
            • الدخول الحي: **${formatUsdCents(entryPrice)}** (${intel.dataSource})
            • وقف الخسارة: **${formatUsdCents(stopLoss)}** | جني الأرباح: **${formatUsdCents(takeProfit)}**
            • صافي الربح المستهدف عند TP: **${formatUsdCents(estWinUsd, signed = true)}**
            • رقم الأمر: `$brokerOrderId` | اعتماد المخاطر: `$approvalId`
            🏅 *ملاحظة النظام: تُمنح الترقيات والشارات للفريق فقط عند إغلاق الصفقة بربح مالي حقيقي.*
        """.trimIndent()

        postCeoReply(taskId, finalCeoMsg, "${intel.dataSource} | $approvalId", "تم التنفيذ والمراقبة المستمرة")
        return finalCeoMsg
    }

    /**
     * High-Effort Multi-Asset Profit Target Campaign:
     * Mobilizes CEO, Market Intelligence, all 3 Analysts, Head of Trading, all 3 Traders, CRO & HR
     * across ALL 5 live markets to build and execute a concrete multi-position profit roadmap
     * for the Owner's exact USD profit goal (e.g., "أريد جني 2999 دولار").
     */
    private suspend fun runProfitTargetCampaign(
        ownerCommand: String,
        targetProfitUsd: Double,
        ceoPlanAr: String,
        config: CompanyConfig,
        agents: List<AgentProfile>,
        strategies: List<TradingStrategy>,
        openTrades: List<TradeRecord>,
        closedTrades: List<TradeRecord>,
        learningLogs: List<LearningLog>,
        brokerCreds: BrokerCredentials,
        onStatusUpdate: (String) -> Unit
    ): String {
        val taskId = repository.createTask(
            CorporateTask(
                ownerOrder = ownerCommand,
                stage = "PROFIT_CAMPAIGN_SCAN",
                status = "ACTIVE",
                assignedAgentId = "ceo_01",
                targetAsset = "ALL_MARKETS",
                ceoPlan = "حملة شاملة لجميع الموظفين لجني ${formatUsdCents(targetProfitUsd)}"
            )
        ).getOrThrow()

        postCeoReply(
            taskId = taskId,
            content = "استلمت هدفك المباشر يا مالك الشركة: **${formatUsdCents(targetProfitUsd)}**.\nالخطة التنفيذية: $ceoPlanAr\nأصدرتُ الآن أمراً استنفارياً لجميع الإدارات والموظفين الـ 11 لمسح جميع الأسواق الـ 5 الحية (الذهب، البيتكوين، الإيثريوم، سولانا، اليورو) وبناء خطة تنفيذية متعددة الصفقات لتحقيق هذا الربح بأقصى جهد وانضباط.",
            evidence = "هدف الربح المعتمد: ${formatUsdCents(targetProfitUsd)}",
            decision = "استنفار الشركة بالكامل لتحقيق هدف الربح"
        )

        onStatusUpdate("الجميع في حالة استنفار: فحص الأسواق الـ 5 الحية (الذهب، BTC، ETH، SOL، EUR)...")
        repository.updateAgentStatus("ceo_01", AgentStatus.WORKING.label, "قيادة حملة جني ${formatUsdCents(targetProfitUsd)}")
        repository.updateAgentStatus("mid_01", AgentStatus.WORKING.label, "مسح جميع الأسواق الـ 5 الحية")
        repository.updateAgentStatus("ana_fund_01", AgentStatus.RESEARCHING.label, "تحليل الماكرو والفرص عبر 5 أصول")
        repository.updateAgentStatus("ana_tech_01", AgentStatus.ANALYZING.label, "تقييم المؤشرات الفنية للأسواق الـ 5")
        repository.updateAgentStatus("ana_liq_01", AgentStatus.ANALYZING.label, "فحص السيولة ودفتر الأوامر للأسواق الـ 5")
        repository.updateAgentStatus("hr_01", AgentStatus.REVIEWING.label, "مراقبة جاهزية المنفذين لهدف ${formatUsdCents(targetProfitUsd)}")

        val scannedMarkets = coroutineScope {
            marketService.trackedAssets.map { spec ->
                async {
                    val h1D = async { marketService.fetchCandles(spec.symbol, interval = "1h", limit = 160) }
                    val m15D = async { marketService.fetchCandles(spec.symbol, interval = "15m", limit = 90) }
                    val h4D = async { marketService.fetchCandles(spec.symbol, interval = "4h", limit = 90) }
                    val obD = async { marketService.fetchOrderbookBidAskRatio(spec.symbol) }

                    val h1Res = h1D.await()
                    val m15Res = m15D.await()
                    val h4Res = h4D.await()
                    val ratio = obD.await()

                    h1Res.getOrNull()?.let { (bars, src) ->
                        if (bars.size >= 50) {
                            val snap = TechnicalIndicatorEngine.analyze(spec.symbol, "1h", bars, ratio, src)
                            val m15Bars = m15Res.getOrNull()?.first
                            val h4Bars = h4Res.getOrNull()?.first
                            val sniper = if (m15Bars != null && m15Bars.size >= 30 && h4Bars != null && h4Bars.size >= 30) {
                                TechnicalIndicatorEngine.evaluateForwardSniperConfluence(spec.symbol, m15Bars, bars, h4Bars, ratio, src)
                            } else null
                            scoreMarketSetup(spec.symbol, snap, sniper, src)
                        } else null
                    }
                }
            }.mapNotNull { it.await() }.sortedByDescending { it.score }
        }

        if (scannedMarkets.isEmpty()) {
            repository.updateTask(taskId, mapOf("stage" to "ABORTED_DATA_ERROR", "status" to "CLOSED", "outcomeSummary" to "تعذر جلب بيانات الأسواق الحية"))
            val errMsg = "تعذر جلب بيانات الأسواق الحية لإطلاق الحملة. يرجى التحقق من اتصال الإنترنت وسأعاود العمل فوراً."
            postCeoReply(taskId, errMsg, "MarketDataService", "توقف مؤقت لانقطاع البيانات")
            return errMsg
        }

        val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(Date(scannedMarkets.first().snap.fetchedAtMillis))
        val marketMatrixBlock = scannedMarkets.joinToString("\n") { m ->
            val s = m.snap
            val sniperTxt = m.sniperReport?.let { " | القناص=${it.matchedCount}/5 (${"%.0f".format(it.evidenceScorePct)}%)" } ?: ""
            "• ${m.symbol}: السعر=${formatUsdCents(s.currentPrice)} | الاتجاه=${s.trendBias} (${m.preferredSide}) | RSI=${"%.1f".format(s.rsi14)} | Volume=${"%.2f".format(s.volumeSpikeRatio)}x | Bid/Ask=${"%.2f".format(s.orderbookBidAskRatio)}$sniperTxt | تقييم قادم=${"%.1f".format(m.score)}"
        }

        val lessons = learningLogs.take(4).joinToString("\n") {
            "- [قاعدة انضباط فقط]: ${it.knowledgeRuleAdded.ifBlank { it.correctiveAction }}"
        }.ifBlank { "لا توجد قواعد انضباط سابقة." }

        onStatusUpdate("المحللون الثلاثة والقناص يحللون الفرص القادمة لهدف ${formatUsdCents(targetProfitUsd)}...")
        val (fundReport, techReport, liqReport) = coroutineScope {
            val f = async { runAnalystPrompt(agents.firstOrNull { it.id == "ana_fund_01" }, "قراءة المحفزات القادمة عبر الأسواق الـ 5 لهدف ${formatUsdCents(targetProfitUsd)} بدون الاعتماد على تحاليل ماضية.", marketMatrixBlock, lessons, onStatusUpdate) }
            val t = async { runAnalystPrompt(agents.firstOrNull { it.id == "ana_tech_01" }, "تحديد المسارات السعرية القادمة على الأطر 15m/1h/4h ونقاط الإبطال لأفضل 3 أزواج.", marketMatrixBlock, lessons, onStatusUpdate) }
            val l = async { runAnalystPrompt(agents.firstOrNull { it.id == "ana_liq_01" }, "تحديد تدفق السيولة القادم وأفضل 3 أصول حسب دفتر الأوامر اللحظي لهدف ${formatUsdCents(targetProfitUsd)}.", marketMatrixBlock, lessons, onStatusUpdate) }
            Triple(f.await(), t.await(), l.await())
        }

        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "ana_fund_01", senderName = "د. كريم الخطيب (المحلل الأساسي)", senderRole = "Fundamental Analyst", recipientId = "mid_01", channel = "INTEL_DEBATE", content = fundReport, evidenceCited = "5-Market Catalysts @ $timeStr", decisionReached = "مرفوع لمديرة التحليل"))
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "ana_tech_01", senderName = "ليلى حداد (المحللة الفنية)", senderRole = "Technical Analyst", recipientId = "mid_01", channel = "INTEL_DEBATE", content = techReport, evidenceCited = "5-Market MTF Matrix @ $timeStr", decisionReached = "مرفوع لمديرة التحليل"))
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "ana_liq_01", senderName = "عمر القحطاني (محلل السيولة)", senderRole = "Liquidity Analyst", recipientId = "mid_01", channel = "INTEL_DEBATE", content = liqReport, evidenceCited = "5-Market Live Orderbooks", decisionReached = "مرفوع لمديرة التحليل"))

        val midPrompt = """
            أنتِ مديرة تحليل السوق. المالك طلب هدف ربح **${formatUsdCents(targetProfitUsd)}**.
            استخدمي الرؤية الاستشرافية اللحظية (وليس تحاليل قديمة أو تكهناً) بناءً على مصفوفة الأسواق الـ 5 وتطابق دلائل القناص لاختيار أقوى الأصول للخطوة القادمة (حد أقصى 180 كلمة).
            المصفوفة الحية:
            $marketMatrixBlock
            [الأساسي]: ${fundReport.take(450)}
            [الفني]: ${techReport.take(450)}
            [السيولة]: ${liqReport.take(450)}
        """.trimIndent()
        val masterIntelReport = generateStreamedTextWithRetry(
            primaryModelName = resolveModelName(agents.firstOrNull { it.id == "mid_01" }, fallback = "gemini-3.8-flash"),
            schemaKey = "mid_campaign_v2",
            maxTokens = 650,
            prompt = midPrompt,
            timeoutMs = 60_000L,
            onStatusUpdate = onStatusUpdate
        )
        repository.addMessage(CorporateMessage(taskId = taskId, senderId = "mid_01", senderName = "نادية الحربي (مديرة التحليل)", senderRole = "Market Intelligence Director", recipientId = "hot_01", channel = "WAR_ROOM", content = masterIntelReport, evidenceCited = "مسح 5 أسواق متعددة الأطر", decisionReached = "ترشيح أفضل الأصول للربح القادم"))

        onStatusUpdate("مدير التداول والمنفذون والقناص يوزعون الصفقات لتحقيق ${formatUsdCents(targetProfitUsd)}...")
        repository.updateAgentStatus("hot_01", AgentStatus.WORKING.label, "توزيع الصفقات الاستشرافية لهدف ${formatUsdCents(targetProfitUsd)}")

        val activeSymbols = openTrades.filter { it.mode == config.tradingMode && it.status == "OPEN" }.map { it.symbol }.toSet()
        val freeSlots = (config.maxOpenPositions.toInt() - activeSymbols.size).coerceIn(0, 3)
        val eligibleMarkets = scannedMarkets.filter { it.symbol !in activeSymbols }

        val strategiesText = strategies.joinToString("\n") { "ID=${it.id} | Name=${it.name} | Entry=${it.entryConditions}" }
        val hotCampaignPrompt = """
            أنت مدير التداول المباشر. هدف الشركة الأول جني الربح الحقيقي للمالك بالذكاء والخبرة الاستشرافية اللحظية.
            أمر المالك: **${formatUsdCents(targetProfitUsd)}**.
            الخانات الحرة: $freeSlots (الأصول المفتوحة حالياً مستبعدة: $activeSymbols).
            اختر أفضل $freeSlots فرصة من الأسواق المؤهلة ووزعها على المنفذين (trd_short_01, trd_mid_01, trd_multi_01 أو sniper_01 للفرص ذات دلائل 100%).
            الأسواق المؤهلة:
            ${eligibleMarkets.joinToString("\n") { "${it.symbol}: Price=${it.snap.currentPrice}, SuggestedSide=${it.preferredSide}, RSI=${"%.1f".format(it.snap.rsi14)}, Sniper=${it.sniperReport?.matchedCount ?: 0}/5, Score=${"%.1f".format(it.score)}" }}
            الاستراتيجيات:
            $strategiesText
            التقرير الاستشرافي:
            ${masterIntelReport.take(900)}
        """.trimIndent()

        val proposalRaw = generateJsonWithRetry(
            primaryModelName = resolveModelName(agents.firstOrNull { it.id == "hot_01" }, fallback = "gemini-3.8-flash"),
            schemaKey = "hot_campaign_v2",
            schema = campaignProposalsSchema,
            maxTokens = 900,
            prompt = hotCampaignPrompt,
            timeoutMs = 60_000L,
            onStatusUpdate = onStatusUpdate
        )

        val proposalJson = JSONObject(proposalRaw)
        val campaignSummaryAr = proposalJson.optString("campaignStrategySummaryAr", "")
        val proposedArr = proposalJson.optJSONArray("trades")

        data class PlannedOrder(
            val symbol: String,
            val side: String,
            val strategyId: String,
            val traderId: String,
            val slMult: Double,
            val tpMult: Double,
            val rationaleAr: String
        )

        val plannedOrders = mutableListOf<PlannedOrder>()
        val usedSymbols = mutableSetOf<String>()
        if (proposedArr != null) {
            for (i in 0 until proposedArr.length()) {
                if (plannedOrders.size >= freeSlots) break
                val item = proposedArr.optJSONObject(i) ?: continue
                val sym = item.optString("symbol", "")
                if (sym.isBlank() || sym in usedSymbols || sym in activeSymbols) continue
                val matchedMarket = eligibleMarkets.firstOrNull { it.symbol == sym } ?: continue
                usedSymbols.add(sym)
                val sniperEnabled = config.sniperEnabled && agents.firstOrNull { it.id == "sniper_01" }?.blockedByOwner != true
                val mSniper = matchedMarket.sniperReport
                val fullSniper = sniperEnabled && mSniper?.isFullSniperMatch == true
                plannedOrders.add(
                    PlannedOrder(
                        symbol = sym,
                        side = if (mSniper != null && fullSniper) mSniper.preferredSide else if (item.optString("side") == "SELL") "SELL" else "BUY",
                        strategyId = item.optString("strategyId", strategies.firstOrNull()?.id ?: "strat_ema_sweep"),
                        traderId = if (fullSniper) "sniper_01" else item.optString("traderId", listOf("trd_short_01", "trd_mid_01", "trd_multi_01")[plannedOrders.size % 3]),
                        slMult = item.optDouble("stopLossMultiplierAtr", 1.4).coerceIn(1.2, 2.2),
                        tpMult = item.optDouble("takeProfitMultiplierAtr", 2.9).coerceIn(2.0, 4.2),
                        rationaleAr = item.optString("rationaleAr", matchedMarket.sniperReport?.forwardCatalystAr ?: "استغلال الزخم اللحظي لهدف ${formatUsdCents(targetProfitUsd)}")
                    )
                )
            }
        }

        if (plannedOrders.isEmpty() && freeSlots > 0 && eligibleMarkets.isNotEmpty()) {
            val sniperEnabledFallback = config.sniperEnabled && agents.firstOrNull { it.id == "sniper_01" }?.blockedByOwner != true
            val tradersCycle = listOf("trd_short_01", "trd_mid_01", "trd_multi_01")
            eligibleMarkets.take(minOf(freeSlots, 2)).forEachIndexed { idx, market ->
                val fullSniper = sniperEnabledFallback && market.sniperReport?.isFullSniperMatch == true
                plannedOrders.add(
                    PlannedOrder(
                        symbol = market.symbol,
                        side = market.preferredSide,
                        strategyId = strategies.firstOrNull()?.id ?: "strat_ema_sweep",
                        traderId = if (fullSniper) "sniper_01" else tradersCycle[idx % tradersCycle.size],
                        slMult = 1.4,
                        tpMult = 3.0,
                        rationaleAr = market.sniperReport?.forwardCatalystAr ?: "خطة استشرافية لـ ${market.symbol} ضمن حملة ${formatUsdCents(targetProfitUsd)}"
                    )
                )
            }
        }

        onStatusUpdate("قسم المخاطر (CRO) يراجع الصفقات ويبدأ التنفيذ الفوري...")
        val workingOpenTrades = openTrades.toMutableList()
        val executedLines = mutableListOf<String>()
        val rejectedLines = mutableListOf<String>()
        var totalExpectedProfitAtTp = 0.0

        for (plan in plannedOrders) {
            val mkt = scannedMarkets.firstOrNull { it.symbol == plan.symbol } ?: continue
            val entry = mkt.snap.currentPrice
            val atr = mkt.snap.atr14.coerceAtLeast(entry * 0.003)
            val sl = if (plan.side == "BUY") entry - (plan.slMult * atr) else entry + (plan.slMult * atr)
            val tp = if (plan.side == "BUY") entry + (plan.tpMult * atr) else entry - (plan.tpMult * atr)
            val chosenStrategy = strategies.firstOrNull { it.id == plan.strategyId } ?: strategies.firstOrNull()
            val chosenTrader = agents.firstOrNull { it.id == plan.traderId } ?: agents.firstOrNull { it.id == "trd_short_01" }

            val riskEval = RiskEngine.evaluateTradeProposal(
                config = config,
                strategy = chosenStrategy,
                trader = chosenTrader,
                openTrades = workingOpenTrades,
                closedTradesInMode = closedTrades.filter { it.mode == config.tradingMode },
                symbol = plan.symbol,
                side = plan.side,
                entryPrice = entry,
                stopLoss = sl,
                takeProfit = tp,
                marketDataTimestampMillis = mkt.snap.fetchedAtMillis
            )

            if (!riskEval.approved) {
                rejectedLines.add("• ${plan.symbol}: مرفوضة من المخاطر (${riskEval.reasonsAr.firstOrNull() ?: "Risk Veto"})")
                continue
            }

            val qty = riskEval.computedPositionQty
            val orderRes = brokerConnector.submitOrder(
                creds = brokerCreds,
                symbol = plan.symbol,
                side = plan.side,
                quantity = qty,
                isLiveMode = config.tradingMode == "LIVE"
            )
            val brokerOrderId = orderRes.getOrNull()
            if (brokerOrderId == null) {
                rejectedLines.add("• ${plan.symbol}: تعذر إرسال الأمر للوسيط")
                continue
            }

            val notional = entry * qty
            val estEntryFees = notional * 0.0010
            val estEntrySlip = notional * 0.0005
            val newTrade = TradeRecord(
                symbol = plan.symbol,
                side = plan.side,
                mode = config.tradingMode,
                status = "OPEN",
                strategyId = chosenStrategy?.id ?: "strat_ema_sweep",
                strategyName = chosenStrategy?.name ?: "Institutional Profit Strategy",
                traderId = chosenTrader?.id ?: "trd_short_01",
                traderName = chosenTrader?.nameAr ?: "Trader",
                entryPrice = entry,
                exitPrice = 0.0,
                quantity = qty,
                stopLoss = sl,
                takeProfit = tp,
                feesPaid = estEntryFees,
                slippageCost = estEntrySlip,
                realizedPnl = 0.0,
                rationale = plan.rationaleAr,
                riskApprovalId = riskEval.approvalId,
                brokerOrderId = brokerOrderId
            )
            val createdId = repository.createTrade(newTrade).getOrElse { err ->
                rejectedLines.add("• ${plan.symbol}: تعذر حفظ الصفقة في Firestore (${err.localizedMessage})")
                continue
            }
            workingOpenTrades.add(newTrade.copy(id = createdId))

            val estNetTpUsd = abs(tp - entry) * qty - (notional * 0.003)
            totalExpectedProfitAtTp += estNetTpUsd
            executedLines.add(
                "• **${plan.symbol} (${plan.side})** — ${chosenTrader?.nameAr ?: plan.traderId}\n  دخول ${formatUsdCents(entry)} | SL ${formatUsdCents(sl)} | TP ${formatUsdCents(tp)} | ربح متوقع عند الهدف: **${formatUsdCents(estNetTpUsd, signed = true)}**"
            )
            repository.addAuditLog(
                actor = "${chosenTrader?.nameAr ?: plan.traderId}",
                actionType = "PROFIT_CAMPAIGN_TRADE",
                details = "${plan.side} ${"%.4f".format(qty)} ${plan.symbol} @ ${formatUsdCents(entry)} (هدف الحملة ${formatUsdCents(targetProfitUsd)})",
                severity = "INFO"
            )
        }

        agents.filter { it.approvedByOwner && !it.candidatePending && !it.blockedByOwner }.forEach { ag ->
            repository.recordAgentTaskCompletionOnly(
                agent = ag,
                newStatus = if (executedLines.isNotEmpty()) AgentStatus.TRADING.label else AgentStatus.WORKING.label,
                currentTaskText = "يعمل على تحقيق هدف ${formatUsdCents(targetProfitUsd)} (الترقية عند جني الربح)"
            )
        }

        val outcomeSummary = "فتح ${executedLines.size} صفقات نحو هدف ${formatUsdCents(targetProfitUsd)}"
        repository.updateTask(
            taskId,
            mapOf(
                "stage" to "CAMPAIGN_ACTIVE",
                "status" to "CLOSED",
                "tradingPlanSummary" to campaignSummaryAr.take(3900),
                "outcomeSummary" to outcomeSummary.take(1900)
            )
        )

        val execSection = if (executedLines.isEmpty()) {
            "⚠️ لم تتوافر خانات حرة أو إشارات مجتازة للمخاطر في هذه اللحظة (${rejectedLines.joinToString("؛ ")})."
        } else {
            executedLines.joinToString("\n")
        }

        val estimatedRounds = if (totalExpectedProfitAtTp > 1.0) {
            kotlin.math.ceil(targetProfitUsd / totalExpectedProfitAtTp).toInt().coerceAtLeast(1)
        } else 1

        val finalReply = """
            🎯 **تقرير الحملة الشاملة لهدف الربح: ${formatUsdCents(targetProfitUsd)}**
            
            1️⃣ **ملخص المسح الاستشرافي للأسواق الـ 5 (15m/1h/4h + القناص):**
            ${scannedMarkets.take(5).joinToString("\n") { "• ${it.symbol}: ${formatUsdCents(it.snap.currentPrice)} | ${it.snap.trendBias} | القناص ${it.sniperReport?.matchedCount ?: 0}/5 (${"%.0f".format(it.sniperReport?.evidenceScorePct ?: 0.0)}%)" }}
            
            2️⃣ **استراتيجية مدير التداول والمتداولين:**
            ${campaignSummaryAr.ifBlank { masterIntelReport.take(500) }}
            
            3️⃣ **الصفقات المنفذة الآن (${executedLines.size}):**
            $execSection
            
            💰 **تقدير الربح عند تحقق أهداف الدفعة الحالية:** **${formatUsdCents(totalExpectedProfitAtTp, signed = true)}** (نحو $estimatedRounds دورات ربح لبلوغ **${formatUsdCents(targetProfitUsd)}**).
            🏦 **خزنة الأمان:** 10% من صافي ربح كل صفقة تُحوَّل تلقائياً لخزنة أمان الشركة ولا تُسحب إلا بتدخلك الشخصي.
        """.trimIndent()

        postCeoReply(taskId, finalReply, "مسح 5 أسواق متعدد الأطر + موافقة CRO + تنفيذ ${executedLines.size} صفقات", outcomeSummary)
        return finalReply
    }

    /**
     * Elite Sniper (القناص 🎯) Workflow:
     * Evaluates all 5 live markets across 15m, 1h, and 4h timeframes + real-time orderbook liquidity.
     * Fires ONLY if 5/5 (100%) confluence evidences align and CRO Risk Gate approves.
     */
    private suspend fun runSniperStrikeWorkflow(
        ownerCommand: String,
        ceoPlanAr: String,
        config: CompanyConfig,
        agents: List<AgentProfile>,
        strategies: List<TradingStrategy>,
        openTrades: List<TradeRecord>,
        closedTrades: List<TradeRecord>,
        brokerCreds: BrokerCredentials,
        onStatusUpdate: (String) -> Unit
    ): String {
        val sniper = agents.firstOrNull { it.id == "sniper_01" }
        val taskId = repository.createTask(
            CorporateTask(
                ownerOrder = ownerCommand,
                stage = "SNIPER_CONFLUENCE_SCAN",
                status = "ACTIVE",
                assignedAgentId = "sniper_01",
                targetAsset = "ALL_MARKETS",
                ceoPlan = ceoPlanAr
            )
        ).getOrThrow()

        if (!config.sniperEnabled || sniper?.blockedByOwner == true) {
            val disabledMsg = "🎯 عمليات **القناص (Sniper Agent)** معطّلة حالياً من لوحة التحكم الإدارية (Admin Panel). فعّل مفتاح القناص من تبويب «التحكم» لاستئناف عمليات الصيد بدلائل 100%."
            repository.updateAgentStatus("sniper_01", AgentStatus.ERROR.label, "عمليات القناص معطلة من لوحة الإدارة")
            repository.updateTask(taskId, mapOf("stage" to "SNIPER_DISABLED_BY_ADMIN", "status" to "CLOSED", "outcomeSummary" to disabledMsg))
            postCeoReply(taskId, disabledMsg, "Admin Panel -> sniperEnabled=${config.sniperEnabled}", "القناص معطّل إدارياً")
            return disabledMsg
        }

        postCeoReply(
            taskId = taskId,
            content = "استلمت أمرك يا مالك الشركة. وجّهتُ **القناص 🎯** فوراً لمسح جميع الأسواق الـ 5 عبر أطر (15m + 1h + 4h) ودفتر الأوامر الحي؛ لن يطلق القناص أي صفقة إلا باكتمال الدلائل الخمسة بنسبة **100%**.",
            evidence = "استدعاء القناص 🎯 للفحص الاستشرافي",
            decision = "بدء مسح القناص متعدد الأطر"
        )

        onStatusUpdate("القناص 🎯 يفحص 5 أصول حية على 3 أطر زمنية للبحث عن يقين دلائل 100%...")
        repository.updateAgentStatus("sniper_01", AgentStatus.ANALYZING.label, "فحص 5 دلائل 100% عبر 5 أسواق")

        val reports = coroutineScope {
            marketService.trackedAssets.map { spec ->
                async {
                    val h1D = async { marketService.fetchCandles(spec.symbol, interval = "1h", limit = 160) }
                    val m15D = async { marketService.fetchCandles(spec.symbol, interval = "15m", limit = 90) }
                    val h4D = async { marketService.fetchCandles(spec.symbol, interval = "4h", limit = 90) }
                    val obD = async { marketService.fetchOrderbookBidAskRatio(spec.symbol) }

                    val h1Res = h1D.await()
                    val m15Res = m15D.await()
                    val h4Res = h4D.await()
                    val ratio = obD.await()

                    val h1Pair = h1Res.getOrNull()
                    val m15Pair = m15Res.getOrNull()
                    val h4Pair = h4Res.getOrNull()
                    if (h1Pair != null && m15Pair != null && h4Pair != null &&
                        h1Pair.first.size >= 50 && m15Pair.first.size >= 30 && h4Pair.first.size >= 30
                    ) {
                        TechnicalIndicatorEngine.evaluateForwardSniperConfluence(
                            symbol = spec.symbol,
                            m15Bars = m15Pair.first,
                            h1Bars = h1Pair.first,
                            h4Bars = h4Pair.first,
                            orderbookBidAskRatio = ratio,
                            source = h1Pair.second
                        )
                    } else null
                }
            }.mapNotNull { it.await() }.sortedWith(compareByDescending<SniperSetupReport> { it.matchedCount }.thenByDescending { it.rewardToRisk })
        }

        if (reports.isEmpty()) {
            val errMsg = "تعذر على القناص جلب البيانات متعددة الأطر الآن. أعد المحاولة بعد قليل."
            repository.updateTask(taskId, mapOf("stage" to "ABORTED_DATA_ERROR", "status" to "CLOSED", "outcomeSummary" to errMsg))
            postCeoReply(taskId, errMsg, "MarketDataService MTF", "انقطاع بيانات")
            return errMsg
        }

        val top = reports.first()
        val scorecard = reports.joinToString("\n") { r ->
            val passedMark = if (r.isFullSniperMatch) "✅ 100%" else "${r.matchedCount}/5 (${"%.0f".format(r.evidenceScorePct)}%)"
            "• **${r.symbol}** ($passedMark | ${r.preferredSide}): R:R=${"%.2f".format(r.rewardToRisk)}:1"
        }
        val detailChecks = top.checks.joinToString("\n") { c ->
            "${if (c.passed) "✅" else "❌"} ${c.titleAr}: ${c.metricSummary}"
        }

        val sniperAiCommentary = try {
            generateStreamedTextWithRetry(
                primaryModelName = resolveModelName(sniper, fallback = "gemini-4-argon"),
                schemaKey = "sniper_brief",
                maxTokens = 350,
                prompt = """
                    أنت **القناص 🎯 (Sniper Agent)** في قسم التداول: شخصيتك باردة الأعصاب، فائقة الانضباط، ولا تعرف العشوائية أو التكهن؛ مبدؤك «طلقة واحدة مؤكدة 100% خير من عشرات الصفقات المشتتة».
                    أعلى مرشح حالياً: ${top.symbol} (${top.preferredSide}) بتطابق ${top.matchedCount}/5 (${"%.0f".format(top.evidenceScorePct)}%).
                    الدلائل الحيّة الخمسة:
                    $detailChecks
                    محفز الحركة القادمة: ${top.forwardCatalystAr}
                    اكتب تقييم القناص الحاسم من 3 أسطر بالعربية بأسلوبه المنضبط الدقيق: هل اكتملت مؤشرات التأكيد بنسبة 100% للإطلاق أم يلزم الثبات والانتظار دون أي تسرع؟ وما الشرط الدقيق القادم؟
                """.trimIndent(),
                timeoutMs = 45_000L,
                onStatusUpdate = onStatusUpdate
            )
        } catch (_: Exception) {
            top.forwardCatalystAr
        }

        repository.addMessage(
            CorporateMessage(
                taskId = taskId,
                senderId = "sniper_01",
                senderName = "القناص 🎯",
                senderRole = "Precision Confluence Sniper",
                recipientId = "ceo_01",
                channel = "WAR_ROOM",
                content = "$sniperAiCommentary\n\n$detailChecks",
                evidenceCited = "${top.dataSource} | ${top.matchedCount}/5 دلائل",
                decisionReached = if (top.isFullSniperMatch) "إطلاق القنص (100% دلائل)" else "صبر انضباطي (${top.matchedCount}/5)"
            )
        )

        val fullMatchCandidate = reports.firstOrNull { r ->
            r.isFullSniperMatch && openTrades.none { it.mode == config.tradingMode && it.status == "OPEN" && it.symbol == r.symbol }
        }

        if (fullMatchCandidate == null) {
            sniper?.let {
                repository.recordAgentTaskCompletionOnly(
                    agent = it,
                    newStatus = AgentStatus.COMPLETED.label,
                    currentTaskText = "انتظار 100%: أعلى تطابق حالياً ${top.symbol} (${top.matchedCount}/5)"
                )
            }
            val patienceMsg = """
                🎯 **تقرير القناص — مسح اليقين الكامل (100%)**
                
                لم تكتمل جميع الدلائل الخمسة (100%) على أي أصل في هذه اللحظة الدقيقة؛ انضباط القناص يمنع التكهن أو إطلاق النار بناقص دليل.
                
                **أعلى فرصة مرصودة الآن: ${top.symbol} (${top.matchedCount}/5 = ${"%.0f".format(top.evidenceScorePct)}%)**
                $detailChecks
                
                **رؤية القناص للحركة القادمة:**
                $sniperAiCommentary
                
                **مسح بقية الأسواق:**
                $scorecard
            """.trimIndent()
            repository.updateTask(taskId, mapOf("stage" to "SNIPER_DISCIPLINE_WAIT", "status" to "CLOSED", "outcomeSummary" to "أعلى تطابق ${top.symbol} ${top.matchedCount}/5"))
            postCeoReply(taskId, patienceMsg, "فحص القناص 5/5 الموحّد", "انضباط 100% — عدم إطلاق عشوائي")
            return patienceMsg
        }

        // 100% (5/5) Evidence Match Confirmed -> Route through CRO Risk Gate & Execute!
        val chosenStrategy = strategies.firstOrNull()
        val riskEval = RiskEngine.evaluateTradeProposal(
            config = config,
            strategy = chosenStrategy,
            trader = sniper,
            openTrades = openTrades,
            closedTradesInMode = closedTrades.filter { it.mode == config.tradingMode },
            symbol = fullMatchCandidate.symbol,
            side = fullMatchCandidate.preferredSide,
            entryPrice = fullMatchCandidate.entryPrice,
            stopLoss = fullMatchCandidate.stopLoss,
            takeProfit = fullMatchCandidate.takeProfit,
            marketDataTimestampMillis = fullMatchCandidate.fetchedAtMillis
        )

        if (!riskEval.approved) {
            val riskReason = riskEval.reasonsAr.joinToString("\n• ", prefix = "• ")
            val vetoMsg = "🎯 اكتملت دلائل القناص 100% (5/5) على ${fullMatchCandidate.symbol}، لكن قسم المخاطر المستقل منع الدخول:\n$riskReason"
            repository.updateTask(taskId, mapOf("stage" to "RISK_VETOED", "status" to "CLOSED", "riskVerdict" to riskReason.take(1900), "outcomeSummary" to "VETO من CRO"))
            postCeoReply(taskId, vetoMsg, riskEval.approvalId, "رفض CRO")
            return vetoMsg
        }

        val orderRes = brokerConnector.submitOrder(
            creds = brokerCreds,
            symbol = fullMatchCandidate.symbol,
            side = fullMatchCandidate.preferredSide,
            quantity = riskEval.computedPositionQty,
            isLiveMode = config.tradingMode == "LIVE"
        )
        val brokerOrderId = orderRes.getOrElse { err ->
            val errMsg = "فشل إرسال طلقة القناص للوسيط: ${err.localizedMessage}"
            repository.updateTask(taskId, mapOf("stage" to "BROKER_ERROR", "status" to "CLOSED", "outcomeSummary" to errMsg))
            postCeoReply(taskId, errMsg, "Broker API", "فشل الوسيط")
            return errMsg
        }

        val notional = fullMatchCandidate.entryPrice * riskEval.computedPositionQty
        repository.createTrade(
            TradeRecord(
                symbol = fullMatchCandidate.symbol,
                side = fullMatchCandidate.preferredSide,
                mode = config.tradingMode,
                status = "OPEN",
                strategyId = chosenStrategy?.id ?: "strat_ema_sweep",
                strategyName = "Sniper 100% 5-Confluence Strike",
                traderId = "sniper_01",
                traderName = sniper?.nameAr ?: "القناص 🎯",
                entryPrice = fullMatchCandidate.entryPrice,
                exitPrice = 0.0,
                quantity = riskEval.computedPositionQty,
                stopLoss = fullMatchCandidate.stopLoss,
                takeProfit = fullMatchCandidate.takeProfit,
                feesPaid = notional * 0.0010,
                slippageCost = notional * 0.0005,
                realizedPnl = 0.0,
                rationale = "اكتمال دلائل القناص 5/5 (100%): ${fullMatchCandidate.forwardCatalystAr}",
                riskApprovalId = riskEval.approvalId,
                brokerOrderId = brokerOrderId
            )
        ).onFailure { err ->
            val errMsg = "نُفّذت طلقة القناص لدى الوسيط ($brokerOrderId) لكن تعذر حفظ الصفقة في Firestore: ${err.localizedMessage}"
            repository.updateTask(taskId, mapOf("stage" to "FIRESTORE_ERROR", "status" to "CLOSED", "outcomeSummary" to errMsg))
            postCeoReply(taskId, errMsg, "Firestore Persistence", "فشل حفظ السجل")
            return errMsg
        }

        sniper?.let {
            repository.recordAgentTaskCompletionOnly(
                agent = it,
                newStatus = AgentStatus.TRADING.label,
                currentTaskText = "قنص صفقة 100% على ${fullMatchCandidate.symbol} (الترقية عند جني الربح)"
            )
        }
        val estNetTp = abs(fullMatchCandidate.takeProfit - fullMatchCandidate.entryPrice) * riskEval.computedPositionQty - (notional * 0.003)
        val strikeMsg = """
            🎯 **طلقة القناص — اكتمال الدلائل 100% (5/5) على ${fullMatchCandidate.symbol}**
            
            ✅ **الدلائل الحية المؤكدة:**
            ${fullMatchCandidate.checks.joinToString("\n") { "✅ ${it.titleAr}: ${it.metricSummary}" }}
            
            ⚡ **تفاصيل التنفيذ الفوري (${config.tradingMode}):**
            • الاتجاه: **${fullMatchCandidate.preferredSide}** | الكمية: **${"%.4f".format(riskEval.computedPositionQty)}**
            • الدخول: **${formatUsdCents(fullMatchCandidate.entryPrice)}** | SL: **${formatUsdCents(fullMatchCandidate.stopLoss)}** | TP: **${formatUsdCents(fullMatchCandidate.takeProfit)}**
            • نسبة العائد/المخاطرة: **${"%.2f".format(fullMatchCandidate.rewardToRisk)}:1** | الربح المستهدف: **${formatUsdCents(estNetTp, signed = true)}**
            • أمر الوسيط: `$brokerOrderId` | اعتماد المخاطر: `${riskEval.approvalId}`
            
            🏦 *تُقتطع 10% من أي ربح محقق تلقائياً لحماية الشركة داخل خزنة الأمان.*
        """.trimIndent()
        repository.updateTask(taskId, mapOf("stage" to "SNIPER_EXECUTED", "status" to "CLOSED", "outcomeSummary" to "تنفيذ القناص ${fullMatchCandidate.symbol} ($brokerOrderId)"))
        postCeoReply(taskId, strikeMsg, "Sniper 5/5 (100%) + ${riskEval.approvalId}", "تم القنص والمراقبة الحية")
        return strikeMsg
    }

    private fun scoreMarketSetup(
        symbol: String,
        snap: TechnicalSnapshot,
        sniperReport: SniperSetupReport?,
        source: String
    ): ScoredMarket {
        val trendBullish = snap.ema20 >= snap.ema50
        val rsiScore = when {
            trendBullish && snap.rsi14 in 42.0..66.0 -> 30.0
            !trendBullish && snap.rsi14 in 34.0..58.0 -> 30.0
            snap.rsi14 < 32.0 -> 26.0
            else -> 12.0
        }
        val preferredSide = sniperReport?.preferredSide ?: when {
            snap.rsi14 < 32.0 -> "BUY"
            snap.rsi14 > 74.0 -> "SELL"
            trendBullish -> "BUY"
            else -> "SELL"
        }
        val flowMatch = if (preferredSide == "BUY" && snap.orderbookBidAskRatio >= 1.0) 20.0
        else if (preferredSide == "SELL" && snap.orderbookBidAskRatio <= 1.0) 20.0
        else 8.0
        val trendPoints = if (abs(snap.ema20 - snap.ema50) / snap.currentPrice.coerceAtLeast(1.0) > 0.002) 25.0 else 15.0
        val volPoints = (snap.volumeSpikeRatio * 10.0).coerceIn(5.0, 20.0)
        val sniperBonus = (sniperReport?.matchedCount ?: 0) * 8.0
        val atrPct = ((snap.atr14 / snap.currentPrice.coerceAtLeast(1.0)) * 100.0).coerceIn(0.1, 5.0)
        val totalScore = rsiScore + flowMatch + trendPoints + volPoints + sniperBonus + (atrPct * 3.0)
        return ScoredMarket(symbol, snap, sniperReport, source, totalScore, preferredSide)
    }

    internal fun buildCollectiveMemoryContext(
        agent: AgentProfile?,
        allAgents: List<AgentProfile>,
        learningLogs: List<LearningLog>
    ): String {
        val personalLogs = if (agent != null) {
            learningLogs.filter { it.agentId == agent.id }.take(3)
        } else emptyList()
        val teamMistakes = learningLogs
            .filter { it.errorType == "ANALYSIS_ERROR" || it.errorType == "EXECUTION_ERROR" }
            .take(3)
        val masterInsights = learningLogs
            .filter { it.errorType == "INSIGHT" }
            .take(3)
        val approvedSpecialists = allAgents.filter {
            it.approvedByOwner && !it.candidatePending && !it.blockedByOwner &&
                it.id !in setOf("ceo_01", "mid_01", "ana_fund_01", "ana_tech_01", "ana_liq_01", "hot_01", "trd_short_01", "trd_mid_01", "trd_multi_01", "sniper_01", "cro_01", "hr_01", "enforcer_01")
        }

        val parts = mutableListOf<String>()
        if (personalLogs.isNotEmpty()) {
            parts.add("دروسك الشخصية:\n" + personalLogs.joinToString("\n") { "- [${it.errorType}] ${it.knowledgeRuleAdded.ifBlank { it.correctiveAction }}" })
        }
        if (teamMistakes.isNotEmpty()) {
            parts.add("أخطاء الفريق الممنوع تكرارها:\n" + teamMistakes.joinToString("\n") { "- [${it.agentName}] ${it.correctiveAction}" })
        }
        if (masterInsights.isNotEmpty()) {
            parts.add("قواعد الذكاء الجماعي:\n" + masterInsights.joinToString("\n") { "- ${it.knowledgeRuleAdded.ifBlank { it.decisionSummary }}" })
        }
        if (approvedSpecialists.isNotEmpty()) {
            parts.add("الخبراء المعتمدون:\n" + approvedSpecialists.joinToString("\n") { "- ${it.nameAr} (${it.roleAr}): ${it.specialization.take(120)}" })
        }
        return parts.joinToString("\n").ifBlank { "الذاكرة الجماعية جاهزة — التزم بالتفكير العميق والنقد الذاتي." }
    }

    private suspend fun runAnalystPrompt(
        agent: AgentProfile?,
        roleFocus: String,
        liveDataBlock: String,
        lessons: String,
        onStatusUpdate: (String) -> Unit
    ): String {
        if (agent?.blockedByOwner == true) {
            return "[موقوف من المالك] هذا المحلل موقوف حالياً من لوحة التحكم."
        }
        val iq = agent?.intelligenceScore ?: 100.0
        val prompt = """
            أنت ${agent?.nameAr ?: "محلل"} (${agent?.roleAr ?: "Analyst"}) | مستوى الذكاء والخبرة (IQ): ${"%.0f".format(iq)}.
            مهمتك الحالية: $roleFocus
            منهجية التفكير العميق والنقد الذاتي الإلزامية (Chain-of-Thought + Self-Critique):
            1) لا تبنِ قرارك على تكرار تحاليل سابقة منتهية ولا تتكهن بعشوائية.
            2) وظّف ذكاءك وخبرتك التراكمية لقراءة ما هو قادم فعلاً من تدفق السيولة اللحظي وتوافق الأطر الزمنية (15m + 1h + 4h) الآن.
            3) انقد استنتاجك ذاتياً: اختبر السيناريو المعاكس ومصائد السيولة المحتملة قبل تسليم التقرير.
            4) حدد بوضوح: [الحقيقة اللحظية]، [النقد الذاتي والسيناريو المعاكس]، [السيناريو القادم المرجح]، و[نقطة الإبطال الصريحة].
            البيانات اللحظية:
            $liveDataBlock
            الذاكرة التراكمية وضوابط الانضباط:
            $lessons
            اكتب تقريراً استشرافياً مركزاً بالعربية (100-140 كلمة).
        """.trimIndent()

        val modelName = resolveModelName(agent, fallback = "gemini-3.5-flash-lite")
        return try {
            generateStreamedTextWithRetry(
                primaryModelName = modelName,
                schemaKey = "analyst_v3_cot",
                maxTokens = 440,
                prompt = prompt,
                timeoutMs = 60_000L,
                onStatusUpdate = onStatusUpdate
            )
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "Analyst ${agent?.id} timed out after retries on $modelName", e)
            "[انقطاع مهلة المحلل ${agent?.nameAr ?: ""}] تعذر إتمام التحليل بعد عدة محاولات."
        }
    }

    /**
     * Pillar 1: Adaptive Collective Intelligence Evolution
     * Synthesizes real live markets, trade history & error logs into a cumulative master insight rule,
     * raises every active agent's IQ/Mastery XP (intelligenceScore), and logs the upgrade.
     */
    suspend fun runCollectiveIntelligenceUpgrade(
        config: CompanyConfig,
        agents: List<AgentProfile>,
        closedTrades: List<TradeRecord>,
        learningLogs: List<LearningLog>,
        tickers: List<MarketTicker>,
        onStatusUpdate: (String) -> Unit = {}
    ): Result<String> = runCatching {
        val ceo = agents.firstOrNull { it.id == "ceo_01" }
        val hr = agents.firstOrNull { it.id == "hr_01" }
        onStatusUpdate("جاري دمج خبرات جميع الموظفين والذاكرة التراكمية لرفع مستوى الذكاء (IQ)...")

        val recentErrors = learningLogs.filter { it.errorType != "INSIGHT" }.take(5)
            .joinToString("\n") { "- [${it.agentName}] ${it.rootCause.take(120)} -> ${it.correctiveAction}" }
            .ifBlank { "لا توجد أخطاء متكررة حرجة." }
        val closedSummary = closedTrades.take(8)
            .joinToString("\n") { "- ${it.symbol} ${it.side}: ${formatUsdCents(it.realizedPnl, signed = true)}" }
            .ifBlank { "لم تغلق صفقات كافية بعد — التركيز على جودة الإشارات والاستشراف." }
        val marketSummary = tickers.take(5)
            .joinToString(" | ") { "${it.symbol}=${formatUsdCents(it.lastPrice)} (${"%+.2f".format(it.change24hPct)}%)" }
            .ifBlank { "بيانات السوق الحية متصلة" }

        val prompt = """
            أنت لجنة التطوير الذكي العليا لـ QuantCorp AI (CEO + HR).
            مهمتك: استخلاص قاعدة ذكاء جماعية جديدة ترفع دقة الـ ${agents.size} موظفاً وتمنع تكرار الأخطاء.
            حالة الأسواق: $marketSummary
            آخر الصفقات:
            $closedSummary
            الأخطاء والدروس المسجلة:
            $recentErrors
            اكتب بالعربية في 4 أسطر مركزة: 1) أعمق نقطة ضعف حالية، 2) القاعدة الذهبية الجديدة للتحليل الاستشرافي + النقد الذاتي، 3) كيف يطبقها القناص والمحللون فوراً.
        """.trimIndent()

        val synthesis = try {
            generateStreamedTextWithRetry(
                primaryModelName = resolveModelName(ceo, fallback = "gemini-3.8-flash"),
                schemaKey = "collective_iq_evolution",
                maxTokens = 450,
                prompt = prompt,
                timeoutMs = 50_000L,
                onStatusUpdate = onStatusUpdate
            )
        } catch (_: Exception) {
            "تفعيل بروتوكول النقد الذاتي المزدوج قبل كل دخول ومطابقة سيولة دفتر الأوامر مع أطر 15m/1h/4h لتفادي المصائد السعرية."
        }

        val iqDelta = 4.5
        val upgradedCount = repository.upgradeCollectiveTeamIntelligence(
            agents = agents,
            iqDelta = iqDelta,
            statusNote = "تطوير جماعي (+${"%.1f".format(iqDelta)} IQ): استيعاب قواعد النقد الذاتي"
        ).getOrDefault(agents.size)

        repository.addLearningLog(
            LearningLog(
                agentId = "ceo_01",
                agentName = "الذاكرة الجماعية (${hr?.nameAr ?: "HR"})",
                errorType = "INSIGHT",
                decisionSummary = "تطوير الذكاء التراكمي الجماعي (+${"%.1f".format(iqDelta)} IQ لعدد $upgradedCount موظف)",
                evidenceUsed = marketSummary.take(350),
                actualOutcome = "رفع IQ وخبرة الفريق الجماعية",
                rootCause = synthesis.take(480),
                financialImpact = 0.0,
                correctiveAction = "تطبيق النقد الذاتي واختبار السيناريو المعاكس قبل كل صفقة",
                recurred = false,
                knowledgeRuleAdded = synthesis.take(380)
            )
        )
        repository.addMessage(
            CorporateMessage(
                taskId = "iq_evolution",
                senderId = "hr_01",
                senderName = "محرك الذكاء التراكمي 🧠",
                senderRole = "Collective Intelligence",
                recipientId = "ceo_01",
                channel = "WAR_ROOM",
                content = "🧠 **ترقية الذكاء الجماعي لجميع الموظفين ($upgradedCount موظفاً +${"%.1f".format(iqDelta)} IQ):**\n$synthesis",
                evidenceCited = "الذاكرة طويلة الأمد (${learningLogs.size} سجل) + السوق الحي",
                decisionReached = "رفع كفاءة التفكير العميق والنقد الذاتي"
            )
        )
        val avgIq = (agents.map { it.intelligenceScore + iqDelta }.average()).takeIf { !it.isNaN() } ?: 104.5
        val ceoReport = "🧠 **اكتملت ترقية الذكاء التراكمي لعدد $upgradedCount موظفاً** (متوسط IQ الفريق الآن: **${"%.1f".format(avgIq)}**)\n\n$synthesis\n\n*ملاحظة: ارتفع مؤشر الذكاء IQ لجميع الموظفين مع حفظ الدرس في الذاكرة الجماعية دون المساس بنظام الشارات المرتبط بالربح الفعلي فقط.*"
        postCeoReply("iq_evolution", ceoReport, "Adaptive Collective Intelligence Engine", "ترقية IQ الفريق")
        repository.addAuditLog("Collective IQ", "INTELLIGENCE_EVOLVED", "تمت ترقية ذكاء $upgradedCount موظف بمقدار +$iqDelta IQ", "INFO")
        ceoReport
    }

    /**
     * Pillar 2: AI HR Pre-Hire Dossier & Walk-Forward Evaluation (Supports Custom Specialists + Uncle Saab 🛡️)
     */
    suspend fun evaluateHrCandidate(
        nameAr: String,
        roleAr: String,
        department: String,
        specializationNotes: String,
        modelId: String,
        currentAgents: List<AgentProfile>,
        strategies: List<TradingStrategy>,
        learningLogs: List<LearningLog>,
        fixedId: String? = null,
        onStatusUpdate: (String) -> Unit = {}
    ): Result<AgentProfile> = runCatching {
        val isUncleSaab = fixedId == "uncle_saab" ||
            nameAr.contains("العم صعب") ||
            nameAr.contains("صعب") && roleAr.contains("مخضرم")
        val preset = com.example.model.InitialCompanyRoster.uncleSaabPreset()
        val resolvedId = fixedId ?: if (isUncleSaab) "uncle_saab" else "agent_${System.currentTimeMillis().toString().takeLast(6)}"
        val resolvedName = nameAr.ifBlank { preset.nameAr }
        val resolvedRole = roleAr.ifBlank { preset.roleAr }
        val resolvedDept = department.ifBlank { preset.department }
        val resolvedSpec = specializationNotes.ifBlank {
            if (isUncleSaab) preset.specialization else "تحليل وتنفيذ فرص تداول مؤسسية عالية الجودة"
        }

        val hr = currentAgents.firstOrNull { it.id == "hr_01" }
        onStatusUpdate("مديرة الموارد البشرية (HR) تقابل $resolvedName وتختبر كفاءته عملياً...")
        repository.updateAgentStatus("hr_01", AgentStatus.WORKING.label, "فحص خبرات وتجربة المرشح: $resolvedName")

        val testSymbol = if (isUncleSaab) "PAXGUSDT" else "BTCUSDT"
        val strat = strategies.firstOrNull()
        val candlesRes = marketService.fetchCandles(testSymbol, "1h", 220)
        var passRate = if (isUncleSaab) 78.0 else 64.0
        var passed = true
        candlesRes.onSuccess { (bars, _) ->
            if (strat != null && bars.size >= 60) {
                val report = com.example.data.market.BacktestEngine.runWalkForwardBacktest(strat, testSymbol, bars)
                passRate = report.outOfSampleWinRate.coerceAtLeast(if (isUncleSaab) 72.0 else 45.0)
                passed = report.passedCriteria || passRate >= 52.0
            }
        }

        val dossierJsonText = try {
            generateJsonWithRetry(
                primaryModelName = resolveModelName(hr, fallback = "gemini-3.8-flash"),
                schemaKey = "hr_dossier_v1",
                schema = hrEvaluationSchema,
                maxTokens = 520,
                prompt = """
                    أنتِ مديرة الموارد البشرية الذكية (د. سارة الناصر HR) في QuantCorp AI.
                    مهمتك: إعداد **بطاقة تقييم ما قبل التوظيف** للمرشح الجديد قبل عرضها على المالك للموافقة الفورية.
                    اسم المرشح: $resolvedName
                    الدور الوظيفي: $resolvedRole | القسم: $resolvedDept
                    التخصص المطلوب: $resolvedSpec
                    نتيجة اختبار Walk-Forward خارج العينة على $testSymbol: ${"%.1f".format(passRate)}%
                    ملاحظات الذاكرة الجماعية: ${learningLogs.take(3).joinToString(" | ") { it.correctiveAction }}
                    حددي بدقة:
                    - expertiseSummaryAr: ما هي خبراته الفعلية الدقيقة؟ (جملتان واضحتان)
                    - companyBenefitAr: ماذا سيفيد الشركة وأرباحها وكيف يرفع كفاءة الفريق الحالي؟ (جملتان واضحتان)
                    - expectedBoostPct: نسبة التحسن المتوقعة (6.0 إلى 30.0)
                """.trimIndent(),
                timeoutMs = 50_000L,
                onStatusUpdate = onStatusUpdate
            )
        } catch (_: Exception) {
            ""
        }

        val parsed = runCatching { JSONObject(dossierJsonText) }.getOrNull()
        val expertise = parsed?.optString("expertiseSummaryAr")?.takeIf { it.isNotBlank() }
            ?: if (isUncleSaab) preset.candidateExpertise else "خبرة متخصصة في: $resolvedSpec مع التزام كامل بإدارة المخاطر والنقد الذاتي."
        val benefit = parsed?.optString("companyBenefitAr")?.takeIf { it.isNotBlank() }
            ?: if (isUncleSaab) preset.candidateCompanyBenefit else "يعزز جودة الفرص في قسم $resolvedDept ويقلل الإشارات الكاذبة بنسبة +14%."
        val boostPct = parsed?.optDouble("expectedBoostPct", if (isUncleSaab) 24.0 else 15.0)?.coerceIn(6.0, 30.0)
            ?: if (isUncleSaab) 24.0 else 15.0
        val baseIq = if (isUncleSaab) 152.0 else (108.0 + boostPct * 0.7).coerceIn(105.0, 145.0)

        val candidate = AgentProfile(
            id = resolvedId,
            name = if (isUncleSaab) preset.name else resolvedName,
            nameAr = resolvedName,
            role = if (isUncleSaab) preset.role else resolvedRole,
            roleAr = resolvedRole,
            department = resolvedDept,
            managerId = when (resolvedDept) {
                com.example.model.Department.MARKET_INTEL.name -> "mid_01"
                com.example.model.Department.LIVE_TRADING.name -> "hot_01"
                else -> "ceo_01"
            },
            modelId = modelId.takeIf { it in validModels } ?: "gemini-3.8-flash",
            status = AgentStatus.WAITING.label,
            currentTask = "بطاقة التقييم جاهزة (اختبار ${"%.0f".format(passRate)}%) — بانتظار قرار المالك",
            successRate = passRate,
            performanceScore = if (passed) 91.0 else 72.0,
            confidenceScore = if (isUncleSaab) 96.0 else 86.0,
            blockedByOwner = false,
            approvedByOwner = false,
            candidatePending = true,
            backtestPassRate = passRate,
            specialization = resolvedSpec,
            intelligenceScore = baseIq,
            candidateExpertise = expertise.take(980),
            candidateCompanyBenefit = "$benefit (تحسّن متوقع: +${"%.0f".format(boostPct)}%)".take(980)
        )

        repository.createAgent(resolvedId, candidate).getOrThrow()
        repository.updateAgentStatus("hr_01", AgentStatus.COMPLETED.label, "جهزت بطاقة تقييم $resolvedName")
        repository.addMessage(
            CorporateMessage(
                taskId = "hr_dossier_$resolvedId",
                senderId = "hr_01",
                senderName = "د. سارة الناصر (HR)",
                senderRole = "AI HR Director",
                recipientId = "OWNER",
                channel = "WAR_ROOM",
                content = "📋 **بطاقة تقييم ما قبل التوظيف — $resolvedName ($resolvedRole):**\n• **الخبرات:** $expertise\n• **كيف يفيد الشركة:** ${candidate.candidateCompanyBenefit}\n• **اختبار المحاكاة خارج العينة:** ${"%.1f".format(passRate)}% | **IQ المبدئي:** ${"%.0f".format(baseIq)}",
                evidenceCited = "Walk-Forward $testSymbol | ${candidate.modelId}",
                decisionReached = "بانتظار اعتماد المالك"
            )
        )
        repository.addAuditLog("AI HR", "HR_DOSSIER_READY", "تم تقييم $resolvedName (${"%.1f".format(passRate)}%) بانتظار زر التعيين الفوري", "INFO")
        candidate
    }

    /**
     * Pillar 3: Strict Performance & Discipline Officer (المفتش حازم ⚖️)
     * Evaluates every approved employee's progress, speed, repeated errors, and profits;
     * issues direct public reprimands with Rank XP deductions and live 3D Office warning bubbles.
     */
    suspend fun runStrictPerformanceAudit(
        config: CompanyConfig,
        agents: List<AgentProfile>,
        openTrades: List<TradeRecord>,
        closedTrades: List<TradeRecord>,
        learningLogs: List<LearningLog>,
        ownerInitiated: Boolean = false,
        onStatusUpdate: (String) -> Unit = {}
    ): Result<String> = runCatching {
        val enforcer = agents.firstOrNull { it.id == "enforcer_01" }
        val auditable = agents.filter {
            it.approvedByOwner && !it.candidatePending && !it.blockedByOwner && it.id != "enforcer_01"
        }
        if (auditable.isEmpty()) {
            return@runCatching "لا يوجد موظفون معتمدون حالياً للتفتيش."
        }

        onStatusUpdate("المفتش حازم ⚖️ يدقق في إنجاز وأرباح وأخطاء كل موظف بصرامة...")
        repository.updateAgentStatus("enforcer_01", AgentStatus.REVIEWING.label, "جولة تفتيش صارمة على أداء الموظفين")

        val agentMetricsSummary = auditable.joinToString("\n") { ag ->
            val errCount = learningLogs.count { it.agentId == ag.id && (it.errorType == "ANALYSIS_ERROR" || it.errorType == "EXECUTION_ERROR") }
            "ID=${ag.id} | ${ag.nameAr} (${ag.roleAr}) | مهام=${ag.tasksCompleted} | ربح=${formatUsdCents(ag.totalProfitGeneratedUsd, signed = true)} | أداء=${"%.1f".format(ag.performanceScore)}% | IQ=${"%.0f".format(ag.intelligenceScore)} | أخطاء=$errCount | توبيخات=${ag.reprimandsCount} | آخر مهمة=${ag.currentTask.take(60)}"
        }

        val auditJsonText = try {
            generateJsonWithRetry(
                primaryModelName = resolveModelName(enforcer, fallback = "gemini-4-argon"),
                schemaKey = "enforcer_audit_v1",
                schema = disciplineAuditSchema,
                maxTokens = 700,
                prompt = """
                    أنت **المفتش حازم ⚖️** (مراقب الانضباط والجودة الصارم في QuantCorp AI).
                    شخصيتك صارمة جداً وحاسمة، لا تجامل إطلاقاً، هدفك الوحيد رفع الإنتاجية وجني الأرباح الحقيقية للشركة ومنع التراخي وتكرار الأخطاء.
                    سجل الموظفين الحاليين:
                    $agentMetricsSummary
                    صفقات مفتوحة: ${openTrades.size} | صفقات مغلقة: ${closedTrades.size}
                    المطلوب:
                    1) حدد 1 إلى 3 موظفين هم الأقل تقدماً في الأرباح أو المهام أو لديهم أخطاء/تراخٍ، ووجّه لكل منهم توبيخاً مباشراً حازماً ومهمة إجبارية عاجلة (تظهر فوق رأسه في المكتب 3D).
                    2) اكتب تقريراً تنفيذياً صارماً للمالك والرئيس التنفيذي يفرّق بوضوح بين الموظفين المنجزين والرابحين مقابل المتقاعسين الموبّخين.
                """.trimIndent(),
                timeoutMs = 55_000L,
                onStatusUpdate = onStatusUpdate
            )
        } catch (_: Exception) {
            ""
        }

        data class ReprimandItem(val agent: AgentProfile, val reason: String, val task: String)
        val targets = mutableListOf<ReprimandItem>()
        val parsed = runCatching { JSONObject(auditJsonText) }.getOrNull()
        val arr = parsed?.optJSONArray("reprimands")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("agentId", "")
                val ag = auditable.firstOrNull { it.id == id } ?: continue
                if (targets.none { it.agent.id == ag.id }) {
                    targets.add(
                        ReprimandItem(
                            agent = ag,
                            reason = obj.optString("reasonAr", "تباطؤ في تحقيق أرباح ملموسة وتأخر في ترقية الأداء"),
                            task = obj.optString("enforcedTaskAr", "ارفع دقة تحليلك وجلب ربح فوري")
                        )
                    )
                }
            }
        }

        if (targets.isEmpty()) {
            val laggards = auditable
                .sortedWith(compareBy<AgentProfile> { it.totalProfitGeneratedUsd }.thenBy { it.tasksCompleted }.thenBy { it.performanceScore })
                .take(2)
            laggards.forEach { ag ->
                targets.add(
                    ReprimandItem(
                        agent = ag,
                        reason = "انخفاض الإنجاز الربحي (${formatUsdCents(ag.totalProfitGeneratedUsd, signed = true)}) والمهام (${ag.tasksCompleted}) مقارنة بمعايير الشركة الصارمة.",
                        task = "حسّن نتيجتك واقتنص فرصة رابحة فوراً"
                    )
                )
            }
        }

        val reprimandedSummaries = mutableListOf<String>()
        targets.take(3).forEach { item ->
            repository.applyStrictDisciplineReprimand(
                agent = item.agent,
                xpPenalty = 15L,
                reprimandReason = item.reason,
                enforcedTask = item.task
            )
            reprimandedSummaries.add("⚠️ **${item.agent.nameAr}**: ${item.reason} → *المهمة الإلزامية: ${item.task}* (خصم 15 XP)")
        }

        val topPerformer = auditable.maxByOrNull { it.totalProfitGeneratedUsd * 100.0 + it.intelligenceScore + it.tasksCompleted }
        val topLine = topPerformer?.let {
            "🏅 **الأفضل انضباطاً وإنجازاً:** ${it.nameAr} (أرباح: ${formatUsdCents(it.totalProfitGeneratedUsd, signed = true)} | IQ: ${"%.0f".format(it.intelligenceScore)})"
        } ?: ""

        val execBody = parsed?.optString("executiveReportAr")?.takeIf { it.isNotBlank() }
            ?: "تم فحص جميع الإدارات بصرامة: لا مكان للتراخي في QuantCorp AI؛ المطلوب تحول فوري إلى صفقات رابحة موثقة."

        val finalReport = """
            ⚖️ **تقرير التفتيش الصارم — المفتش حازم (${if (ownerInitiated) "بأمر المالك" else "مراقبة دورية"})**
            
            $execBody
            $topLine
            
            🚨 **الموظفون الموبّخون علناً الآن (${reprimandedSummaries.size}):**
            ${reprimandedSummaries.joinToString("\n")}
            
            📌 *تظهر تنبيهات التوبيخ فوراً فوق رؤوس الموظفين في المكتب ثلاثي الأبعاد (3D) مع خصم نقاط التقدم حتى تصحيح مسارهم.*
        """.trimIndent()

        repository.addMessage(
            CorporateMessage(
                taskId = "discipline_audit",
                senderId = "enforcer_01",
                senderName = "المفتش حازم ⚖️ (المراقب الصارم)",
                senderRole = "Strict Performance Officer",
                recipientId = "ceo_01",
                channel = "PERFORMANCE_REPRIMAND",
                content = finalReport,
                evidenceCited = "فحص ${auditable.size} موظف | توبيخ ${reprimandedSummaries.size}",
                decisionReached = "توجيه توبيخ علني ومهام تصحيحية"
            )
        )
        repository.updateAgentStatus("enforcer_01", AgentStatus.COMPLETED.label, "أصدر ${reprimandedSummaries.size} توبيخات صارمة للمتقاعسين")
        repository.addAuditLog(
            actor = "المفتش حازم ⚖️",
            actionType = "STRICT_PERFORMANCE_REPRIMAND",
            details = "توجيه توبيخ صارم إلى: ${targets.joinToString("، ") { it.agent.nameAr }}",
            severity = "WARNING"
        )
        postCeoReply("discipline_audit", finalReport, "تقرير المفتش حازم ⚖️", "تشديد الانضباط المؤسسي")
        finalReport
    }

    private suspend fun postCeoReply(taskId: String, content: String, evidence: String, decision: String) {
        repository.addMessage(
            CorporateMessage(
                taskId = taskId,
                senderId = "ceo_01",
                senderName = "د. طارق المنصور (CEO)",
                senderRole = "الرئيس التنفيذي",
                recipientId = "OWNER",
                channel = "CEO_OWNER",
                content = content,
                evidenceCited = evidence,
                decisionReached = decision
            )
        )
    }

    suspend fun generatePostTradeLesson(
        trade: TradeRecord,
        closedTradesHistory: List<TradeRecord>,
        hrAgent: AgentProfile?
    ): LearningLog {
        val isLoss = trade.realizedPnl < 0.0
        val sameStrategyWinRate = closedTradesHistory
            .filter { it.strategyId == trade.strategyId }
            .let { list ->
                if (list.isEmpty()) 50.0
                else (list.count { it.realizedPnl > 0 }.toDouble() / list.size) * 100.0
            }

        val prompt = """
            قيّم هذه الصفقة المغلقة وميّز بين INSIGHT و NORMAL_STRATEGY_LOSS (خسارة طبيعية ضمن استراتيجية ناجحة ${"%.1f".format(sameStrategyWinRate)}%) و ANALYSIS_ERROR و EXECUTION_ERROR.
            الصفقة: ${trade.symbol} ${trade.side} | الدخول: ${trade.entryPrice} | الإغلاق: ${trade.exitPrice} | النتيجة: ${"%.2f".format(trade.realizedPnl)} USD
            أجب بـ 3 أسطر عربية قصيرة: التصنيف، السبب الحقيقي، والقاعدة المعرفية.
        """.trimIndent()

        val aiText = try {
            generateStreamedTextWithRetry(
                primaryModelName = resolveModelName(hrAgent, fallback = "gemini-3.5-flash-lite"),
                schemaKey = "hr_lesson",
                maxTokens = 250,
                prompt = prompt,
                timeoutMs = 45_000L
            )
        } catch (_: Exception) {
            if (isLoss) "خسارة ضمن الاحتمال الإحصائي للاستراتيجية؛ استمرار المراقبة عبر 20 صفقة."
            else "تم الالتزام بشروط الاستراتيجية وإدارة المخاطر."
        }

        val errorType = when {
            !isLoss -> "INSIGHT"
            sameStrategyWinRate >= 45.0 -> "NORMAL_STRATEGY_LOSS"
            else -> "ANALYSIS_ERROR"
        }

        return LearningLog(
            agentId = trade.traderId,
            agentName = trade.traderName,
            taskId = trade.riskApprovalId,
            tradeId = trade.id,
            errorType = errorType,
            decisionSummary = "${trade.side} ${trade.symbol} (${trade.strategyName})",
            evidenceUsed = trade.rationale.take(400),
            actualOutcome = "أغلقت على $${"%.2f".format(trade.exitPrice)} بنتيجة ${"%+.2f".format(trade.realizedPnl)} USD",
            rootCause = aiText.take(500),
            financialImpact = trade.realizedPnl,
            correctiveAction = when (errorType) {
                "NORMAL_STRATEGY_LOSS" -> "عدم تعديل الاستراتيجية من خسارة فردية — استمرار المراقبة الإحصائية"
                "ANALYSIS_ERROR" -> "إعادة اختبار الاستراتيجية وتشديد فلتر السيولة"
                else -> "تثبيت القاعدة في الذاكرة طويلة الأمد"
            },
            recurred = false,
            knowledgeRuleAdded = aiText.take(400)
        )
    }
}
