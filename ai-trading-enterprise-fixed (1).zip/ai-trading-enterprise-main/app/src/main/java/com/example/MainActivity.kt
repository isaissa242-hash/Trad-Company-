package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.broker.BrokerConnector
import com.example.data.ai.CommandOutbox
import com.example.data.firebase.CompanyRepository
import com.example.data.market.MarketDataService
import com.example.model.CompanyConfig
import com.example.security.EncryptedVault
import com.example.security.configureAppCheck
import com.example.ui.auth.AuthScreen
import com.example.ui.components.CorporateTopBar
import com.example.ui.screens.BrokerControlScreen
import com.example.ui.screens.CeoCommandScreen
import com.example.ui.screens.PnLDashboardScreen
import com.example.ui.screens.StrategyHrMemoryScreen
import com.example.ui.screens.VirtualOfficeScreen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.QuantCorpTheme
import com.example.viewmodel.CompanyViewModel
import com.example.viewmodel.StreamState
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class NavDestination(val route: String, val labelAr: String, val icon: ImageVector) {
    data object CeoCommand : NavDestination("ceo_command", "القيادة", Icons.Filled.AutoAwesome)
    data object VirtualOffice : NavDestination("virtual_office", "المكتب", Icons.Filled.Apartment)
    data object PnLDashboard : NavDestination("pnl_dashboard", "الأرباح", Icons.Filled.CandlestickChart)
    data object StrategyMemory : NavDestination("strategy_memory", "الذاكرة", Icons.Filled.Psychology)
    data object BrokerControl : NavDestination("broker_control", "التحكم", Icons.Filled.Security)
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    trySend(currentUser)
    val listener = FirebaseAuth.AuthStateListener { auth -> trySend(auth.currentUser) }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // STEP 1: Mandatory App Check configuration with launch intent before UI/ViewModels
        configureAppCheck(this, intent)

        setContent {
            QuantCorpTheme(darkTheme = true) {
                Surface(modifier = Modifier.fillMaxSize(), color = ObsidianBg) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth? = null) {
    val firebaseAuth = remember(auth) { auth ?: Firebase.auth }
    var authRefreshCount by remember { mutableIntStateOf(0) }
    val streamUser by firebaseAuth.authStateFlow().collectAsStateWithLifecycle(initialValue = firebaseAuth.currentUser)
    val user = remember(streamUser, authRefreshCount) { streamUser ?: firebaseAuth.currentUser }

    if (user == null) {
        AuthScreen(onAuthSuccess = { authRefreshCount++ })
    } else {
        key(user.uid) {
            QuantCorpShell(currentUserId = user.uid)
        }
    }
}

@Composable
fun QuantCorpShell(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val viewModel: CompanyViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                CompanyViewModel(
                    repository = CompanyRepository(app),
                    marketService = MarketDataService(),
                    brokerConnector = BrokerConnector(),
                    encryptedVault = EncryptedVault(app),
                    currentUserId = currentUserId,
                    commandOutbox = CommandOutbox(app, currentUserId)
                )
            }
        }
    )

    val configState by viewModel.configState.collectAsStateWithLifecycle()
    val agents by viewModel.agentsState.collectAsStateWithLifecycle()
    val tasks by viewModel.tasksState.collectAsStateWithLifecycle()
    val messages by viewModel.messagesState.collectAsStateWithLifecycle()
    val strategies by viewModel.strategiesState.collectAsStateWithLifecycle()
    val trades by viewModel.tradesState.collectAsStateWithLifecycle()
    val learningLogs by viewModel.learningLogsState.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogsState.collectAsStateWithLifecycle()
    val tickers by viewModel.liveTickers.collectAsStateWithLifecycle()
    val selectedSymbol by viewModel.selectedSymbol.collectAsStateWithLifecycle()
    val selectedCandles by viewModel.selectedCandles.collectAsStateWithLifecycle()
    val selectedTechSnapshot by viewModel.selectedTechSnapshot.collectAsStateWithLifecycle()
    val isCommandRunning by viewModel.isCommandRunning.collectAsStateWithLifecycle()
    val commandStatusMessage by viewModel.commandStatusMessage.collectAsStateWithLifecycle()
    val queuedCommandCount by viewModel.queuedCommandCount.collectAsStateWithLifecycle()
    val failedCommand by viewModel.failedCommand.collectAsStateWithLifecycle()
    val bannerMessage by viewModel.bannerMessage.collectAsStateWithLifecycle()
    val brokerCreds by viewModel.brokerCreds.collectAsStateWithLifecycle()
    val brokerSnapshot by viewModel.brokerSnapshot.collectAsStateWithLifecycle()
    val pnlSummary by viewModel.pnlSummary.collectAsStateWithLifecycle()
    val pnlModeFilter by viewModel.pnlFilterMode.collectAsStateWithLifecycle()
    val isBacktesting by viewModel.isBacktesting.collectAsStateWithLifecycle()
    val lastBacktestReport by viewModel.lastBacktestReport.collectAsStateWithLifecycle()
    val isNetworkOnline by viewModel.isNetworkOnline.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(bannerMessage) {
        val msg = bannerMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBanner()
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val destinations = remember {
        listOf(
            NavDestination.CeoCommand,
            NavDestination.VirtualOffice,
            NavDestination.PnLDashboard,
            NavDestination.StrategyMemory,
            NavDestination.BrokerControl
        )
    }

    val activeConfig = (configState as? StreamState.Ready)?.data ?: CompanyConfig(userId = currentUserId)

    val onSignOutClick: () -> Unit = {
        scope.launch {
            withContext(NonCancellable) {
                try {
                    CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w("Auth", "Failed to clear credential state: ${e.message}")
                } finally {
                    Firebase.auth.signOut()
                }
            }
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 680.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                CorporateTopBar(
                    config = activeConfig,
                    pnlSummary = pnlSummary,
                    isNetworkOnline = isNetworkOnline,
                    onToggleKillSwitch = { viewModel.toggleKillSwitch(!activeConfig.killSwitchActive) },
                    onRefreshMarkets = { viewModel.refreshMarketsOnce() },
                    onSignOut = onSignOutClick
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = ObsidianSurface) {
                        destinations.forEach { dest ->
                            NavigationBarItem(
                                selected = currentRoute == dest.route,
                                onClick = {
                                    navController.navigate(dest.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(dest.icon, contentDescription = dest.labelAr) },
                                label = { Text(dest.labelAr) }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = ObsidianSurface) {
                        destinations.forEach { dest ->
                            NavigationRailItem(
                                selected = currentRoute == dest.route,
                                onClick = {
                                    navController.navigate(dest.route) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(dest.icon, contentDescription = dest.labelAr) },
                                label = { Text(dest.labelAr) }
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    val cfgErr = configState as? StreamState.Error
                    if (configState is StreamState.Loading && agents.isEmpty()) {
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    } else if (cfgErr != null && agents.isEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(20.dp)
                                .widthIn(max = 460.dp)
                                .testTag("firestore_init_error_card")
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "تعذر الاتصال بقاعدة بيانات الشركة",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CrimsonRisk
                                )
                                Text(
                                    text = cfgErr.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.retryCompanyInitialization() },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = ChampagneGold,
                                            contentColor = ObsidianBg
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("firestore_retry_button")
                                    ) {
                                        Text("إعادة المحاولة")
                                    }
                                    OutlinedButton(
                                        onClick = onSignOutClick,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("firestore_sign_out_button")
                                    ) {
                                        Text("تسجيل الخروج")
                                    }
                                }
                            }
                        }
                    } else {
                        NavHost(
                            navController = navController,
                            startDestination = NavDestination.CeoCommand.route,
                            enterTransition = { fadeIn(animationSpec = tween(150)) },
                            exitTransition = { fadeOut(animationSpec = tween(120)) }
                        ) {
                            composable(NavDestination.CeoCommand.route) {
                                CeoCommandScreen(
                                    config = activeConfig,
                                    pnlSummary = pnlSummary,
                                    messages = messages,
                                    tasks = tasks,
                                    tickers = tickers,
                                    isCommandRunning = isCommandRunning,
                                    commandStatusMessage = commandStatusMessage,
                                    queuedCommandCount = queuedCommandCount,
                                    failedCommandText = failedCommand?.text,
                                    failedCommandError = failedCommand?.lastError,
                                    onRetryFailedCommand = viewModel::retryFailedCommand,
                                    onDismissFailedCommand = viewModel::dismissFailedCommand,
                                    onSendCommand = viewModel::sendOwnerCommand
                                )
                            }
                            composable(NavDestination.VirtualOffice.route) {
                                VirtualOfficeScreen(
                                    config = activeConfig,
                                    agents = agents,
                                    messages = messages,
                                    tasks = tasks,
                                    learningLogs = learningLogs,
                                    strategies = strategies,
                                    tickers = tickers,
                                    pnlSummary = pnlSummary,
                                    isCommandRunning = isCommandRunning,
                                    onToggleBlockAgent = viewModel::setAgentBlocked,
                                    onChangeAgentModel = viewModel::updateAgentModel,
                                    onSendDirective = viewModel::sendOwnerCommand,
                                    onEvolveCollectiveIntelligence = viewModel::runCollectiveIntelligenceUpgrade,
                                    onRunStrictAudit = viewModel::runStrictDisciplineAudit
                                )
                            }
                            composable(NavDestination.PnLDashboard.route) {
                                PnLDashboardScreen(
                                    config = activeConfig,
                                    pnlSummary = pnlSummary,
                                    pnlModeFilter = pnlModeFilter,
                                    onModeFilterChange = viewModel::setPnlModeFilter,
                                    trades = trades,
                                    strategies = strategies,
                                    tickers = tickers,
                                    selectedSymbol = selectedSymbol,
                                    selectedCandles = selectedCandles,
                                    selectedTechSnapshot = selectedTechSnapshot,
                                    onSelectSymbol = viewModel::selectChartSymbol,
                                    onCloseTrade = viewModel::closeSingleTrade,
                                    onWithdrawSafetyVault = viewModel::withdrawFromSafetyVaultByOwner
                                )
                            }
                            composable(NavDestination.StrategyMemory.route) {
                                StrategyHrMemoryScreen(
                                    strategies = strategies,
                                    agents = agents,
                                    learningLogs = learningLogs,
                                    isBacktesting = isBacktesting,
                                    isCommandRunning = isCommandRunning,
                                    lastBacktestReport = lastBacktestReport,
                                    onRunBacktest = viewModel::runStrategyBacktest,
                                    onApproveStrategyLive = viewModel::approveStrategyForLive,
                                    onEvolveCollectiveIntelligence = viewModel::runCollectiveIntelligenceUpgrade,
                                    onSummonUncleSaab = viewModel::summonUncleSaabForEvaluation,
                                    onRunStrictAudit = viewModel::runStrictDisciplineAudit,
                                    onRecruitCandidate = viewModel::recruitAndTestHrCandidate,
                                    onApproveCandidate = viewModel::approveHrCandidate
                                )
                            }
                            composable(NavDestination.BrokerControl.route) {
                                BrokerControlScreen(
                                    config = activeConfig,
                                    isNetworkOnline = isNetworkOnline,
                                    brokerCreds = brokerCreds,
                                    brokerSnapshot = brokerSnapshot,
                                    auditLogs = auditLogs,
                                    onToggleCloudEngine = viewModel::toggleCloudAutonomousEngine,
                                    onSaveAndTestBroker = viewModel::saveAndTestBrokerConnection,
                                    onUpdateRiskSettings = viewModel::updateRiskSettings,
                                    onSwitchMode = viewModel::setTradingMode,
                                    onToggleKillSwitch = viewModel::toggleKillSwitch,
                                    onToggleTradingPause = viewModel::toggleTradingPause,
                                    onToggleSniper = viewModel::toggleSniperOperations,
                                    onEmergencyCloseAll = viewModel::emergencyCloseAllOpenTrades
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
