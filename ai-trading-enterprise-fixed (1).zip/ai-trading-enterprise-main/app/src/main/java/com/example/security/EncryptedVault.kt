package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.model.BrokerCredentials
import com.example.model.BrokerPlatform
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Hardware-backed Android Keystore AES-256-GCM vault for broker API keys & secrets.
 * Credentials never touch Firestore, source code, or plaintext preferences.
 */
class EncryptedVault(context: Context) {

    private val appContext = context.applicationContext
    private val prefs by lazy {
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existingKey = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existingKey != null) return existingKey

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun encrypt(plaintext: String): String {
        if (plaintext.isEmpty()) return ""
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        val ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        val dataB64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP)
        return "$ivB64:$dataB64"
    }

    private fun decrypt(encoded: String): String {
        if (encoded.isBlank() || !encoded.contains(":")) return ""
        return try {
            val parts = encoded.split(":", limit = 2)
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val ciphertext = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    fun saveCredentials(userId: String, creds: BrokerCredentials) {
        val prefix = "u_${userId}_"
        prefs.edit()
            .putString("${prefix}platform", creds.platform.name)
            .putString("${prefix}account_type", creds.accountType)
            .putString("${prefix}api_key", encrypt(creds.apiKey))
            .putString("${prefix}api_secret", encrypt(creds.apiSecret))
            .putString("${prefix}endpoint", encrypt(creds.customEndpoint))
            .putBoolean("${prefix}testnet", creds.useTestnet)
            .putBoolean("${prefix}withdraw_disabled", creds.withdrawalDisabledConfirmed)
            .apply()
    }

    fun loadCredentials(userId: String): BrokerCredentials {
        val prefix = "u_${userId}_"
        val platformName = prefs.getString("${prefix}platform", BrokerPlatform.QUANTCORP_PAPER.name)
            ?: BrokerPlatform.QUANTCORP_PAPER.name
        val platform = BrokerPlatform.entries.firstOrNull { it.name == platformName }
            ?: BrokerPlatform.QUANTCORP_PAPER
        return BrokerCredentials(
            platform = platform,
            accountType = prefs.getString("${prefix}account_type", "Spot / Paper") ?: "Spot / Paper",
            apiKey = decrypt(prefs.getString("${prefix}api_key", "") ?: ""),
            apiSecret = decrypt(prefs.getString("${prefix}api_secret", "") ?: ""),
            customEndpoint = decrypt(prefs.getString("${prefix}endpoint", "") ?: ""),
            useTestnet = prefs.getBoolean("${prefix}testnet", true),
            withdrawalDisabledConfirmed = prefs.getBoolean("${prefix}withdraw_disabled", true)
        )
    }

    fun clearCredentials(userId: String) {
        val prefix = "u_${userId}_"
        prefs.edit()
            .remove("${prefix}platform")
            .remove("${prefix}account_type")
            .remove("${prefix}api_key")
            .remove("${prefix}api_secret")
            .remove("${prefix}endpoint")
            .remove("${prefix}testnet")
            .remove("${prefix}withdraw_disabled")
            .apply()
    }

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "quantcorp_broker_vault_aes256"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val PREFS_NAME = "quantcorp_encrypted_vault"
    }
}
