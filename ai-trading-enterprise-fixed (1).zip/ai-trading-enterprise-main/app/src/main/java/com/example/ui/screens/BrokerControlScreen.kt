package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.model.AuditLog
import com.example.model.BrokerAccountSnapshot
import com.example.model.BrokerCredentials
import com.example.model.BrokerPlatform
import com.example.model.CompanyConfig
import com.example.model.formatUsdCents
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldProfit
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated

@Composable
fun BrokerControlScreen(
    config: CompanyConfig,
    isNetworkOnline: Boolean,
    brokerCreds: BrokerCredentials,
    brokerSnapshot: BrokerAccountSnapshot,
    auditLogs: List<AuditLog>,
    onToggleCloudEngine: (Boolean) -> Unit,
    onSaveAndTestBroker: (BrokerCredentials) -> Unit,
    onUpdateRiskSettings: (Double, Double, Double, Long) -> Unit,
    onSwitchMode: (String, Boolean) -> Unit,
    onToggleKillSwitch: (Boolean) -> Unit,
    onToggleTradingPause: (Boolean) -> Unit,
    onToggleSniper: (Boolean) -> Unit = {},
    onEmergencyCloseAll: () -> Unit
) {
    var selectedPlatform by remember(brokerCreds) { mutableStateOf(brokerCreds.platform) }
    var apiKey by remember(brokerCreds) { mutableStateOf(brokerCreds.apiKey) }
    var apiSecret by remember(brokerCreds) { mutableStateOf(brokerCreds.apiSecret) }
    var customEndpoint by remember(brokerCreds) { mutableStateOf(brokerCreds.customEndpoint) }
    var useTestnet by remember(brokerCreds) { mutableStateOf(brokerCreds.useTestnet) }
    var withdrawDisabled by remember(brokerCreds) { mutableStateOf(brokerCreds.withdrawalDisabledConfirmed) }

    var capitalStr by remember(config.allocatedCapital) { mutableStateOf(config.allocatedCapital.toLong().toString()) }
    var riskPctStr by remember(config.maxRiskPerTradePct) { mutableStateOf(config.maxRiskPerTradePct.toString()) }
    var dailyLossStr by remember(config.dailyLossLimitPct) { mutableStateOf(config.dailyLossLimitPct.toString()) }
    var maxPosStr by remember(config.maxOpenPositions) { mutableStateOf(config.maxOpenPositions.toString()) }

    var showLiveConfirmDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("broker_control_list"),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section 0: 24/7 Cloud Autonomous Engine & Offline Persistence Sync
        item {
            val cloudActive = config.cloudEngineEnabled
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (cloudActive) EmeraldProfit.copy(alpha = 0.65f) else ChampagneGold.copy(alpha = 0.45f),
                        RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "المحرك السحابي المستقل 24/7 (Cloud Engine)",
                                style = MaterialTheme.typography.titleMedium,
                                color = if (cloudActive) EmeraldProfit else ChampagneGold,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (cloudActive) {
                                    "التشغيل السحابي 24/7 مفعّل — تستمر الشركة بالبحث والتداول عبر Cloud Scheduler حتى عند إغلاق الهاتف."
                                } else {
                                    "التشغيل المحلي — يعمل الوكلاء عند إصدار الأوامر من جهازك."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = cloudActive,
                            onCheckedChange = onToggleCloudEngine,
                            modifier = Modifier.testTag("cloud_engine_switch")
                        )
                    }

                    Surface(
                        color = ObsidianSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ObsidianBorder, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (cloudActive) "المسار: تشغيل سحابي 24/7" else "المسار: تشغيل محلي",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (cloudActive) ElectricCyan else ChampagneGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = config.cloudEngineStatus.ifBlank { if (cloudActive) "RUNNING" else "STANDBY" },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (cloudActive) EmeraldProfit else AmberWarn,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = if (isNetworkOnline) {
                                    "المزامنة الحية: متصل بالسحابة • Firestore Offline Cache جاهز"
                                } else {
                                    "المزامنة الحية: بدون إنترنت — يتم عرض آخر البيانات المحفوظة محلياً والمزامنة تلقائياً فور الاتصال"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isNetworkOnline) EmeraldProfit else AmberWarn
                            )
                            if (config.cloudLastSummary.isNotBlank()) {
                                Text(
                                    text = "آخر دورة سحابية: ${config.cloudLastSummary}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 1: TRADING ACCOUNT CONNECTION
        item {
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TRADING ACCOUNT CONNECTION", style = MaterialTheme.typography.titleMedium, color = ElectricCyan, fontWeight = FontWeight.Bold)
                    Text("ربط حساب التداول الرسمي عبر واجهات API المشفرة بخزنة Android Keystore (AES-256-GCM).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    // Live Connection Status Card
                    Surface(
                        color = ObsidianSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (brokerSnapshot.connected) EmeraldProfit else CrimsonRisk, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(brokerSnapshot.platform.displayName, style = MaterialTheme.typography.titleSmall, color = ChampagneGold)
                                Text(
                                    text = if (brokerSnapshot.connected) "CONNECTED" else "DISCONNECTED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (brokerSnapshot.connected) EmeraldProfit else CrimsonRisk,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text("الرصيد: $${"%,.2f".format(brokerSnapshot.balance)} | Equity: $${"%,.2f".format(brokerSnapshot.equity)} | صفقات مفتوحة: ${brokerSnapshot.openOrdersCount}", style = MaterialTheme.typography.bodySmall)
                            Text(brokerSnapshot.statusMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Text("اختر منصة التداول:", style = MaterialTheme.typography.titleSmall)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        BrokerPlatform.entries.chunked(2).forEach { rowItems ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowItems.forEach { platform ->
                                    FilterChip(
                                        selected = selectedPlatform == platform,
                                        onClick = { selectedPlatform = platform },
                                        label = { Text(platform.displayName, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        text = selectedPlatform.noteAr,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (selectedPlatform == BrokerPlatform.METATRADER_5) AmberWarn else ElectricCyan
                    )

                    if (selectedPlatform != BrokerPlatform.QUANTCORP_PAPER) {
                        if (selectedPlatform == BrokerPlatform.METATRADER_5) {
                            OutlinedTextField(
                                value = customEndpoint,
                                onValueChange = { customEndpoint = it },
                                label = { Text("عنوان جسر MT5 REST Bridge (HTTPS)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = { apiKey = it },
                            label = { Text("API Key (صلاحية قراءة وتداول فقط)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = apiSecret,
                            onValueChange = { apiSecret = it },
                            label = { Text("API Secret (مشفر محلياً بالـ Keystore)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("استخدام شبكة الاختبار (Testnet / Paper API)", style = MaterialTheme.typography.bodySmall)
                            Switch(checked = useTestnet, onCheckedChange = { useTestnet = it })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = withdrawDisabled, onCheckedChange = { withdrawDisabled = it })
                            Text("أؤكد أن مفتاح API لا يملك صلاحيات سحب أو تحويل مالي.", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Button(
                        onClick = {
                            onSaveAndTestBroker(
                                BrokerCredentials(
                                    platform = selectedPlatform,
                                    accountType = if (useTestnet) "Testnet / Paper" else "Live Account",
                                    apiKey = apiKey.trim(),
                                    apiSecret = apiSecret.trim(),
                                    customEndpoint = customEndpoint.trim(),
                                    useTestnet = useTestnet,
                                    withdrawalDisabledConfirmed = withdrawDisabled
                                )
                            )
                        },
                        enabled = selectedPlatform == BrokerPlatform.QUANTCORP_PAPER || withdrawDisabled,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = ObsidianBg),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_broker_connection_button")
                    ) {
                        Text("حفظ مشفر واختبار الاتصال بالوسيط", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section 2: Owner-Only Control Panel & Risk Limits
        item {
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ChampagneGold.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("لوحة تحكم المالك الحصرية (Owner Control)", style = MaterialTheme.typography.titleMedium, color = ChampagneGold, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("وضع التنفيذ النشط: ${config.tradingMode}", style = MaterialTheme.typography.titleSmall, color = if (config.tradingMode == "LIVE") CrimsonRisk else EmeraldProfit)
                            Text("الافتراضي هو الوضع التجريبي حتى موافقتك الصريحة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = {
                                if (config.tradingMode == "PAPER") showLiveConfirmDialog = true
                                else onSwitchMode("PAPER", false)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (config.tradingMode == "LIVE") EmeraldProfit else CrimsonRisk,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (config.tradingMode == "LIVE") "العودة للتجريبي" else "تفعيل الحقيقي")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = capitalStr,
                            onValueChange = { capitalStr = it },
                            label = { Text("رأس المال ($)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = riskPctStr,
                            onValueChange = { riskPctStr = it },
                            label = { Text("المخاطرة %") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dailyLossStr,
                            onValueChange = { dailyLossStr = it },
                            label = { Text("حد الخسارة اليومي %") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = maxPosStr,
                            onValueChange = { maxPosStr = it },
                            label = { Text("أقصى صفقات مفتوحة") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Button(
                        onClick = {
                            onUpdateRiskSettings(
                                capitalStr.toDoubleOrNull() ?: config.allocatedCapital,
                                riskPctStr.toDoubleOrNull() ?: config.maxRiskPerTradePct,
                                dailyLossStr.toDoubleOrNull() ?: config.dailyLossLimitPct,
                                maxPosStr.toLongOrNull() ?: config.maxOpenPositions
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianBg),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("حفظ حدود رأس المال والمخاطر", fontWeight = FontWeight.Bold)
                    }

                    // Emergency & Specialized Agent Controls
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("إيقاف التداول فقط (Trading Pause)", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = config.tradingPaused, onCheckedChange = onToggleTradingPause)
                    }

                    // Admin Panel Control: Enable / Disable Sniper Agent (100% Confirmation Only)
                    Surface(
                        color = ObsidianSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (config.sniperEnabled) ChampagneGold.copy(alpha = 0.65f) else CrimsonRisk.copy(alpha = 0.45f),
                                RoundedCornerShape(12.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "🎯 تشغيل / تعطيل عمليات القناص (Sniper Agent)",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = if (config.sniperEnabled) ChampagneGold else CrimsonRisk,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (config.sniperEnabled) {
                                            "مفعّل — القناص يبحث بهدوء ولا ينفذ إلا عند تأكيد 100% (5/5 مؤشرات)."
                                        } else {
                                            "معطّل — تم إيقاف صفقات وعمليات القناص إدارياً."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = config.sniperEnabled,
                                    onCheckedChange = onToggleSniper,
                                    modifier = Modifier.testTag("admin_sniper_switch")
                                )
                            }
                            Text(
                                text = "شروط القنص الإلزامية (100%): توافق الأطر (15m+1h+4h) + تدفق دفتر الأوامر Bid/Ask + طفرة حجم تداول + مساحة RSI + عائد لمخاطرة ≥ 2:1.",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (config.sniperEnabled) ElectricCyan else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onToggleKillSwitch(!config.killSwitchActive) },
                            colors = ButtonDefaults.buttonColors(containerColor = if (config.killSwitchActive) EmeraldProfit else CrimsonRisk),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (config.killSwitchActive) "إلغاء Kill Switch" else "إيقاف الشركة (Kill Switch)")
                        }
                        Button(
                            onClick = onEmergencyCloseAll,
                            colors = ButtonDefaults.buttonColors(containerColor = AmberWarn, contentColor = ObsidianBg),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إغلاق جميع الصفقات فوراً", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Company Safety Vault Read-Only Protection Status
                    Surface(
                        color = ObsidianSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ChampagneGold.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🛡️ خزنة أمان الشركة (${config.safetyVaultAllocationPct.toInt()}% تلقائياً):",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = ChampagneGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = formatUsdCents(config.safetyVaultBalance),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = EmeraldProfit,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "محجوز إجمالي لمنع الإفلاس: ${formatUsdCents(config.safetyVaultTotalDeposited)} — معزول تماماً عن وكلاء التداول ولا يُسحب إلا بتدخلك الشخصي من لوحة الأرباح.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Section 3: Operations & Security Audit Log
        item {
            Text("سجل العمليات والرقابة (${auditLogs.size})", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
        }
        items(auditLogs.take(25), key = { it.id }) { log ->
            val sevColor = when (log.severity) {
                "CRITICAL" -> CrimsonRisk
                "WARNING" -> AmberWarn
                else -> ElectricCyan
            }
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${log.actor} • ${log.actionType}", style = MaterialTheme.typography.labelMedium, color = sevColor)
                        Text(log.severity, style = MaterialTheme.typography.labelSmall, color = sevColor)
                    }
                    Text(log.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }

    if (showLiveConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLiveConfirmDialog = false },
            title = { Text("تأكيد تفعيل التداول الحقيقي (LIVE)", color = CrimsonRisk) },
            text = {
                Text("هل تؤكد موافقتك الصريحة على تفعيل التداول الحقيقي؟ سيتم تنفيذ الصفقات بأموال حقيقية فقط للاستراتيجيات المعتمدة وضمن حدود المخاطرة المحددة.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLiveConfirmDialog = false
                        onSwitchMode("LIVE", true)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRisk)
                ) {
                    Text("نعم، أوافق على التفعيل الحقيقي")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLiveConfirmDialog = false }) {
                    Text("إلغاء والبقاء بالتجريبي")
                }
            }
        )
    }
}
