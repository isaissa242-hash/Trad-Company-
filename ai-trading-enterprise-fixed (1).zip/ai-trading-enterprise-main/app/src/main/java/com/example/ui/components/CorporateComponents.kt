package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AgentStatus
import com.example.model.CandleBar
import com.example.model.CompanyConfig
import com.example.model.PnLSummary
import com.example.model.formatUsdCents
import com.example.ui.theme.AmberBg
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonBg
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldBg
import com.example.ui.theme.EmeraldProfit
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.VioletAgent

@Composable
fun CorporateTopBar(
    config: CompanyConfig,
    pnlSummary: PnLSummary? = null,
    isNetworkOnline: Boolean = true,
    onToggleKillSwitch: () -> Unit,
    onRefreshMarkets: () -> Unit,
    onSignOut: () -> Unit
) {
    val killColor by animateColorAsState(
        targetValue = if (config.killSwitchActive) CrimsonRisk else EmeraldProfit,
        label = "killColor"
    )
    Surface(
        color = ObsidianSurface,
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = ObsidianBorder, shape = RoundedCornerShape(0.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "QuantCorp AI",
                        style = MaterialTheme.typography.titleMedium,
                        color = ChampagneGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    ModePill(mode = config.tradingMode, paused = config.tradingPaused)
                    if (config.cloudEngineEnabled) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Surface(
                            color = Color(0xFF102A3A),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "☁️ 24/7",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricCyan,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = when {
                        config.killSwitchActive -> "تم تفعيل Kill Switch — جميع الأوامر موقوفة"
                        !isNetworkOnline -> "وضع عدم الاتصال (Offline Cache) • المزامنة تلقائياً عند العودة"
                        config.tradingPaused -> "التداول متوقف مؤقتاً (البحث مستمر)"
                        config.cloudEngineEnabled -> "السحابة 24/7 نشطة • الحماية والمخاطر مفعّلة"
                        else -> "الشركة نشطة • الحماية والمخاطر مفعّلة"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (!isNetworkOnline) AmberWarn else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = if (config.killSwitchActive) CrimsonBg else ObsidianSurfaceElevated,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, killColor.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                        .clickable { onToggleKillSwitch() }
                        .testTag("global_kill_switch_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PowerSettingsNew,
                            contentDescription = "Kill Switch",
                            tint = killColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (config.killSwitchActive) "KILL ON" else "KILL",
                            style = MaterialTheme.typography.labelSmall,
                            color = killColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(
                    onClick = onRefreshMarkets,
                    modifier = Modifier.testTag("refresh_markets_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "تحديث الأسعار الحية",
                        tint = ElectricCyan
                    )
                }

                IconButton(
                    onClick = onSignOut,
                    modifier = Modifier.testTag("sign_out_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "تسجيل الخروج",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            }

            if (pnlSummary != null) {
                val liveTotalProfit = pnlSummary.netRealizedProfit + pnlSummary.unrealizedPnl
                val profitColor = if (liveTotalProfit >= 0.0) EmeraldProfit else CrimsonRisk
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ObsidianSurfaceElevated)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("live_cents_profit_strip"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(profitColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "الربح المباشر: ${formatUsdCents(liveTotalProfit, signed = true)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = profitColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (config.safetyVaultBalance > 0.0) {
                            Surface(
                                color = ChampagneGold.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .border(0.5.dp, ChampagneGold.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                                    .testTag("topbar_safety_vault_pill")
                            ) {
                                Text(
                                    text = "🛡️ ${formatUsdCents(config.safetyVaultBalance)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ChampagneGold,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        if (config.profitTargetUsd > 0.0) {
                            val towardGoal = (liveTotalProfit - config.profitTargetBaselinePnl).coerceAtLeast(0.0)
                            Text(
                                text = "الهدف: ${formatUsdCents(towardGoal)} / ${formatUsdCents(config.profitTargetUsd)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else {
                            Text(
                                text = "Equity: ${formatUsdCents(pnlSummary.equity)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ChampagneGold,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModePill(mode: String, paused: Boolean) {
    val isLive = mode == "LIVE"
    val bg = when {
        paused -> AmberBg
        isLive -> CrimsonBg
        else -> EmeraldBg
    }
    val fg = when {
        paused -> AmberWarn
        isLive -> CrimsonRisk
        else -> EmeraldProfit
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = if (paused) "PAUSED" else mode,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun AgentStatusBadge(statusRaw: String) {
    val status = AgentStatus.fromRaw(statusRaw)
    val (bg, fg) = when (status) {
        AgentStatus.WORKING -> Color(0xFF132D46) to ElectricCyan
        AgentStatus.RESEARCHING -> Color(0xFF281F47) to VioletAgent
        AgentStatus.ANALYZING -> Color(0xFF0E323D) to ElectricCyan
        AgentStatus.TRADING -> EmeraldBg to EmeraldProfit
        AgentStatus.REVIEWING -> AmberBg to AmberWarn
        AgentStatus.WAITING -> ObsidianSurfaceElevated to TextMuted
        AgentStatus.COMPLETED -> EmeraldBg to EmeraldProfit
        AgentStatus.ERROR -> CrimsonBg to CrimsonRisk
    }
    Surface(color = bg, shape = RoundedCornerShape(8.dp)) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = status.label,
                style = MaterialTheme.typography.labelSmall,
                color = fg,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun EquityCurveChart(
    points: List<Double>,
    modifier: Modifier = Modifier
) {
    val safePoints = if (points.size >= 2) points else listOf(100_000.0, 100_000.0)
    val isPositive = safePoints.last() >= safePoints.first()
    val strokeColor = if (isPositive) EmeraldProfit else CrimsonRisk

    Canvas(modifier = modifier) {
        val minVal = safePoints.minOrNull() ?: 0.0
        val maxVal = safePoints.maxOrNull() ?: 1.0
        val range = (maxVal - minVal).takeIf { it > 0.0 } ?: 1.0

        val w = size.width
        val h = size.height
        val pad = 8f

        // Subtle horizontal gridlines
        for (i in 0..3) {
            val y = pad + (h - 2 * pad) * (i / 3f)
            drawLine(
                color = ObsidianBorder.copy(alpha = 0.5f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
        }

        val path = Path()
        val fillPath = Path()
        safePoints.forEachIndexed { idx, value ->
            val x = if (safePoints.size == 1) w else (idx.toFloat() / (safePoints.size - 1)) * w
            val norm = ((value - minVal) / range).toFloat()
            val y = (h - pad) - norm * (h - 2 * pad)
            if (idx == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(w, h)
        fillPath.close()

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(strokeColor.copy(alpha = 0.28f), Color.Transparent)
            )
        )
        drawPath(
            path = path,
            color = strokeColor,
            style = Stroke(width = 4f, cap = StrokeCap.Round)
        )
    }
}

@Composable
fun CandlestickChart(
    bars: List<CandleBar>,
    modifier: Modifier = Modifier
) {
    if (bars.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                text = "جاري تحميل الشموع الحية...",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }
    val visibleBars = bars.takeLast(48)
    Canvas(modifier = modifier) {
        val minLow = visibleBars.minOf { it.low }
        val maxHigh = visibleBars.maxOf { it.high }
        val range = (maxHigh - minLow).takeIf { it > 0.0 } ?: 1.0
        val w = size.width
        val h = size.height
        val pad = 10f

        for (i in 0..3) {
            val y = pad + (h - 2 * pad) * (i / 3f)
            drawLine(
                color = ObsidianBorder.copy(alpha = 0.45f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
        }

        val step = w / visibleBars.size
        val candleWidth = (step * 0.62f).coerceAtLeast(3f)

        visibleBars.forEachIndexed { idx, bar ->
            val cx = idx * step + step / 2f
            fun yFor(price: Double): Float {
                val norm = ((price - minLow) / range).toFloat()
                return (h - pad) - norm * (h - 2 * pad)
            }

            val yHigh = yFor(bar.high)
            val yLow = yFor(bar.low)
            val yOpen = yFor(bar.open)
            val yClose = yFor(bar.close)
            val isBull = bar.close >= bar.open
            val color = if (isBull) EmeraldProfit else CrimsonRisk

            drawLine(
                color = color,
                start = Offset(cx, yHigh),
                end = Offset(cx, yLow),
                strokeWidth = 2f
            )
            val top = minOf(yOpen, yClose)
            val bodyH = kotlin.math.abs(yClose - yOpen).coerceAtLeast(2f)
            drawRect(
                color = color,
                topLeft = Offset(cx - candleWidth / 2f, top),
                size = Size(candleWidth, bodyH)
            )
        }
    }
}
