package com.example.data.market

import com.example.model.BacktestReport
import com.example.model.CandleBar
import com.example.model.TradingStrategy
import kotlin.math.max

/**
 * Real Historical + Walk-Forward + Out-of-Sample Backtesting Engine.
 * Splits real OHLCV history into 60% In-Sample and 40% Out-of-Sample,
 * explicitly charging commission (0.10%/side) and slippage (0.05%/side).
 */
object BacktestEngine {

    private const val COMMISSION_PER_SIDE = 0.0010
    private const val SLIPPAGE_PER_SIDE = 0.0005

    fun runWalkForwardBacktest(
        strategy: TradingStrategy,
        symbol: String,
        bars: List<CandleBar>
    ): BacktestReport {
        require(bars.size >= 80) { "Need at least 80 real historical candles to run walk-forward test." }

        val splitIndex = (bars.size * 0.60).toInt().coerceIn(40, bars.size - 30)
        val inSampleBars = bars.subList(0, splitIndex)
        val outSampleBars = bars.subList(splitIndex - 30, bars.size) // 30 bars warmup for indicators

        val inSampleRes = simulateSegment(strategy.id, inSampleBars, startEvalIndex = 30)
        val outSampleRes = simulateSegment(strategy.id, outSampleBars, startEvalIndex = 30)

        val passed = outSampleRes.totalTrades >= 3 &&
            outSampleRes.returnPct > 0.0 &&
            outSampleRes.maxDrawdownPct <= 15.0 &&
            outSampleRes.profitFactor >= 1.10

        val summaryAr = if (passed) {
            "اجتازت الاستراتيجية الاختبار التاريخي وخارج العينة (Out-of-Sample) بعائد ${"%.2f".format(outSampleRes.returnPct)}% ومعامل ربح ${"%.2f".format(outSampleRes.profitFactor)} بعد احتساب العمولات والانزلاق."
        } else {
            "لم تجتز الاستراتيجية معايير الترقية الصارمة على بيانات $symbol خارج العينة (العائد: ${"%.2f".format(outSampleRes.returnPct)}%، الصفقات: ${outSampleRes.totalTrades}، أقصى تراجع: ${"%.2f".format(outSampleRes.maxDrawdownPct)}%)."
        }

        return BacktestReport(
            strategyId = strategy.id,
            symbol = symbol,
            barsTested = bars.size,
            inSampleReturnPct = inSampleRes.returnPct,
            walkForwardReturnPct = outSampleRes.returnPct,
            outOfSampleWinRate = outSampleRes.winRatePct,
            maxDrawdownPct = max(inSampleRes.maxDrawdownPct, outSampleRes.maxDrawdownPct),
            profitFactor = outSampleRes.profitFactor,
            totalTrades = inSampleRes.totalTrades + outSampleRes.totalTrades,
            feesAndSlippagePct = (COMMISSION_PER_SIDE + SLIPPAGE_PER_SIDE) * 200.0,
            passedCriteria = passed,
            summaryAr = summaryAr
        )
    }

    private data class SegmentResult(
        val returnPct: Double,
        val winRatePct: Double,
        val maxDrawdownPct: Double,
        val profitFactor: Double,
        val totalTrades: Int
    )

    private fun simulateSegment(
        strategyId: String,
        bars: List<CandleBar>,
        startEvalIndex: Int
    ): SegmentResult {
        var equity = 10_000.0
        var peakEquity = equity
        var maxDrawdownPct = 0.0

        var wins = 0
        var losses = 0
        var grossProfit = 0.0
        var grossLoss = 0.0

        var inPosition = false
        var entryPrice = 0.0
        var stopLoss = 0.0
        var takeProfit = 0.0
        var qty = 0.0

        for (i in startEvalIndex until bars.size) {
            val window = bars.subList(0, i + 1)
            val bar = bars[i]
            val closes = window.map { it.close }
            val ema20 = TechnicalIndicatorEngine.ema(closes, 20)
            val ema50 = TechnicalIndicatorEngine.ema(closes, minOf(50, closes.size))
            val rsi = TechnicalIndicatorEngine.rsi(closes, 14)
            val atr = TechnicalIndicatorEngine.atr(window, 14).coerceAtLeast(bar.close * 0.002)

            if (inPosition) {
                var exitTrigger: Double? = null
                if (bar.low <= stopLoss) {
                    exitTrigger = stopLoss * (1.0 - SLIPPAGE_PER_SIDE)
                } else if (bar.high >= takeProfit) {
                    exitTrigger = takeProfit * (1.0 - SLIPPAGE_PER_SIDE)
                } else if (bar.close < ema20 && rsi > 62.0) {
                    exitTrigger = bar.close * (1.0 - SLIPPAGE_PER_SIDE)
                }

                if (exitTrigger != null) {
                    val exitNotional = exitTrigger * qty
                    val exitFee = exitNotional * COMMISSION_PER_SIDE
                    val entryNotional = entryPrice * qty
                    val entryFee = entryNotional * COMMISSION_PER_SIDE
                    val netPnl = (exitNotional - entryNotional) - (entryFee + exitFee)
                    equity += netPnl
                    if (netPnl >= 0) {
                        wins++
                        grossProfit += netPnl
                    } else {
                        losses++
                        grossLoss += kotlin.math.abs(netPnl)
                    }
                    inPosition = false
                    peakEquity = max(peakEquity, equity)
                    val dd = if (peakEquity > 0) ((peakEquity - equity) / peakEquity) * 100.0 else 0.0
                    maxDrawdownPct = max(maxDrawdownPct, dd)
                }
            } else {
                val recent20High = window.dropLast(1).takeLast(20).maxOf { it.high }
                val avgVol = window.dropLast(1).takeLast(20).map { it.volume }.average().coerceAtLeast(1e-9)
                val mean20 = closes.takeLast(20).average()
                val std20 = kotlin.math.sqrt(closes.takeLast(20).sumOf { (it - mean20) * (it - mean20) } / 20.0)
                val bbLower = mean20 - 2.0 * std20

                val signalBuy = when (strategyId) {
                    "strat_rsi_reversion" -> bar.close <= bbLower * 1.005 || rsi < 36.0
                    "strat_breakout_vol" -> bar.close > recent20High && bar.volume > avgVol * 1.25
                    else -> bar.close > ema20 && ema20 > ema50 && rsi in 42.0..68.0
                }

                if (signalBuy) {
                    entryPrice = bar.close * (1.0 + SLIPPAGE_PER_SIDE)
                    stopLoss = entryPrice - (1.5 * atr)
                    takeProfit = entryPrice + (2.5 * atr)
                    val riskBudget = equity * 0.015 // 1.5% risk per trade
                    val stopDist = (entryPrice - stopLoss).coerceAtLeast(entryPrice * 0.003)
                    qty = (riskBudget / stopDist).coerceAtMost((equity * 0.5) / entryPrice)
                    if (qty > 0.0) {
                        inPosition = true
                    }
                }
            }
        }

        val totalTrades = wins + losses
        val winRate = if (totalTrades > 0) (wins.toDouble() / totalTrades) * 100.0 else 0.0
        val profitFactor = when {
            grossLoss > 0.0 -> grossProfit / grossLoss
            grossProfit > 0.0 -> 3.0
            else -> 0.0
        }
        val returnPct = ((equity - 10_000.0) / 10_000.0) * 100.0

        return SegmentResult(
            returnPct = returnPct,
            winRatePct = winRate,
            maxDrawdownPct = maxDrawdownPct,
            profitFactor = profitFactor,
            totalTrades = totalTrades
        )
    }
}
