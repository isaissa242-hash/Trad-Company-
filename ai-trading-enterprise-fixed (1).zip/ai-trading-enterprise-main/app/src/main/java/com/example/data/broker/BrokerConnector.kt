package com.example.data.broker

import com.example.model.BrokerAccountSnapshot
import com.example.model.BrokerCredentials
import com.example.model.BrokerPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Official REST Broker Integration Layer.
 * - QuantCorp Paper Engine: real live-price paper execution.
 * - Binance Spot / Testnet: HMAC-SHA256 signed REST API.
 * - Alpaca Paper / Live: APCA header authenticated REST API.
 * - Bybit V5 Testnet / Live: HMAC-SHA256 signed V5 REST API.
 * - MetaTrader 5 Bridge: User-hosted HTTP Bearer MT5 Gateway REST API (never fakes screen-clicks).
 */
class BrokerConnector {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    suspend fun fetchAccountSnapshot(
        creds: BrokerCredentials,
        paperBalance: Double,
        paperOpenCount: Int,
        paperUnrealizedPnl: Double
    ): BrokerAccountSnapshot = withContext(Dispatchers.IO) {
        when (creds.platform) {
            BrokerPlatform.QUANTCORP_PAPER -> BrokerAccountSnapshot(
                platform = BrokerPlatform.QUANTCORP_PAPER,
                connected = true,
                modeLabel = "Paper Engine",
                balance = paperBalance,
                equity = paperBalance + paperUnrealizedPnl,
                openOrdersCount = paperOpenCount,
                statusMessage = "متصل بمحرك التداول التجريبي المرتبط بالأسعار الحية",
                fetchedAtMillis = System.currentTimeMillis()
            )

            BrokerPlatform.BINANCE_SPOT -> fetchBinanceAccount(creds)
            BrokerPlatform.ALPACA_TRADING -> fetchAlpacaAccount(creds)
            BrokerPlatform.BYBIT_V5 -> fetchBybitAccount(creds)
            BrokerPlatform.METATRADER_5 -> fetchMt5BridgeAccount(creds)
        }
    }

    suspend fun submitOrder(
        creds: BrokerCredentials,
        symbol: String,
        side: String,
        quantity: Double,
        isLiveMode: Boolean
    ): Result<String> = withContext(Dispatchers.IO) {
        if (!isLiveMode || creds.platform == BrokerPlatform.QUANTCORP_PAPER) {
            return@withContext Result.success("PAPER-${UUID.randomUUID().toString().take(8).uppercase()}")
        }
        if (creds.apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("مفاتيح الربط غير مدخلة في الخزنة المشفرة."))
        }
        when (creds.platform) {
            BrokerPlatform.BINANCE_SPOT -> submitBinanceMarketOrder(creds, symbol, side, quantity)
            BrokerPlatform.ALPACA_TRADING -> submitAlpacaOrder(creds, symbol, side, quantity)
            BrokerPlatform.BYBIT_V5 -> submitBybitOrder(creds, symbol, side, quantity)
            BrokerPlatform.METATRADER_5 -> submitMt5BridgeOrder(creds, symbol, side, quantity)
            BrokerPlatform.QUANTCORP_PAPER -> Result.success("PAPER-${UUID.randomUUID().toString().take(8)}")
        }
    }

    private fun fetchBinanceAccount(creds: BrokerCredentials): BrokerAccountSnapshot {
        if (creds.apiKey.isBlank() || creds.apiSecret.isBlank()) {
            return BrokerAccountSnapshot(
                platform = BrokerPlatform.BINANCE_SPOT,
                connected = false,
                modeLabel = if (creds.useTestnet) "Testnet" else "Live",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "يرجى إدخال API Key و Secret محدود الصلاحية (بدون صلاحية سحب)"
            )
        }
        return try {
            val base = if (creds.useTestnet) "https://testnet.binance.vision" else "https://api.binance.com"
            val ts = System.currentTimeMillis()
            val query = "timestamp=$ts"
            val sig = hmacSha256(query, creds.apiSecret)
            val req = Request.Builder()
                .url("$base/api/v3/account?$query&signature=$sig")
                .addHeader("X-MBX-APIKEY", creds.apiKey)
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return BrokerAccountSnapshot(
                        platform = BrokerPlatform.BINANCE_SPOT,
                        connected = false,
                        modeLabel = if (creds.useTestnet) "Testnet" else "Live",
                        balance = 0.0,
                        equity = 0.0,
                        openOrdersCount = 0,
                        statusMessage = "خطأ Binance HTTP ${resp.code}: ${body.take(120)}"
                    )
                }
                val json = JSONObject(body)
                val balances = json.optJSONArray("balances") ?: JSONArray()
                var usdtFree = 0.0
                var usdtLocked = 0.0
                for (i in 0 until balances.length()) {
                    val b = balances.getJSONObject(i)
                    if (b.optString("asset") == "USDT") {
                        usdtFree = b.optString("free").toDoubleOrNull() ?: 0.0
                        usdtLocked = b.optString("locked").toDoubleOrNull() ?: 0.0
                    }
                }
                BrokerAccountSnapshot(
                    platform = BrokerPlatform.BINANCE_SPOT,
                    connected = true,
                    modeLabel = if (creds.useTestnet) "Binance Testnet" else "Binance Live",
                    balance = usdtFree,
                    equity = usdtFree + usdtLocked,
                    openOrdersCount = 0,
                    statusMessage = "متصل رسمياً بواجهة Binance REST (${if (creds.useTestnet) "Testnet" else "Live"})"
                )
            }
        } catch (e: Exception) {
            BrokerAccountSnapshot(
                platform = BrokerPlatform.BINANCE_SPOT,
                connected = false,
                modeLabel = if (creds.useTestnet) "Testnet" else "Live",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "تعذر الاتصال بـ Binance: ${e.localizedMessage}"
            )
        }
    }

    private fun submitBinanceMarketOrder(
        creds: BrokerCredentials,
        symbol: String,
        side: String,
        quantity: Double
    ): Result<String> {
        return try {
            val base = if (creds.useTestnet) "https://testnet.binance.vision" else "https://api.binance.com"
            val ts = System.currentTimeMillis()
            val qtyStr = String.format(Locale.US, "%.4f", quantity)
            val query = "symbol=$symbol&side=$side&type=MARKET&quantity=$qtyStr&timestamp=$ts"
            val sig = hmacSha256(query, creds.apiSecret)
            val req = Request.Builder()
                .url("$base/api/v3/order?$query&signature=$sig")
                .addHeader("X-MBX-APIKEY", creds.apiKey)
                .post("".toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    Result.failure(IllegalStateException("Binance order rejected (${resp.code}): $body"))
                } else {
                    val orderId = JSONObject(body).optLong("orderId", 0L).toString()
                    Result.success("BN-$orderId")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchAlpacaAccount(creds: BrokerCredentials): BrokerAccountSnapshot {
        if (creds.apiKey.isBlank() || creds.apiSecret.isBlank()) {
            return BrokerAccountSnapshot(
                platform = BrokerPlatform.ALPACA_TRADING,
                connected = false,
                modeLabel = if (creds.useTestnet) "Paper" else "Live",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "أدخل APCA-API-KEY-ID و Secret للمصادقة"
            )
        }
        return try {
            val base = if (creds.useTestnet) "https://paper-api.alpaca.markets" else "https://api.alpaca.markets"
            val req = Request.Builder()
                .url("$base/v2/account")
                .addHeader("APCA-API-KEY-ID", creds.apiKey)
                .addHeader("APCA-API-SECRET-KEY", creds.apiSecret)
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return BrokerAccountSnapshot(
                        platform = BrokerPlatform.ALPACA_TRADING,
                        connected = false,
                        modeLabel = if (creds.useTestnet) "Paper" else "Live",
                        balance = 0.0,
                        equity = 0.0,
                        openOrdersCount = 0,
                        statusMessage = "خطأ Alpaca HTTP ${resp.code}: ${body.take(120)}"
                    )
                }
                val json = JSONObject(body)
                BrokerAccountSnapshot(
                    platform = BrokerPlatform.ALPACA_TRADING,
                    connected = true,
                    modeLabel = if (creds.useTestnet) "Alpaca Paper" else "Alpaca Live",
                    balance = json.optString("cash").toDoubleOrNull() ?: 0.0,
                    equity = json.optString("equity").toDoubleOrNull() ?: 0.0,
                    openOrdersCount = 0,
                    statusMessage = "متصل رسمياً بواجهة Alpaca (${json.optString("status")})"
                )
            }
        } catch (e: Exception) {
            BrokerAccountSnapshot(
                platform = BrokerPlatform.ALPACA_TRADING,
                connected = false,
                modeLabel = if (creds.useTestnet) "Paper" else "Live",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "تعذر الاتصال بـ Alpaca: ${e.localizedMessage}"
            )
        }
    }

    private fun submitAlpacaOrder(
        creds: BrokerCredentials,
        symbol: String,
        side: String,
        quantity: Double
    ): Result<String> {
        return try {
            val base = if (creds.useTestnet) "https://paper-api.alpaca.markets" else "https://api.alpaca.markets"
            val alpacaSym = symbol.replace("USDT", "USD")
            val payload = JSONObject().apply {
                put("symbol", alpacaSym)
                put("qty", String.format(Locale.US, "%.4f", quantity))
                put("side", side.lowercase(Locale.US))
                put("type", "market")
                put("time_in_force", "gtc")
            }.toString()
            val req = Request.Builder()
                .url("$base/v2/orders")
                .addHeader("APCA-API-KEY-ID", creds.apiKey)
                .addHeader("APCA-API-SECRET-KEY", creds.apiSecret)
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) Result.failure(IllegalStateException("Alpaca rejected: $body"))
                else Result.success("ALP-${JSONObject(body).optString("id").take(8)}")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchBybitAccount(creds: BrokerCredentials): BrokerAccountSnapshot {
        if (creds.apiKey.isBlank() || creds.apiSecret.isBlank()) {
            return BrokerAccountSnapshot(
                platform = BrokerPlatform.BYBIT_V5,
                connected = false,
                modeLabel = if (creds.useTestnet) "Testnet" else "Live",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "أدخل مفتاح Bybit V5 API Key و Secret"
            )
        }
        return try {
            val base = if (creds.useTestnet) "https://api-testnet.bybit.com" else "https://api.bybit.com"
            val ts = System.currentTimeMillis().toString()
            val recvWindow = "5000"
            val query = "accountType=UNIFIED"
            val signPayload = "$ts${creds.apiKey}$recvWindow$query"
            val sig = hmacSha256(signPayload, creds.apiSecret)
            val req = Request.Builder()
                .url("$base/v5/account/wallet-balance?$query")
                .addHeader("X-BAPI-API-KEY", creds.apiKey)
                .addHeader("X-BAPI-SIGN", sig)
                .addHeader("X-BAPI-TIMESTAMP", ts)
                .addHeader("X-BAPI-RECV-WINDOW", recvWindow)
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return BrokerAccountSnapshot(
                        platform = BrokerPlatform.BYBIT_V5,
                        connected = false,
                        modeLabel = if (creds.useTestnet) "Testnet" else "Live",
                        balance = 0.0,
                        equity = 0.0,
                        openOrdersCount = 0,
                        statusMessage = "خطأ Bybit HTTP ${resp.code}: ${body.take(120)}"
                    )
                }
                val json = JSONObject(body)
                if (json.optInt("retCode", -1) != 0) {
                    return BrokerAccountSnapshot(
                        platform = BrokerPlatform.BYBIT_V5,
                        connected = false,
                        modeLabel = if (creds.useTestnet) "Testnet" else "Live",
                        balance = 0.0,
                        equity = 0.0,
                        openOrdersCount = 0,
                        statusMessage = "Bybit: ${json.optString("retMsg")}"
                    )
                }
                val list = json.optJSONObject("result")?.optJSONArray("list")
                val acct = list?.optJSONObject(0)
                val equity = acct?.optString("totalEquity")?.toDoubleOrNull() ?: 0.0
                val avail = acct?.optString("totalAvailableBalance")?.toDoubleOrNull() ?: equity
                BrokerAccountSnapshot(
                    platform = BrokerPlatform.BYBIT_V5,
                    connected = true,
                    modeLabel = if (creds.useTestnet) "Bybit Testnet" else "Bybit Live",
                    balance = avail,
                    equity = equity,
                    openOrdersCount = 0,
                    statusMessage = "متصل رسمياً بواجهة Bybit V5"
                )
            }
        } catch (e: Exception) {
            BrokerAccountSnapshot(
                platform = BrokerPlatform.BYBIT_V5,
                connected = false,
                modeLabel = if (creds.useTestnet) "Testnet" else "Live",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "تعذر الاتصال بـ Bybit: ${e.localizedMessage}"
            )
        }
    }

    private fun submitBybitOrder(
        creds: BrokerCredentials,
        symbol: String,
        side: String,
        quantity: Double
    ): Result<String> {
        return try {
            val base = if (creds.useTestnet) "https://api-testnet.bybit.com" else "https://api.bybit.com"
            val ts = System.currentTimeMillis().toString()
            val recvWindow = "5000"
            val bodyJson = JSONObject().apply {
                put("category", "spot")
                put("symbol", symbol)
                put("side", if (side == "BUY") "Buy" else "Sell")
                put("orderType", "Market")
                put("qty", String.format(Locale.US, "%.4f", quantity))
            }.toString()
            val sig = hmacSha256("$ts${creds.apiKey}$recvWindow$bodyJson", creds.apiSecret)
            val req = Request.Builder()
                .url("$base/v5/order/create")
                .addHeader("X-BAPI-API-KEY", creds.apiKey)
                .addHeader("X-BAPI-SIGN", sig)
                .addHeader("X-BAPI-TIMESTAMP", ts)
                .addHeader("X-BAPI-RECV-WINDOW", recvWindow)
                .post(bodyJson.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                val respBody = resp.body?.string().orEmpty()
                val json = JSONObject(respBody)
                if (resp.isSuccessful && json.optInt("retCode", -1) == 0) {
                    val orderId = json.optJSONObject("result")?.optString("orderId").orEmpty()
                    Result.success("BB-$orderId")
                } else {
                    Result.failure(IllegalStateException("Bybit order rejected: $respBody"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchMt5BridgeAccount(creds: BrokerCredentials): BrokerAccountSnapshot {
        val url = creds.customEndpoint.trimEnd('/')
        if (url.isBlank() || (!url.startsWith("https://") && !url.startsWith("http://"))) {
            return BrokerAccountSnapshot(
                platform = BrokerPlatform.METATRADER_5,
                connected = false,
                modeLabel = "MT5 Bridge Required",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "MT5 يتطلب خادم REST Bridge (مثل MetaAPI أو Python MT5 Gateway) لأن ميتاتريدر لا توفر REST مباشر للهاتف."
            )
        }
        return try {
            val req = Request.Builder()
                .url("$url/account")
                .apply {
                    if (creds.apiKey.isNotBlank()) addHeader("Authorization", "Bearer ${creds.apiKey}")
                }
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return BrokerAccountSnapshot(
                        platform = BrokerPlatform.METATRADER_5,
                        connected = false,
                        modeLabel = "MT5 Bridge",
                        balance = 0.0,
                        equity = 0.0,
                        openOrdersCount = 0,
                        statusMessage = "خطأ جسر MT5 HTTP ${resp.code}"
                    )
                }
                val json = JSONObject(body)
                BrokerAccountSnapshot(
                    platform = BrokerPlatform.METATRADER_5,
                    connected = true,
                    modeLabel = "MT5 Bridge",
                    balance = json.optDouble("balance", 0.0),
                    equity = json.optDouble("equity", 0.0),
                    openOrdersCount = json.optInt("positionsCount", 0),
                    statusMessage = "متصل بخادم MT5 REST Bridge"
                )
            }
        } catch (e: Exception) {
            BrokerAccountSnapshot(
                platform = BrokerPlatform.METATRADER_5,
                connected = false,
                modeLabel = "MT5 Bridge",
                balance = 0.0,
                equity = 0.0,
                openOrdersCount = 0,
                statusMessage = "تعذر الوصول لجسر MT5: ${e.localizedMessage}"
            )
        }
    }

    internal fun submitMt5BridgeOrder(
        creds: BrokerCredentials,
        symbol: String,
        side: String,
        quantity: Double
    ): Result<String> {
        val url = creds.customEndpoint.trimEnd('/')
        if (url.isBlank() || (!url.startsWith("https://") && !url.startsWith("http://"))) {
            return Result.failure(IllegalStateException("عنوان جسر MT5 غير مهيأ أو لا يبدأ بـ http:// أو https://."))
        }
        return try {
            val payload = JSONObject().apply {
                put("symbol", symbol)
                put("side", side)
                put("volume", quantity)
            }.toString()
            val req = Request.Builder()
                .url("$url/orders")
                .apply {
                    if (creds.apiKey.isNotBlank()) addHeader("Authorization", "Bearer ${creds.apiKey}")
                }
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) Result.failure(IllegalStateException("MT5 Bridge rejected: $body"))
                else Result.success("MT5-${JSONObject(body).optString("orderId", "OK")}")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun hmacSha256(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
