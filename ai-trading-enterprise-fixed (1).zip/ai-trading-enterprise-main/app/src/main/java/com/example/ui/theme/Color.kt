package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Obsidian & Champagne Gold Dark Palette
val ObsidianBg = Color(0xFF070C14)
val ObsidianSurface = Color(0xFF0E1624)
val ObsidianSurfaceElevated = Color(0xFF152136)
val ObsidianSurfaceHigh = Color(0xFF1C2B45)
val ObsidianBorder = Color(0xFF243552)

val ChampagneGold = Color(0xFFE5B95C)
val ChampagneGoldDim = Color(0xFF9F7E39)
val ElectricCyan = Color(0xFF22D3EE)
val EmeraldProfit = Color(0xFF10B981)
val EmeraldBg = Color(0xFF0A2E25)
val CrimsonRisk = Color(0xFFEF4444)
val CrimsonBg = Color(0xFF331116)
val AmberWarn = Color(0xFFF59E0B)
val AmberBg = Color(0xFF33240B)
val VioletAgent = Color(0xFFA78BFA)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Light palette tokens for optional system light mode support
val IvoryBg = Color(0xFFF6F7FB)
val IvorySurface = Color(0xFFFFFFFF)
val IvorySurfaceElevated = Color(0xFFEEF2F8)
val SlateInk = Color(0xFF0F172A)
val SlateSecondary = Color(0xFF475569)
val GoldDark = Color(0xFFB38624)
val CyanDark = Color(0xFF0E7490)
