package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AgentProfile
import com.example.model.BacktestReport
import com.example.model.Department
import com.example.model.InitialCompanyRoster
import com.example.model.LearningLog
import com.example.model.TradingStrategy
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldProfit
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated

@Composable
fun StrategyHrMemoryScreen(
    strategies: List<TradingStrategy>,
    agents: List<AgentProfile>,
    learningLogs: List<LearningLog>,
    isBacktesting: Boolean,
    isCommandRunning: Boolean = false,
    lastBacktestReport: BacktestReport?,
    onRunBacktest: (TradingStrategy, String) -> Unit,
    onApproveStrategyLive: (TradingStrategy, Boolean) -> Unit,
    onEvolveCollectiveIntelligence: () -> Unit = {},
    onSummonUncleSaab: () -> Unit = {},
    onRunStrictAudit: () -> Unit = {},
    onRecruitCandidate: (String, String, String, String, String) -> Unit,
    onApproveCandidate: (String, Boolean) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("الاستراتيجيات والذكاء", "الموارد البشرية HR", "الذاكرة والأخطاء")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = ObsidianSurface,
            contentColor = ChampagneGold
        ) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(title, style = MaterialTheme.typography.labelLarge) }
                )
            }
        }

        if (isBacktesting || isCommandRunning) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ChampagneGold)
        }

        when (selectedTab) {
            0 -> StrategiesTab(
                strategies = strategies,
                agents = agents,
                isBacktesting = isBacktesting,
                isCommandRunning = isCommandRunning,
                lastReport = lastBacktestReport,
                onRunBacktest = onRunBacktest,
                onApproveLive = onApproveStrategyLive,
                onEvolveCollectiveIntelligence = onEvolveCollectiveIntelligence
            )
            1 -> HrTab(
                agents = agents,
                isTesting = isBacktesting,
                isCommandRunning = isCommandRunning,
                onSummonUncleSaab = onSummonUncleSaab,
                onRunStrictAudit = onRunStrictAudit,
                onRecruitCandidate = onRecruitCandidate,
                onApproveCandidate = onApproveCandidate
            )
            2 -> MemoryLearningTab(learningLogs = learningLogs)
        }
    }
}

@Composable
private fun StrategiesTab(
    strategies: List<TradingStrategy>,
    agents: List<AgentProfile>,
    isBacktesting: Boolean,
    isCommandRunning: Boolean,
    lastReport: BacktestReport?,
    onRunBacktest: (TradingStrategy, String) -> Unit,
    onApproveLive: (TradingStrategy, Boolean) -> Unit,
    onEvolveCollectiveIntelligence: () -> Unit
) {
    var testSymbol by remember { mutableStateOf("BTCUSDT") }
    val activeAgents = remember(agents) { agents.filter { it.approvedByOwner && !it.candidatePending } }
    val avgIq = remember(activeAgents) {
        if (activeAgents.isEmpty()) 100.0 else activeAgents.map { it.intelligenceScore }.average()
    }

    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ElectricCyan.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
                    .testTag("collective_iq_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🧠 محرك الذكاء المتزايد الجماعي", style = MaterialTheme.typography.titleMedium, color = ElectricCyan, fontWeight = FontWeight.Bold)
                        Text("متوسط IQ: ${"%.1f".format(avgIq)}", style = MaterialTheme.typography.labelLarge, color = ChampagneGold, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "يدمج الذاكرة التراكمية والأخطاء السابقة مع التفكير العميق والنقد الذاتي لرفع كفاءة جميع الموظفين (${activeAgents.size}) تلقائياً.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onEvolveCollectiveIntelligence,
                        enabled = !isCommandRunning && !isBacktesting,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = ObsidianBg),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("evolve_collective_iq_btn")
                    ) {
                        Text("تطوير ورفع ذكاء جميع الموظفين الآن (+IQ)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text("اختر الأصل للاختبار التاريخي و Walk-Forward (بيانات حقيقية):", style = MaterialTheme.typography.titleSmall, color = ElectricCyan)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("PAXGUSDT", "BTCUSDT", "ETHUSDT").forEach { sym ->
                    FilterChip(
                        selected = testSymbol == sym,
                        onClick = { testSymbol = sym },
                        label = { Text(sym, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            lastReport?.let { rep ->
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = ObsidianSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (rep.passedCriteria) EmeraldProfit else AmberWarn, RoundedCornerShape(12.dp))
                ) {
                    Text(
                        text = rep.summaryAr,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (rep.passedCriteria) EmeraldProfit else AmberWarn,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }

        items(strategies, key = { it.id }) { strat ->
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(strat.name, style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                        Text(strat.timeframes, style = MaterialTheme.typography.labelMedium, color = ElectricCyan)
                    }
                    Text("الأسواق: ${strat.suitableMarkets}", style = MaterialTheme.typography.bodySmall)
                    Text("شروط الدخول: ${strat.entryConditions}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("وقف الخسارة / الهدف: ${strat.stopLossRule} | ${strat.takeProfitRule}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("تعمل في: ${strat.worksInConditions}", style = MaterialTheme.typography.bodySmall, color = EmeraldProfit)
                    Text("تفشل في: ${strat.failsInConditions}", style = MaterialTheme.typography.bodySmall, color = CrimsonRisk)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Backtest: ${"%+.1f".format(strat.backtestReturnPct)}%", style = MaterialTheme.typography.labelMedium)
                        Text("Walk-Fwd: ${"%+.1f".format(strat.walkForwardReturnPct)}%", style = MaterialTheme.typography.labelMedium, color = ChampagneGold)
                        Text("WinRate: ${"%.0f".format(strat.outOfSampleWinRate)}%", style = MaterialTheme.typography.labelMedium, color = ElectricCyan)
                        Text("PF: ${"%.2f".format(strat.profitFactor)}", style = MaterialTheme.typography.labelMedium)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { onRunBacktest(strat, testSymbol) },
                            enabled = !isBacktesting,
                            colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceElevated, contentColor = ElectricCyan),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("run_backtest_${strat.id}")
                        ) {
                            Text("اختبار Walk-Forward ($testSymbol)", style = MaterialTheme.typography.labelMedium)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("اعتماد للحقيقي", style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = strat.approvedForLive,
                                onCheckedChange = { onApproveLive(strat, it) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HrTab(
    agents: List<AgentProfile>,
    isTesting: Boolean,
    isCommandRunning: Boolean,
    onSummonUncleSaab: () -> Unit,
    onRunStrictAudit: () -> Unit,
    onRecruitCandidate: (String, String, String, String, String) -> Unit,
    onApproveCandidate: (String, Boolean) -> Unit
) {
    var nameAr by remember { mutableStateOf("") }
    var roleAr by remember { mutableStateOf("") }
    var specialization by remember { mutableStateOf("") }
    var department by remember { mutableStateOf(Department.MARKET_INTEL.name) }
    var modelId by remember { mutableStateOf("gemini-3.8-flash") }

    val pendingCandidates = agents.filter { it.candidatePending }
    val uncleSaabAgent = agents.firstOrNull { it.id == "uncle_saab" }
    val enforcerAgent = agents.firstOrNull { it.id == "enforcer_01" }

    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Featured Specialist Recruitment Card: Uncle Saab 🛡️
        item {
            val saabAlreadyHired = uncleSaabAgent?.approvedByOwner == true && !uncleSaabAgent.candidatePending
            val saabPending = uncleSaabAgent?.candidatePending == true
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, ChampagneGold.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                    .testTag("uncle_saab_summon_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🛡️ المرشح الاستثنائي: العم صعب", style = MaterialTheme.typography.titleMedium, color = ChampagneGold, fontWeight = FontWeight.Bold)
                        Text(
                            text = when {
                                saabAlreadyHired -> "معيّن ونشط ✅"
                                saabPending -> "بطاقته جاهزة 👇"
                                else -> "IQ 152 • جاهز للاستدعاء"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (saabAlreadyHired) EmeraldProfit else ElectricCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        "الخبير المخضرم في كشف مصائد السيولة (Stop-Hunts) والاختراقات الكاذبة ورفع دقة اقتناص الصفقات الصعبة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!saabAlreadyHired && !saabPending) {
                        Button(
                            onClick = onSummonUncleSaab,
                            enabled = !isTesting,
                            colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianBg),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("summon_uncle_saab_btn")
                        ) {
                            Text("استدعاء العم صعب وإعداد بطاقة تقييمه عبر HR", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Strict Performance & Discipline Officer Card: Inspector Hazim ⚖️
        item {
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CrimsonRisk.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
                    .testTag("strict_enforcer_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚖️ مراقب الانضباط الصارم (المفتش حازم)", style = MaterialTheme.typography.titleMedium, color = CrimsonRisk, fontWeight = FontWeight.Bold)
                        Text("IQ ${"%.0f".format(enforcerAgent?.intelligenceScore ?: 138.0)}", style = MaterialTheme.typography.labelMedium, color = ChampagneGold)
                    }
                    Text(
                        "يدقق فوراً في أرباح وإنجازات وأخطاء جميع الموظفين، ويوجّه توبيخاً علنياً ومهام إجبارية للمتقاعسين مع خصم XP.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onRunStrictAudit,
                        enabled = !isCommandRunning && !isTesting,
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonRisk, contentColor = MaterialTheme.colorScheme.onPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_strict_audit_btn")
                    ) {
                        Text("تشغيل جولة التفتيش وتوبيخ المتقاعسين الآن", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (pendingCandidates.isNotEmpty()) {
            item {
                Text("بطاقات تقييم ما قبل التوظيف — بانتظار قرارك (${pendingCandidates.size})", style = MaterialTheme.typography.titleMedium, color = AmberWarn)
            }
            items(pendingCandidates, key = { it.id }) { cand ->
                Surface(
                    color = ObsidianSurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, AmberWarn.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                        .testTag("hr_dossier_${cand.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${cand.nameAr} — ${cand.roleAr}", style = MaterialTheme.typography.titleSmall, color = ChampagneGold, modifier = Modifier.weight(1f))
                            Text("IQ ${"%.0f".format(cand.intelligenceScore)}", style = MaterialTheme.typography.labelMedium, color = ElectricCyan, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            "الخبرات الفعلية: ${cand.candidateExpertise.ifBlank { cand.specialization }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (cand.candidateCompanyBenefit.isNotBlank()) {
                            Text(
                                "ماذا سيفيد الشركة: ${cand.candidateCompanyBenefit}",
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldProfit
                            )
                        }
                        Text(
                            "نتيجة اختبار المحاكاة: ${"%.1f".format(cand.backtestPassRate)}% | القسم: ${cand.department} | ${cand.modelId}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { onApproveCandidate(cand.id, true) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldProfit, contentColor = ObsidianBg),
                                modifier = Modifier.weight(1f).testTag("approve_candidate_${cand.id}")
                            ) {
                                Text("اعتماد التعيين الفوري", fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { onApproveCandidate(cand.id, false) },
                                colors = ButtonDefaults.buttonColors(containerColor = CrimsonRisk),
                                modifier = Modifier.testTag("reject_candidate_${cand.id}")
                            ) {
                                Text("رفض")
                            }
                        }
                    }
                }
            }
        }

        item {
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إدارة الموارد البشرية (توظيف واختبار وكلاء جدد)", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                    Text("قبل تعيين أي موظف جديد، تفحص HR خبراته وفائدته وتختبره عملياً وتعرض لك بطاقة التقييم للموافقة الفورية.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = nameAr,
                        onValueChange = { nameAr = it },
                        label = { Text("اسم الوكيل المتخصص") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = roleAr,
                        onValueChange = { roleAr = it },
                        label = { Text("المسمى الوظيفي") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = specialization,
                        onValueChange = { specialization = it },
                        label = { Text("التخصص الدقيق") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(Department.MARKET_INTEL, Department.LIVE_TRADING).forEach { dept ->
                            FilterChip(
                                selected = department == dept.name,
                                onClick = { department = dept.name },
                                label = { Text(dept.titleAr, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InitialCompanyRoster.supportedModels.forEach { m ->
                            FilterChip(
                                selected = modelId == m,
                                onClick = { modelId = m },
                                label = { Text(m.replace("gemini-", "g-"), style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (nameAr.isNotBlank() && roleAr.isNotBlank()) {
                                onRecruitCandidate(nameAr.trim(), roleAr.trim(), department, specialization.trim(), modelId)
                                nameAr = ""
                                roleAr = ""
                                specialization = ""
                            }
                        },
                        enabled = !isTesting && nameAr.isNotBlank() && roleAr.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianBg),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("hr_recruit_button")
                    ) {
                        Text("إنشاء بطاقة التقييم واختبار المرشح عبر HR", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun MemoryLearningTab(learningLogs: List<LearningLog>) {
    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("نظام التعلم التراكمي والذاكرة الجماعية (${learningLogs.size})", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
            Text("سجل موثق يراجعها كل وكيل تلقائياً قبل التحليل والصفقة لرفع IQ وتفادي تكرار الأخطاء.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (learningLogs.isEmpty()) {
            item {
                Text("لا توجد سجلات تعلم مسجلة بعد. تبدأ بالتسجيل تلقائياً مع تنفيذ ومراجعة الصفقات أو تطوير الذكاء الجماعي.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(learningLogs, key = { it.id }) { log ->
                val badgeColor = when (log.errorType) {
                    "ANALYSIS_ERROR", "EXECUTION_ERROR" -> CrimsonRisk
                    "NORMAL_STRATEGY_LOSS" -> AmberWarn
                    else -> EmeraldProfit
                }
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${log.agentName} • ${log.errorType}", style = MaterialTheme.typography.labelMedium, color = badgeColor)
                            Text("${"%+.2f".format(log.financialImpact)} $", style = MaterialTheme.typography.labelMedium, color = if (log.financialImpact >= 0) EmeraldProfit else CrimsonRisk)
                        }
                        Text("القرار: ${log.decisionSummary}", style = MaterialTheme.typography.titleSmall)
                        Text("النتيجة: ${log.actualOutcome}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("السبب / الدرس: ${log.rootCause}", style = MaterialTheme.typography.bodySmall)
                        Text("الإجراء التصحيحي: ${log.correctiveAction}", style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                        Text("تكرار الخطأ: ${if (log.recurred) "نعم" else "لا"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
