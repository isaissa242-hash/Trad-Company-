package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AgentProfile
import com.example.model.AgentRankSystem
import com.example.model.AgentStatus
import com.example.model.CompanyConfig
import com.example.model.CorporateMessage
import com.example.model.CorporateTask
import com.example.model.Department
import com.example.model.LearningLog
import com.example.model.MarketTicker
import com.example.model.TradingStrategy
import com.example.model.formatUsdCents
import com.example.ui.components.AgentStatusBadge
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldProfit
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.VioletAgent
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private enum class OfficeRoomId {
    CEO_SUITE,
    FUNDAMENTAL_ROOM,
    TECHNICAL_ROOM,
    LIQUIDITY_ROOM,
    WAR_ROOM,
    TRADING_FLOOR,
    RISK_VAULT,
    HR_LAB,
    MEMORY_ARCHIVE
}

private data class OfficeRoomSpec(
    val id: OfficeRoomId,
    val titleAr: String,
    val subtitleAr: String,
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val accent: Color,
    val deskPositions: List<Pair<Float, Float>>
) {
    val cx: Float get() = (x1 + x2) / 2f
    val cy: Float get() = (y1 + y2) / 2f
}

private data class PlacedAgent3D(
    val agent: AgentProfile,
    val roomId: OfficeRoomId,
    val wx: Float,
    val wy: Float,
    val accent: Color,
    val phaseOffset: Float
)

private val Office3DRooms = listOf(
    OfficeRoomSpec(
        id = OfficeRoomId.CEO_SUITE,
        titleAr = "مكتب الرئيس التنفيذي",
        subtitleAr = "القيادة العليا وتوزيع المهام",
        x1 = 0.4f, y1 = 0.4f, x2 = 3.8f, y2 = 3.8f,
        accent = ChampagneGold,
        deskPositions = listOf(2.1f to 2.0f)
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.FUNDAMENTAL_ROOM,
        titleAr = "التحليل الأساسي والأخبار",
        subtitleAr = "رصد الاقتصاد والبنوك المركزية",
        x1 = 0.4f, y1 = 4.4f, x2 = 3.8f, y2 = 8.0f,
        accent = VioletAgent,
        deskPositions = listOf(2.1f to 6.2f)
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.TECHNICAL_ROOM,
        titleAr = "التحليل الفني والمؤشرات",
        subtitleAr = "الشموع والاتجاهات المستقبلية",
        x1 = 4.4f, y1 = 0.4f, x2 = 8.0f, y2 = 3.8f,
        accent = ElectricCyan,
        deskPositions = listOf(5.5f to 1.8f, 6.9f to 2.5f)
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.LIQUIDITY_ROOM,
        titleAr = "السيولة وهيكل السوق",
        subtitleAr = "تدفق الأوامر والسيولة اللحظية",
        x1 = 0.4f, y1 = 8.6f, x2 = 3.8f, y2 = 12.2f,
        accent = ElectricCyan,
        deskPositions = listOf(2.1f to 10.4f)
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.WAR_ROOM,
        titleAr = "غرفة الاجتماعات (War Room)",
        subtitleAr = "مناقشات الإدارات وتكوين القرار",
        x1 = 4.4f, y1 = 4.4f, x2 = 7.8f, y2 = 7.8f,
        accent = ChampagneGold,
        deskPositions = emptyList()
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.HR_LAB,
        titleAr = "الموارد البشرية والانضباط ⚖️",
        subtitleAr = "تقييم المواهب والتفتيش الصارم",
        x1 = 8.6f, y1 = 0.4f, x2 = 12.2f, y2 = 3.8f,
        accent = AmberWarn,
        deskPositions = listOf(9.7f to 1.8f, 11.1f to 2.6f)
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.RISK_VAULT,
        titleAr = "إدارة المخاطر وخزنة 10%",
        subtitleAr = "درع الشركة وصلاحية النقض",
        x1 = 4.4f, y1 = 8.5f, x2 = 7.8f, y2 = 12.2f,
        accent = CrimsonRisk,
        deskPositions = listOf(6.1f to 10.3f)
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.MEMORY_ARCHIVE,
        titleAr = "غرفة الذاكرة والأرشيف",
        subtitleAr = "سجل التعلم والاستراتيجيات",
        x1 = 8.5f, y1 = 4.4f, x2 = 12.2f, y2 = 7.8f,
        accent = VioletAgent,
        deskPositions = emptyList()
    ),
    OfficeRoomSpec(
        id = OfficeRoomId.TRADING_FLOOR,
        titleAr = "قسم التداول والقناص 🎯",
        subtitleAr = "التنفيذ الفوري (A / B / C / القناص)",
        x1 = 8.5f, y1 = 8.5f, x2 = 12.6f, y2 = 12.6f,
        accent = EmeraldProfit,
        deskPositions = listOf(
            9.6f to 9.5f,
            11.4f to 9.6f,
            9.6f to 11.4f,
            11.5f to 11.4f,
            10.55f to 10.55f
        )
    )
)

private const val CAMPUS_CENTER = 6.5f
private const val ISO_X_FACTOR = 0.84f
private const val ISO_Y_FACTOR = 0.50f

private fun worldToScreen(
    wx: Float,
    wy: Float,
    wz: Float,
    canvasSize: IntSize,
    unit: Float,
    pan: Offset,
    zoom: Float
): Offset {
    val midIsoY = (CAMPUS_CENTER + CAMPUS_CENTER) * unit * ISO_Y_FACTOR
    val baseX = (wx - wy) * unit * ISO_X_FACTOR
    val baseY = (wx + wy) * unit * ISO_Y_FACTOR - wz * unit
    val sx = (canvasSize.width / 2f) + pan.x + baseX * zoom
    val sy = (canvasSize.height / 2f) + pan.y + (baseY - midIsoY) * zoom
    return Offset(sx, sy)
}

private fun screenToFloorWorld(
    screen: Offset,
    canvasSize: IntSize,
    unit: Float,
    pan: Offset,
    zoom: Float
): Pair<Float, Float> {
    val midIsoY = (CAMPUS_CENTER + CAMPUS_CENTER) * unit * ISO_Y_FACTOR
    val dx = (screen.x - canvasSize.width / 2f - pan.x) / zoom
    val dy = (screen.y - canvasSize.height / 2f - pan.y) / zoom + midIsoY
    val a = dx / (unit * ISO_X_FACTOR) // wx - wy
    val b = dy / (unit * ISO_Y_FACTOR) // wx + wy
    return (a + b) / 2f to (b - a) / 2f
}

private fun assignAgentsTo3DRooms(agents: List<AgentProfile>): List<PlacedAgent3D> {
    val activeAgents = agents.filter { it.approvedByOwner && !it.candidatePending }
    val placed = mutableListOf<PlacedAgent3D>()
    val roomCounts = mutableMapOf<OfficeRoomId, Int>()

    fun roomForAgent(a: AgentProfile): Pair<OfficeRoomId, Color> = when {
        a.id == "ceo_01" || a.department == Department.EXECUTIVE.name -> OfficeRoomId.CEO_SUITE to ChampagneGold
        a.id == "ana_fund_01" -> OfficeRoomId.FUNDAMENTAL_ROOM to VioletAgent
        a.id == "ana_liq_01" -> OfficeRoomId.LIQUIDITY_ROOM to ElectricCyan
        a.id == "mid_01" || a.id == "ana_tech_01" || a.department == Department.MARKET_INTEL.name ->
            OfficeRoomId.TECHNICAL_ROOM to ElectricCyan
        a.id == "cro_01" || a.department == Department.RISK.name -> OfficeRoomId.RISK_VAULT to CrimsonRisk
        a.id == "enforcer_01" -> OfficeRoomId.HR_LAB to CrimsonRisk
        a.id == "hr_01" || a.department == Department.HR.name -> OfficeRoomId.HR_LAB to AmberWarn
        a.id == "sniper_01" || a.id == "uncle_saab" -> OfficeRoomId.TRADING_FLOOR to ChampagneGold
        else -> OfficeRoomId.TRADING_FLOOR to EmeraldProfit
    }

    activeAgents.forEachIndexed { idx, agent ->
        val (roomId, accent) = roomForAgent(agent)
        val room = Office3DRooms.first { it.id == roomId }
        val slotIdx = roomCounts.getOrDefault(roomId, 0)
        roomCounts[roomId] = slotIdx + 1

        val baseSlot = when (agent.id) {
            "mid_01" -> room.deskPositions.getOrNull(0)
            "ana_tech_01" -> room.deskPositions.getOrNull(1)
            "hr_01" -> room.deskPositions.getOrNull(0)
            "enforcer_01" -> room.deskPositions.getOrNull(1)
            "hot_01" -> room.deskPositions.getOrNull(0)
            "trd_short_01" -> room.deskPositions.getOrNull(1)
            "trd_mid_01" -> room.deskPositions.getOrNull(2)
            "trd_multi_01" -> room.deskPositions.getOrNull(3)
            "sniper_01" -> room.deskPositions.getOrNull(4)
            else -> room.deskPositions.getOrNull(slotIdx % room.deskPositions.size.coerceAtLeast(1))
        } ?: (room.cx to room.cy)

        val overflowOffset = if (slotIdx >= room.deskPositions.size && room.deskPositions.isNotEmpty()) {
            ((slotIdx % 2) - 0.5f) * 0.6f to 0.55f
        } else {
            0f to 0f
        }

        placed.add(
            PlacedAgent3D(
                agent = agent,
                roomId = roomId,
                wx = baseSlot.first + overflowOffset.first,
                wy = baseSlot.second + overflowOffset.second,
                accent = accent,
                phaseOffset = (idx * 0.85f)
            )
        )
    }
    return placed
}

private fun statusAccentColor(statusRaw: String, blocked: Boolean): Color {
    if (blocked) return CrimsonRisk
    return when (AgentStatus.fromRaw(statusRaw)) {
        AgentStatus.WORKING, AgentStatus.ANALYZING -> ElectricCyan
        AgentStatus.RESEARCHING -> VioletAgent
        AgentStatus.TRADING, AgentStatus.COMPLETED -> EmeraldProfit
        AgentStatus.REVIEWING -> AmberWarn
        AgentStatus.WAITING -> TextMuted
        AgentStatus.ERROR -> CrimsonRisk
    }
}

private fun shortenTaskBubble(task: String, statusRaw: String, blocked: Boolean): String {
    if (blocked) return "موقوف بأمر المالك"
    val clean = task.trim()
    if (clean.isBlank()) return statusRaw
    return if (clean.length > 26) clean.take(24) + ".." else clean
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualOffice3DPanel(
    config: CompanyConfig?,
    agents: List<AgentProfile>,
    tasks: List<CorporateTask>,
    messages: List<CorporateMessage>,
    learningLogs: List<LearningLog>,
    strategies: List<TradingStrategy>,
    tickers: List<MarketTicker>,
    isCommandRunning: Boolean,
    onSelectAgent: (AgentProfile) -> Unit,
    onSendDirective: (String) -> Unit
) {
    val textMeasurer = rememberTextMeasurer(cacheSize = 64)
    val density = LocalDensity.current.density

    var zoom by remember { mutableFloatStateOf(1.02f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var canvasSize by remember { mutableStateOf(IntSize(1080, 1400)) }
    var selectedRoom by remember { mutableStateOf<OfficeRoomSpec?>(null) }

    val sortedRooms = remember { Office3DRooms.sortedBy { it.cx + it.cy } }
    val placedAgents = remember(agents) { assignAgentsTo3DRooms(agents) }
    val activeTasksCount = remember(tasks, isCommandRunning) {
        val activeInDb = tasks.count { it.status == "ACTIVE" || it.status == "IN_PROGRESS" }
        if (isCommandRunning) activeInDb.coerceAtLeast(1) else activeInDb
    }
    val workingAgentsCount = remember(agents) {
        agents.count {
            !it.blockedByOwner &&
                (it.status == AgentStatus.WORKING.label ||
                    it.status == AgentStatus.ANALYZING.label ||
                    it.status == AgentStatus.TRADING.label ||
                    it.status == AgentStatus.RESEARCHING.label)
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "office3d")
    val animPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "animPhase"
    )
    val pulseFlow by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "pulseFlow"
    )

    val worldUnit = remember(canvasSize) {
        val w = canvasSize.width.coerceAtLeast(360).toFloat()
        val h = canvasSize.height.coerceAtLeast(360).toFloat()
        minOf(w / 21.5f, h / 14.2f)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF131B2E), ObsidianBg)
                )
            )
            .testTag("virtual_office_3d_container")
    ) {
        // Interactive 3D Isometric Campus Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { canvasSize = it }
                .pointerInput(worldUnit) {
                    detectTransformGestures { _, panChange, zoomChange, _ ->
                        val nextZoom = (zoom * zoomChange).coerceIn(0.68f, 2.55f)
                        val maxPanX = (canvasSize.width * 0.72f) * nextZoom
                        val maxPanY = (canvasSize.height * 0.65f) * nextZoom
                        zoom = nextZoom
                        pan = Offset(
                            x = (pan.x + panChange.x).coerceIn(-maxPanX, maxPanX),
                            y = (pan.y + panChange.y).coerceIn(-maxPanY, maxPanY)
                        )
                    }
                }
                .pointerInput(placedAgents, worldUnit) {
                    detectTapGestures { tapOffset ->
                        val hitRadius = 32f * density * zoom.coerceIn(0.85f, 1.45f)
                        val hitAgent = placedAgents
                            .mapNotNull { placed ->
                                val moveX = if (placed.agent.status != AgentStatus.WAITING.label && !placed.agent.blockedByOwner) {
                                    sin(animPhase + placed.phaseOffset) * 0.14f
                                } else 0f
                                val pos = worldToScreen(
                                    placed.wx + moveX,
                                    placed.wy,
                                    0.45f,
                                    canvasSize,
                                    worldUnit,
                                    pan,
                                    zoom
                                )
                                val bubbleCenter = Offset(pos.x, pos.y - 34f * zoom)
                                val distBody = (tapOffset - pos).getDistance()
                                val distBubble = (tapOffset - bubbleCenter).getDistance()
                                val minDist = minOf(distBody, distBubble)
                                if (minDist <= hitRadius) placed to minDist else null
                            }
                            .minByOrNull { it.second }
                            ?.first

                        if (hitAgent != null) {
                            onSelectAgent(hitAgent.agent)
                            return@detectTapGestures
                        }

                        val (wx, wy) = screenToFloorWorld(tapOffset, canvasSize, worldUnit, pan, zoom)
                        val tappedRoom = Office3DRooms.firstOrNull { room ->
                            wx in (room.x1 - 0.15f)..(room.x2 + 0.15f) &&
                                wy in (room.y1 - 0.15f)..(room.y2 + 0.15f)
                        }
                        if (tappedRoom != null) {
                            selectedRoom = tappedRoom
                        }
                    }
                }
        ) {
            fun proj(wx: Float, wy: Float, wz: Float = 0f): Offset =
                worldToScreen(wx, wy, wz, canvasSize, worldUnit, pan, zoom)

            // 1. Ambient Campus Base Platform & Corridors
            drawIsoPrism(
                x1 = 0f, y1 = 0f, x2 = 13f, y2 = 13f,
                zBottom = -0.35f, zTop = 0f,
                topColor = Color(0xFF0E1523),
                leftColor = Color(0xFF0A0F1A),
                rightColor = Color(0xFF070B14),
                proj = ::proj
            )

            // Subtle isometric architectural floor grid lines
            for (g in 1..12) {
                val gf = g.toFloat()
                drawLine(
                    color = Color(0xFF1D2942).copy(alpha = 0.45f),
                    start = proj(gf, 0f, 0.005f),
                    end = proj(gf, 13f, 0.005f),
                    strokeWidth = 1f
                )
                drawLine(
                    color = Color(0xFF1D2942).copy(alpha = 0.45f),
                    start = proj(0f, gf, 0.005f),
                    end = proj(13f, gf, 0.005f),
                    strokeWidth = 1f
                )
            }

            // Glowing Corridor Network connecting CEO -> Depts -> Trading Floor
            val corridorSegments = listOf(
                Pair(2.1f to 3.8f, 2.1f to 4.4f),
                Pair(3.8f to 2.1f, 4.4f to 2.1f),
                Pair(4.1f to 2.1f, 4.1f to 10.4f),
                Pair(2.1f to 4.1f, 10.4f to 4.1f),
                Pair(8.15f to 2.1f, 8.15f to 10.6f),
                Pair(2.1f to 8.15f, 10.6f to 8.15f)
            )
            corridorSegments.forEach { (start, end) ->
                val p1 = proj(start.first, start.second, 0.02f)
                val p2 = proj(end.first, end.second, 0.02f)
                drawLine(
                    color = ElectricCyan.copy(alpha = 0.25f),
                    start = p1,
                    end = p2,
                    strokeWidth = 5f * zoom,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = ChampagneGold.copy(alpha = 0.5f),
                    start = p1,
                    end = p2,
                    strokeWidth = 1.6f * zoom,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f * zoom, 10f * zoom), phase = -pulseFlow * 40f * zoom)
                )
                // Animated signal packet dot moving along corridor
                val px = start.first + (end.first - start.first) * pulseFlow
                val py = start.second + (end.second - start.second) * pulseFlow
                drawCircle(
                    color = if (isCommandRunning) EmeraldProfit else ElectricCyan,
                    radius = 3.2f * zoom,
                    center = proj(px, py, 0.04f)
                )
            }

            // 2. Render 9 Rooms back-to-front using Painter's algorithm (cx + cy ascending)
            sortedRooms.forEach { room ->
                val roomAgents = placedAgents.filter { it.roomId == room.id }
                val isSelected = selectedRoom?.id == room.id

                // Floor Slab + Elevation
                drawIsoPrism(
                    x1 = room.x1, y1 = room.y1, x2 = room.x2, y2 = room.y2,
                    zBottom = 0f, zTop = 0.10f,
                    topColor = Color(0xFF141E33),
                    leftColor = room.accent.copy(alpha = 0.28f),
                    rightColor = room.accent.copy(alpha = 0.16f),
                    proj = ::proj
                )

                // Floor accent glow perimeter
                val fl1 = proj(room.x1, room.y1, 0.105f)
                val fl2 = proj(room.x2, room.y1, 0.105f)
                val fl3 = proj(room.x2, room.y2, 0.105f)
                val fl4 = proj(room.x1, room.y2, 0.105f)
                val floorPath = Path().apply {
                    moveTo(fl1.x, fl1.y)
                    lineTo(fl2.x, fl2.y)
                    lineTo(fl3.x, fl3.y)
                    lineTo(fl4.x, fl4.y)
                    close()
                }
                drawPath(
                    path = floorPath,
                    color = if (isSelected) ChampagneGold else room.accent.copy(alpha = 0.65f),
                    style = Stroke(width = (if (isSelected) 2.8f else 1.5f) * zoom)
                )

                // Back-left architectural wall (x = x1) & Back-right wall (y = y1)
                val wallH = if (room.id == OfficeRoomId.CEO_SUITE) 0.92f else 0.72f
                drawIsoQuad(
                    p1 = proj(room.x1, room.y1, 0.10f),
                    p2 = proj(room.x1, room.y2, 0.10f),
                    p3 = proj(room.x1, room.y2, wallH),
                    p4 = proj(room.x1, room.y1, wallH),
                    color = Color(0xFF1B2741),
                    borderColor = room.accent.copy(alpha = 0.4f),
                    strokeW = 1.2f * zoom
                )
                drawIsoQuad(
                    p1 = proj(room.x1, room.y1, 0.10f),
                    p2 = proj(room.x2, room.y1, 0.10f),
                    p3 = proj(room.x2, room.y1, wallH),
                    p4 = proj(room.x1, room.y1, wallH),
                    color = Color(0xFF21304E),
                    borderColor = room.accent.copy(alpha = 0.55f),
                    strokeW = 1.2f * zoom
                )

                // Architectural 3D Furniture & Room Props
                when (room.id) {
                    OfficeRoomId.CEO_SUITE -> {
                        // Large executive L-desk + panoramic Command Monitor + Gold Plaque
                        drawDeskWithMonitors(2.0f, 1.9f, ChampagneGold, tripleScreen = true, zoom = zoom, proj = ::proj)
                        drawIsoPrism(1.2f, 0.8f, 3.0f, 1.0f, 0.40f, 0.82f, Color(0xFF0B1C2C), Color(0xFF081420), Color(0xFF112A42), ::proj)
                    }
                    OfficeRoomId.WAR_ROOM -> {
                        // Central Holographic Conference Table + Floating Ring
                        drawIsoPrism(5.2f, 5.2f, 7.0f, 7.0f, 0.12f, 0.42f, Color(0xFF1E2D4A), Color(0xFF141F36), Color(0xFF0F1729), ::proj)
                        val holoCenter = proj(room.cx, room.cy, 0.65f + sin(animPhase) * 0.05f)
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(ElectricCyan.copy(alpha = 0.55f), Color.Transparent),
                                center = holoCenter,
                                radius = 20f * zoom
                            ),
                            center = holoCenter,
                            radius = 20f * zoom
                        )
                        drawCircle(
                            color = ChampagneGold.copy(alpha = 0.75f),
                            radius = 9f * zoom,
                            center = holoCenter,
                            style = Stroke(width = 1.6f * zoom)
                        )
                    }
                    OfficeRoomId.RISK_VAULT -> {
                        // Armored Safety Vault 10% Cube + CRO Desk
                        drawDeskWithMonitors(6.1f, 10.2f, CrimsonRisk, tripleScreen = true, zoom = zoom, proj = ::proj)
                        drawIsoPrism(4.8f, 9.1f, 5.7f, 10.0f, 0.12f, 0.78f, ChampagneGold.copy(alpha = 0.85f), Color(0xFF8C6E2B), Color(0xFF5D481A), ::proj)
                    }
                    OfficeRoomId.MEMORY_ARCHIVE -> {
                        // 3D Archive Bookshelves / Glowing Knowledge Server Racks
                        for (rack in 0..2) {
                            val rx = 9.0f + rack * 1.0f
                            drawIsoPrism(rx, 4.9f, rx + 0.55f, 5.8f, 0.12f, 0.86f, VioletAgent.copy(alpha = 0.75f), Color(0xFF281F47), Color(0xFF1B1433), ::proj)
                            val ledPos = proj(rx + 0.25f, 5.8f, 0.62f)
                            drawCircle(color = if ((rack + (pulseFlow * 3).toInt()) % 2 == 0) ElectricCyan else EmeraldProfit, radius = 2.2f * zoom, center = ledPos)
                        }
                        drawIsoPrism(9.4f, 6.4f, 11.2f, 7.1f, 0.12f, 0.42f, Color(0xFF232F4D), Color(0xFF172038), Color(0xFF101729), ::proj)
                    }
                    OfficeRoomId.TRADING_FLOOR -> {
                        room.deskPositions.forEachIndexed { idx, (dx, dy) ->
                            val isSniperDesk = idx == 4
                            drawDeskWithMonitors(
                                wx = dx,
                                wy = dy,
                                screenColor = if (isSniperDesk) ChampagneGold else EmeraldProfit,
                                tripleScreen = isSniperDesk || idx == 0,
                                zoom = zoom,
                                proj = ::proj
                            )
                        }
                    }
                    else -> {
                        room.deskPositions.forEach { (dx, dy) ->
                            drawDeskWithMonitors(dx, dy, room.accent, tripleScreen = false, zoom = zoom, proj = ::proj)
                        }
                    }
                }

                // Draw Agents inside this room back-to-front
                roomAgents.sortedBy { it.wx + it.wy }.forEach { placed ->
                    val activeMotion = placed.agent.status != AgentStatus.WAITING.label && !placed.agent.blockedByOwner
                    val walkOffset = if (activeMotion) sin(animPhase + placed.phaseOffset) * 0.14f else 0f
                    val bobZ = if (activeMotion) kotlin.math.abs(sin(animPhase * 2f + placed.phaseOffset)) * 0.07f else 0f

                    drawAgent3DRobot(
                        placed = placed,
                        wx = placed.wx + walkOffset,
                        wy = placed.wy,
                        bobZ = bobZ,
                        zoom = zoom,
                        proj = ::proj
                    )
                }

                // Low architectural front cutaway rim for clean 3D look
                drawLine(color = room.accent.copy(alpha = 0.55f), start = proj(room.x2, room.y1, 0.11f), end = proj(room.x2, room.y2, 0.11f), strokeWidth = 2f * zoom)
                drawLine(color = room.accent.copy(alpha = 0.55f), start = proj(room.x1, room.y2, 0.11f), end = proj(room.x2, room.y2, 0.11f), strokeWidth = 2f * zoom)
            }

            // 3. Foreground HUD Overlay Pass (Room Tags & Floating Speech Bubbles — never clipped by walls!)
            sortedRooms.forEach { room ->
                drawRoomPlaque(
                    room = room,
                    pos = proj(room.x1 + 0.18f, room.y2 - 0.18f, 0.14f),
                    textMeasurer = textMeasurer,
                    zoom = zoom
                )
            }

            placedAgents.forEach { placed ->
                val activeMotion = placed.agent.status != AgentStatus.WAITING.label && !placed.agent.blockedByOwner
                val walkOffset = if (activeMotion) sin(animPhase + placed.phaseOffset) * 0.14f else 0f
                val headTop = proj(placed.wx + walkOffset, placed.wy, 0.92f)
                val rankInfo = AgentRankSystem.evaluateAgent(placed.agent)
                val bubbleText = shortenTaskBubble(placed.agent.currentTask, placed.agent.status, placed.agent.blockedByOwner)
                val isReprimanded = placed.agent.currentTask.startsWith("⚠️")
                val statusColor = if (isReprimanded) CrimsonRisk else statusAccentColor(placed.agent.status, placed.agent.blockedByOwner)

                drawFloatingSpeechBubble(
                    anchor = headTop,
                    nameWithBadge = "${placed.agent.nameAr.substringBefore(" (")} ${rankInfo.badge} 🧠${placed.agent.intelligenceScore.toInt()}",
                    taskSnippet = bubbleText,
                    accent = when {
                        isReprimanded -> CrimsonRisk
                        placed.agent.id == "sniper_01" || placed.agent.id == "uncle_saab" -> ChampagneGold
                        else -> statusColor
                    },
                    textMeasurer = textMeasurer,
                    zoom = zoom
                )
            }
        }

        // Top Live Broadcast & Active Tasks Telemetry Overlay
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                color = ObsidianSurface.copy(alpha = 0.92f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .border(1.dp, ObsidianBorder, RoundedCornerShape(12.dp))
                    .testTag("office_3d_live_hud")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val liveDotAlpha = (0.45f + 0.55f * kotlin.math.abs(sin(animPhase))).coerceIn(0.4f, 1f)
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(CrimsonRisk.copy(alpha = liveDotAlpha))
                    )
                    Text(
                        text = "LIVE 3D",
                        style = MaterialTheme.typography.labelMedium,
                        color = CrimsonRisk,
                        fontWeight = FontWeight.Bold
                    )
                    Text("•", color = ObsidianBorder)
                    Text(
                        text = "مهام نشطة: $activeTasksCount",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricCyan,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.testTag("office_3d_active_tasks_count")
                    )
                    Text("•", color = ObsidianBorder)
                    Text(
                        text = "نشط: $workingAgentsCount/${agents.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldProfit
                    )
                }
            }

            if ((config?.safetyVaultBalance ?: 0.0) > 0.0) {
                Surface(
                    color = ObsidianSurface.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.border(1.dp, ChampagneGold.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                ) {
                    Text(
                        text = "🛡️ ${formatUsdCents(config?.safetyVaultBalance ?: 0.0)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = ChampagneGold,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp)
                    )
                }
            }
        }

        // Bottom Hint & Camera Zoom/Pan Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Surface(
                color = ObsidianSurface.copy(alpha = 0.88f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
            ) {
                Text(
                    text = "اسحب للتحريك • قرّب بإصبعين • اضغط أي غرفة أو موظف",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }

            Surface(
                color = ObsidianSurface.copy(alpha = 0.92f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.border(1.dp, ChampagneGold.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { zoom = (zoom + 0.25f).coerceAtMost(2.55f) },
                        modifier = Modifier.size(48.dp).testTag("office_3d_zoom_in")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "تكبير المكتب ثلاثي الأبعاد", tint = ChampagneGold)
                    }
                    IconButton(
                        onClick = { zoom = (zoom - 0.25f).coerceAtLeast(0.68f) },
                        modifier = Modifier.size(48.dp).testTag("office_3d_zoom_out")
                    ) {
                        Icon(Icons.Filled.Remove, contentDescription = "تصغير المكتب ثلاثي الأبعاد", tint = ElectricCyan)
                    }
                    IconButton(
                        onClick = {
                            zoom = 1.02f
                            pan = Offset.Zero
                        },
                        modifier = Modifier.size(48.dp).testTag("office_3d_reset_camera")
                    ) {
                        Icon(Icons.Filled.CenterFocusStrong, contentDescription = "إعادة ضبط الكاميرا", tint = EmeraldProfit)
                    }
                }
            }
        }
    }

    // Room Interactive Inspector Modal Sheet
    selectedRoom?.let { room ->
        val roomAgents = placedAgents.filter { it.roomId == room.id }.map { it.agent }
        val warRoomMsgs = messages.filter { it.channel != "CEO_OWNER" }
        var roomDirectiveText by remember(room.id) { mutableStateOf("") }

        ModalBottomSheet(
            onDismissRequest = { selectedRoom = null },
            containerColor = ObsidianSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(room.titleAr, style = MaterialTheme.typography.titleLarge, color = room.accent, fontWeight = FontWeight.Bold)
                        Text(room.subtitleAr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { selectedRoom = null }, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "إغلاق نافذة الغرفة")
                    }
                }

                HorizontalDivider(color = ObsidianBorder)

                when (room.id) {
                    OfficeRoomId.WAR_ROOM -> {
                        Text("نقاشات غرفة الحرب (${warRoomMsgs.size})", style = MaterialTheme.typography.titleSmall, color = ChampagneGold)
                        if (warRoomMsgs.isEmpty()) {
                            Text("لا توجد نقاشات مسجلة بعد. أرسل توجيهاً للغرفة لبدء اجتماع فوري بين الإدارات.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            LazyColumn(
                                modifier = Modifier.height(220.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(warRoomMsgs.reversed().take(12), key = { it.id }) { msg ->
                                    Surface(
                                        color = ObsidianSurfaceElevated,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text("${msg.senderName} • ${msg.channel}", style = MaterialTheme.typography.labelMedium, color = ElectricCyan)
                                            Text(msg.content, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    OfficeRoomId.MEMORY_ARCHIVE -> {
                        Text("سجل الذاكرة والأرشيف (${learningLogs.size} درس • ${strategies.size} استراتيجية)", style = MaterialTheme.typography.titleSmall, color = VioletAgent)
                        if (learningLogs.isEmpty()) {
                            Text("الأرشيف جاهز لتوثيق دروس كل صفقة وتحديث خبرة الوكلاء تلقائياً.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            LazyColumn(
                                modifier = Modifier.height(200.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(learningLogs.take(10), key = { it.id }) { log ->
                                    Surface(
                                        color = ObsidianSurfaceElevated,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth().border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text("[${log.errorType}] ${log.agentName}", style = MaterialTheme.typography.labelMedium, color = ChampagneGold)
                                            Text("${log.decisionSummary} ← ${log.correctiveAction}", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    OfficeRoomId.RISK_VAULT -> {
                        Surface(
                            color = ObsidianSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().border(1.dp, ChampagneGold.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("🛡️ خزنة الأمان (10% Shield): ${formatUsdCents(config?.safetyVaultBalance ?: 0.0)}", style = MaterialTheme.typography.titleSmall, color = ChampagneGold, fontWeight = FontWeight.Bold)
                                Text("أقصى مخاطرة/صفقة: ${config?.maxRiskPerTradePct ?: 1.5}% • Kill Switch: ${if (config?.killSwitchActive == true) "مفعل" else "آمن"}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    else -> Unit
                }

                if (roomAgents.isNotEmpty()) {
                    Text("الموظفون داخل الغرفة (اضغط لفتح الملف):", style = MaterialTheme.typography.titleSmall, color = ElectricCyan)
                    roomAgents.forEach { agent ->
                        val rankInfo = AgentRankSystem.evaluateAgent(agent)
                        Surface(
                            color = ObsidianSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, room.accent.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                                .clickable {
                                    selectedRoom = null
                                    onSelectAgent(agent)
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.Person, contentDescription = agent.nameAr, tint = room.accent, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("${agent.nameAr} ${rankInfo.badge}", style = MaterialTheme.typography.titleSmall, color = ChampagneGold)
                                        Text(agent.currentTask, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                AgentStatusBadge(agent.status)
                            }
                        }
                    }
                }

                val leadTicker = tickers.firstOrNull()
                if (leadTicker != null) {
                    Text(
                        text = "إشارة السوق الحية: ${leadTicker.symbol} @ ${formatUsdCents(leadTicker.lastPrice)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldProfit
                    )
                }

                // Direct Directive Dispatcher for this Room
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = roomDirectiveText,
                        onValueChange = { roomDirectiveText = it },
                        label = { Text("إرسال توجيه إلى ${room.titleAr}") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = room.accent, unfocusedBorderColor = ObsidianBorder),
                        modifier = Modifier.weight(1f).testTag("room_3d_directive_input")
                    )
                    Button(
                        onClick = {
                            if (roomDirectiveText.isNotBlank()) {
                                val msg = "توجيه مباشر من المالك إلى قسم (${room.titleAr}): ${roomDirectiveText.trim()}"
                                roomDirectiveText = ""
                                selectedRoom = null
                                onSendDirective(msg)
                            }
                        },
                        enabled = roomDirectiveText.isNotBlank() && !isCommandRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = room.accent, contentColor = ObsidianBg),
                        modifier = Modifier.height(52.dp).testTag("room_3d_send_directive_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال التوجيه")
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
        }
    }
}

private fun DrawScope.drawIsoQuad(
    p1: Offset,
    p2: Offset,
    p3: Offset,
    p4: Offset,
    color: Color,
    borderColor: Color? = null,
    strokeW: Float = 1f
) {
    val path = Path().apply {
        moveTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        lineTo(p3.x, p3.y)
        lineTo(p4.x, p4.y)
        close()
    }
    drawPath(path = path, color = color)
    if (borderColor != null) {
        drawPath(path = path, color = borderColor, style = Stroke(width = strokeW))
    }
}

private fun DrawScope.drawIsoPrism(
    x1: Float,
    y1: Float,
    x2: Float,
    y2: Float,
    zBottom: Float,
    zTop: Float,
    topColor: Color,
    leftColor: Color,
    rightColor: Color,
    proj: (Float, Float, Float) -> Offset
) {
    val t1 = proj(x1, y1, zTop)
    val t2 = proj(x2, y1, zTop)
    val t3 = proj(x2, y2, zTop)
    val t4 = proj(x1, y2, zTop)

    val b2 = proj(x2, y1, zBottom)
    val b3 = proj(x2, y2, zBottom)
    val b4 = proj(x1, y2, zBottom)

    // Left visible face (y = y2)
    drawIsoQuad(t4, t3, b3, b4, leftColor)
    // Right visible face (x = x2)
    drawIsoQuad(t2, t3, b3, b2, rightColor)
    // Top face
    drawIsoQuad(t1, t2, t3, t4, topColor)
}

private fun DrawScope.drawDeskWithMonitors(
    wx: Float,
    wy: Float,
    screenColor: Color,
    tripleScreen: Boolean,
    zoom: Float,
    proj: (Float, Float, Float) -> Offset
) {
    // Desk body
    drawIsoPrism(
        x1 = wx - 0.42f, y1 = wy - 0.30f, x2 = wx + 0.42f, y2 = wy + 0.30f,
        zBottom = 0.11f, zTop = 0.34f,
        topColor = Color(0xFF283552),
        leftColor = Color(0xFF1A2338),
        rightColor = Color(0xFF12192A),
        proj = proj
    )
    // Glowing monitor(s) on top
    val scrW = if (tripleScreen) 0.56f else 0.36f
    drawIsoPrism(
        x1 = wx - scrW / 2f, y1 = wy - 0.24f, x2 = wx + scrW / 2f, y2 = wy - 0.14f,
        zBottom = 0.35f, zTop = 0.62f,
        topColor = screenColor.copy(alpha = 0.9f),
        leftColor = screenColor.copy(alpha = 0.72f),
        rightColor = screenColor.copy(alpha = 0.48f),
        proj = proj
    )
    // Mini chart sparkline on monitor front face
    val mLeft = proj(wx - scrW * 0.35f, wy - 0.14f, 0.48f)
    val mMid = proj(wx, wy - 0.14f, 0.56f)
    val mRight = proj(wx + scrW * 0.35f, wy - 0.14f, 0.45f)
    drawLine(Color.White.copy(alpha = 0.85f), mLeft, mMid, strokeWidth = 1.4f * zoom)
    drawLine(Color.White.copy(alpha = 0.85f), mMid, mRight, strokeWidth = 1.4f * zoom)
}

private fun DrawScope.drawAgent3DRobot(
    placed: PlacedAgent3D,
    wx: Float,
    wy: Float,
    bobZ: Float,
    zoom: Float,
    proj: (Float, Float, Float) -> Offset
) {
    val isReprimanded = placed.agent.currentTask.startsWith("⚠️")
    val statusColor = if (isReprimanded) CrimsonRisk else statusAccentColor(placed.agent.status, placed.agent.blockedByOwner)
    val floorPos = proj(wx, wy, 0.11f)
    val isSniper = placed.agent.id == "sniper_01" || placed.agent.id == "uncle_saab"
    val bodyAccent = if (isSniper) ChampagneGold else placed.accent

    // Drop shadow & pulsing status ring on floor
    drawCircle(
        color = Color.Black.copy(alpha = 0.45f),
        radius = 11f * zoom,
        center = floorPos
    )
    drawCircle(
        color = statusColor.copy(alpha = 0.78f),
        radius = 12.5f * zoom,
        center = floorPos,
        style = Stroke(width = 2f * zoom)
    )

    // 3D Torso (extruded box floating smoothly with bobZ)
    drawIsoPrism(
        x1 = wx - 0.18f, y1 = wy - 0.18f, x2 = wx + 0.18f, y2 = wy + 0.18f,
        zBottom = 0.18f + bobZ, zTop = 0.56f + bobZ,
        topColor = bodyAccent.copy(alpha = 0.92f),
        leftColor = bodyAccent.copy(alpha = 0.68f),
        rightColor = bodyAccent.copy(alpha = 0.46f),
        proj = proj
    )

    // Head Sphere & Glowing AI Visor
    val headCenter = proj(wx, wy, 0.73f + bobZ)
    drawCircle(
        color = Color(0xFFE7ECF8),
        radius = 8.2f * zoom,
        center = headCenter
    )
    drawCircle(
        color = bodyAccent,
        radius = 8.2f * zoom,
        center = headCenter,
        style = Stroke(width = 1.8f * zoom)
    )
    drawRoundRect(
        color = statusColor,
        topLeft = Offset(headCenter.x - 5.2f * zoom, headCenter.y - 2.3f * zoom),
        size = Size(10.4f * zoom, 4.2f * zoom),
        cornerRadius = CornerRadius(2f * zoom, 2f * zoom)
    )
}

private fun DrawScope.drawRoomPlaque(
    room: OfficeRoomSpec,
    pos: Offset,
    textMeasurer: TextMeasurer,
    zoom: Float
) {
    val labelLayout = textMeasurer.measure(
        text = room.titleAr,
        style = TextStyle(
            color = room.accent,
            fontSize = (9.5f * zoom.coerceIn(0.8f, 1.25f)).sp,
            fontWeight = FontWeight.Bold
        ),
        maxLines = 1
    )
    val padH = 6f * zoom
    val padV = 2.5f * zoom
    val w = labelLayout.size.width + padH * 2f
    val h = labelLayout.size.height + padV * 2f
    val topLeft = Offset(pos.x - w / 2f, pos.y - h / 2f)

    drawRoundRect(
        color = ObsidianBg.copy(alpha = 0.86f),
        topLeft = topLeft,
        size = Size(w, h),
        cornerRadius = CornerRadius(6f * zoom, 6f * zoom)
    )
    drawRoundRect(
        color = room.accent.copy(alpha = 0.65f),
        topLeft = topLeft,
        size = Size(w, h),
        cornerRadius = CornerRadius(6f * zoom, 6f * zoom),
        style = Stroke(width = 1f)
    )
    drawText(
        textLayoutResult = labelLayout,
        topLeft = Offset(topLeft.x + padH, topLeft.y + padV)
    )
}

private fun DrawScope.drawFloatingSpeechBubble(
    anchor: Offset,
    nameWithBadge: String,
    taskSnippet: String,
    accent: Color,
    textMeasurer: TextMeasurer,
    zoom: Float
) {
    val nameStyle = TextStyle(
        color = ChampagneGold,
        fontSize = (8.8f * zoom.coerceIn(0.82f, 1.25f)).sp,
        fontWeight = FontWeight.Bold
    )
    val taskStyle = TextStyle(
        color = Color(0xFFE6EDF7),
        fontSize = (7.8f * zoom.coerceIn(0.80f, 1.20f)).sp,
        fontWeight = FontWeight.Normal
    )
    val nameLayout = textMeasurer.measure(text = nameWithBadge, style = nameStyle, maxLines = 1)
    val taskLayout = textMeasurer.measure(text = taskSnippet, style = taskStyle, maxLines = 1)

    val padX = 7f * zoom
    val padY = 4f * zoom
    val contentW = maxOf(nameLayout.size.width, taskLayout.size.width).toFloat()
    val boxW = contentW + padX * 2f
    val boxH = nameLayout.size.height + taskLayout.size.height + padY * 2f + 2f * zoom

    val boxRect = Rect(
        left = anchor.x - boxW / 2f,
        top = anchor.y - boxH - 8f * zoom,
        right = anchor.x + boxW / 2f,
        bottom = anchor.y - 8f * zoom
    )

    drawRoundRect(
        color = ObsidianSurface.copy(alpha = 0.93f),
        topLeft = boxRect.topLeft,
        size = boxRect.size,
        cornerRadius = CornerRadius(8f * zoom, 8f * zoom)
    )
    drawRoundRect(
        color = accent.copy(alpha = 0.78f),
        topLeft = boxRect.topLeft,
        size = boxRect.size,
        cornerRadius = CornerRadius(8f * zoom, 8f * zoom),
        style = Stroke(width = 1.2f)
    )

    // Speech pointer triangle
    val pointer = Path().apply {
        moveTo(anchor.x - 4f * zoom, boxRect.bottom)
        lineTo(anchor.x, anchor.y - 2f * zoom)
        lineTo(anchor.x + 4f * zoom, boxRect.bottom)
        close()
    }
    drawPath(pointer, color = accent.copy(alpha = 0.85f))

    drawText(
        textLayoutResult = nameLayout,
        topLeft = Offset(boxRect.left + (boxW - nameLayout.size.width) / 2f, boxRect.top + padY)
    )
    drawText(
        textLayoutResult = taskLayout,
        topLeft = Offset(
            boxRect.left + (boxW - taskLayout.size.width) / 2f,
            boxRect.top + padY + nameLayout.size.height + 2f * zoom
        )
    )
}
