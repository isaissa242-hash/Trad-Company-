package com.example.data.risk

import com.example.model.AgentProfile
import com.example.model.CompanyConfig
import com.example.model.RiskEvaluation
import com.example.model.TradeRecord
import com.example.model.TradingStrategy
import java.util.UUID
import kotlin.math.abs

/**
 * Technologically independent Chief Risk Officer (CRO) enforcement gate.
 * No AI agent (including CEO or Head of Trading) can bypass these checks.
 */
object RiskEngine {

    private const val MAX_MARKET_DATA_AGE_MS = 180_000L // 3 minutes max staleness

    fun evaluateTradeProposal(
        config: CompanyConfig,
        strategy: TradingStrategy?,
        trader: AgentProfile?,
        openTrades: List<TradeRecord>,
        closedTradesInMode: List<TradeRecord>,
        symbol: String,
        side: String,
        entryPrice: Double,
        stopLoss: Double,
        takeProfit: Double,
        marketDataTimestampMillis: Long
    ): RiskEvaluation {
        val reasons = mutableListOf<String>()

        // 1. Master Kill Switch & Trading Pause
        if (config.killSwitchActive) {
            reasons.add("مفتاح الطوارئ (Kill Switch) مُفعّل: جميع عمليات التداول موقوفة.")
        }
        if (config.tradingPaused) {
            reasons.add("التداول متوقف مؤقتاً بأمر المالك.")
        }

        // 2. Live Mode Authorization Gate
        val isLive = config.tradingMode == "LIVE"
        if (isLive && !config.liveTradingApprovedByOwner) {
            reasons.add("الحساب الحقيقي غير مصرّح له من المالك.")
        }

        // 3. Data Freshness Check
        val dataAgeMs = System.currentTimeMillis() - marketDataTimestampMillis
        if (marketDataTimestampMillis <= 0L || dataAgeMs > MAX_MARKET_DATA_AGE_MS) {
            reasons.add("بيانات السوق قديمة أو منقطعة (${dataAgeMs / 1000}ث) — تم منع التنفيذ.")
        }

        // 4. Trader & Strategy Eligibility
        if (trader == null || trader.blockedByOwner || !trader.approvedByOwner || trader.candidatePending) {
            reasons.add("موظف التداول غير معتمد أو محظور من المالك.")
        }
        if (strategy == null) {
            reasons.add("لا توجد استراتيجية صالحة مرفقة بخطة التداول.")
        } else if (isLive && !strategy.approvedForLive) {
            reasons.add("الاستراتيجية (${strategy.name}) لم تحصل على اعتماد التداول الحقيقي بعد.")
        }

        // 5. Mandatory Stop-Loss & Risk-Reward Sanity
        if (entryPrice <= 0.0 || stopLoss <= 0.0 || takeProfit <= 0.0) {
            reasons.add("يجب تحديد أسعار حقيقية للدخول ووقف الخسارة وجني الأرباح.")
        } else {
            val validStopDirection = if (side == "BUY") stopLoss < entryPrice && takeProfit > entryPrice
            else stopLoss > entryPrice && takeProfit < entryPrice
            if (!validStopDirection) {
                reasons.add("اتجاه وقف الخسارة أو الهدف غير منطقي بالنسبة لاتجاه الصفقة ($side).")
            }
        }

        // 6. Open Positions & Duplicate Symbol Exposure
        val activeTradesInMode = openTrades.filter { it.mode == config.tradingMode && it.status == "OPEN" }
        if (activeTradesInMode.size >= config.maxOpenPositions) {
            reasons.add("تم بلوغ الحد الأقصى للصفقات المفتوحة (${config.maxOpenPositions}).")
        }
        if (activeTradesInMode.any { it.symbol == symbol }) {
            reasons.add("يوجد صفقة مفتوحة بالفعل على $symbol — منع تكديس الارتباط والمخاطرة.")
        }

        // 7. Daily & Cumulative Drawdown Circuit Breakers (Operational capital ONLY; Safety Vault is untouched)
        val capitalBase = if (isLive) config.allocatedCapital else config.paperBalance
        if (capitalBase <= 0.0) {
            reasons.add("رأس المال التشغيلي نفد (${"%.2f".format(capitalBase)}$) — خزنة الأمان محمية من الإفلاس ولا تُمس.")
        }
        val totalClosedPnl = closedTradesInMode.sumOf { it.realizedPnl }
        val drawdownPct = if (capitalBase > 0 && totalClosedPnl < 0) {
            (abs(totalClosedPnl) / capitalBase) * 100.0
        } else 0.0

        if (drawdownPct >= config.dailyLossLimitPct) {
            reasons.add("تجاوز حد الخسارة اليومي (${"%.2f".format(drawdownPct)}% >= ${config.dailyLossLimitPct}%).")
        }
        if (drawdownPct >= config.weeklyLossLimitPct) {
            reasons.add("تجاوز حد الخسارة الأسبوعي (${"%.2f".format(drawdownPct)}% >= ${config.weeklyLossLimitPct}%).")
        }

        // 8. Position Sizing bounded by Max Risk Per Trade & Max Leverage
        val riskUsd = (capitalBase * (config.maxRiskPerTradePct / 100.0)).coerceAtLeast(10.0)
        val stopDist = abs(entryPrice - stopLoss).coerceAtLeast(entryPrice * 0.002)
        val rawQty = if (entryPrice > 0) riskUsd / stopDist else 0.0
        val maxNotionalAllowed = capitalBase * config.maxLeverage * 0.25 // cap single position to 25% of levered capacity
        val cappedQty = if (entryPrice > 0) minOf(rawQty, maxNotionalAllowed / entryPrice) else 0.0

        if (cappedQty <= 0.0) {
            reasons.add("حجم الصفقة المحسوب يساوي صفراً.")
        }

        val approved = reasons.isEmpty()
        val approvalId = if (approved) "CRO-OK-${UUID.randomUUID().toString().take(8).uppercase()}"
        else "CRO-VETO-${UUID.randomUUID().toString().take(8).uppercase()}"

        return RiskEvaluation(
            approved = approved,
            approvalId = approvalId,
            reasonsAr = if (approved) listOf("تمت الموافقة المستقلة من قسم المخاطر ضمن حد ${config.maxRiskPerTradePct}%.") else reasons,
            computedPositionQty = cappedQty,
            computedRiskUsd = riskUsd
        )
    }
}
