package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val QuantCorpDarkColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = ObsidianBg,
    primaryContainer = ObsidianSurfaceElevated,
    onPrimaryContainer = ChampagneGold,
    secondary = ElectricCyan,
    onSecondary = ObsidianBg,
    secondaryContainer = Color(0xFF0D2E3B),
    onSecondaryContainer = ElectricCyan,
    tertiary = EmeraldProfit,
    onTertiary = ObsidianBg,
    tertiaryContainer = EmeraldBg,
    onTertiaryContainer = EmeraldProfit,
    error = CrimsonRisk,
    onError = Color.White,
    errorContainer = CrimsonBg,
    onErrorContainer = CrimsonRisk,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceElevated,
    surfaceContainerHigh = ObsidianSurfaceHigh,
    outline = ObsidianBorder,
    outlineVariant = Color(0xFF1B2940)
)

private val QuantCorpLightColorScheme = lightColorScheme(
    primary = GoldDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFAF0D7),
    onPrimaryContainer = Color(0xFF3E2D05),
    secondary = CyanDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD9F3F8),
    onSecondaryContainer = Color(0xFF06323F),
    tertiary = EmeraldProfit,
    onTertiary = Color.White,
    error = CrimsonRisk,
    onError = Color.White,
    background = IvoryBg,
    onBackground = SlateInk,
    surface = IvorySurface,
    onSurface = SlateInk,
    surfaceVariant = IvorySurfaceElevated,
    onSurfaceVariant = SlateSecondary,
    outline = Color(0xFFCBD5E1)
)

val QuantCorpShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun QuantCorpTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) QuantCorpDarkColorScheme else QuantCorpLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = QuantCorpShapes,
        content = content
    )
}
