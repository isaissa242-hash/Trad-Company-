package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AgentProfile
import com.example.model.AgentRankSystem
import com.example.model.CompanyConfig
import com.example.model.CorporateMessage
import com.example.model.CorporateTask
import com.example.model.Department
import com.example.model.InitialCompanyRoster
import com.example.model.LearningLog
import com.example.model.MarketTicker
import com.example.model.PnLSummary
import com.example.model.TradingStrategy
import com.example.model.formatUsdCents
import com.example.ui.components.AgentStatusBadge
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldProfit
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.VioletAgent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualOfficeScreen(
    config: CompanyConfig? = null,
    agents: List<AgentProfile>,
    messages: List<CorporateMessage>,
    tasks: List<CorporateTask>,
    learningLogs: List<LearningLog>,
    strategies: List<TradingStrategy> = emptyList(),
    tickers: List<MarketTicker>,
    pnlSummary: PnLSummary,
    isCommandRunning: Boolean = false,
    onToggleBlockAgent: (String, Boolean) -> Unit,
    onChangeAgentModel: (String, String) -> Unit,
    onSendDirective: (String) -> Unit = {},
    onEvolveCollectiveIntelligence: () -> Unit = {},
    onRunStrictAudit: () -> Unit = {}
) {
    var selectedOfficeTab by remember { mutableStateOf(0) } // 0 = Hierarchy Rooms, 1 = 3D Interactive Office
    var selectedAgent by remember { mutableStateOf<AgentProfile?>(null) }
    var showWarRoomSheet by remember { mutableStateOf(false) }

    val warRoomMessages = remember(messages) {
        messages.filter { it.channel != "CEO_OWNER" }
    }

    val activeAgents = remember(agents) {
        agents.filter { it.approvedByOwner && !it.candidatePending }
    }
    val ceo = activeAgents.firstOrNull { it.id == "ceo_01" }
    val mid = activeAgents.firstOrNull { it.id == "mid_01" }
    val analysts = activeAgents.filter { it.department == Department.MARKET_INTEL.name && it.id != "mid_01" }
    val hot = activeAgents.firstOrNull { it.id == "hot_01" }
    val traders = activeAgents.filter { it.department == Department.LIVE_TRADING.name && it.id != "hot_01" }
    val cro = activeAgents.firstOrNull { it.id == "cro_01" }
    val hrStaff = activeAgents.filter { it.department == Department.HR.name }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "pulseAlpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        // Independent Virtual Office View Switcher: Hierarchy Rooms vs Interactive 3D Diorama
        Surface(
            color = ObsidianSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, ObsidianBorder, RoundedCornerShape(0.dp))
        ) {
            SingleChoiceSegmentedButtonRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                SegmentedButton(
                    selected = selectedOfficeTab == 0,
                    onClick = { selectedOfficeTab = 0 },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                    icon = { Icon(Icons.Filled.Apartment, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("office_tab_hierarchy")
                ) {
                    Text("المكتب التنظيمي", style = MaterialTheme.typography.labelLarge)
                }
                SegmentedButton(
                    selected = selectedOfficeTab == 1,
                    onClick = { selectedOfficeTab = 1 },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                    icon = { Icon(Icons.Filled.ViewInAr, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("office_tab_3d")
                ) {
                    Text("المكتب 3D", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        if (selectedOfficeTab == 1) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                VirtualOffice3DPanel(
                    config = config,
                    agents = agents,
                    tasks = tasks,
                    messages = messages,
                    learningLogs = learningLogs,
                    strategies = strategies,
                    tickers = tickers,
                    isCommandRunning = isCommandRunning,
                    onSelectAgent = { selectedAgent = it },
                    onSendDirective = onSendDirective
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(ObsidianBg),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "المقر الافتراضي لشركة QuantCorp AI",
                            style = MaterialTheme.typography.headlineSmall,
                            color = ChampagneGold
                        )
                        Text(
                            text = "الشارات والترقيات تُمنح حصراً مقابل الأرباح الحقيقية المحققة للشركة (كل سنت ربح موثق في Firestore).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { showWarRoomSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceElevated, contentColor = ElectricCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("war_room_button")
                    ) {
                        Icon(Icons.Filled.Forum, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("غرفة الاجتماعات (${warRoomMessages.size})", style = MaterialTheme.typography.labelMedium)
                    }
                }

                // Gamified Rank Ladder + Collective IQ & Strict Discipline Summary Card
                val highestAgent = remember(activeAgents) {
                    activeAgents.maxByOrNull { AgentRankSystem.evaluateAgent(it).currentXp }
                }
                val totalXp = remember(activeAgents) { activeAgents.sumOf { it.rankXp.coerceAtLeast(0L) } }
                val avgIq = remember(activeAgents) {
                    if (activeAgents.isEmpty()) 100.0 else activeAgents.map { it.intelligenceScore }.average()
                }
                val totalReprimands = remember(activeAgents) { activeAgents.sumOf { it.reprimandsCount } }
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ChampagneGold.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .testTag("rank_ladder_summary_card")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ترقية بالربح فقط: ⭐ ← 🦅 ← ⚔️ ← 🐋",
                                style = MaterialTheme.typography.labelMedium,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$totalXp XP • 🧠 ${"%.0f".format(avgIq)} IQ",
                                style = MaterialTheme.typography.labelMedium,
                                color = ElectricCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (highestAgent != null) {
                            val topRank = AgentRankSystem.evaluateAgent(highestAgent)
                            Text(
                                text = "الأعلى رتبة: ${highestAgent.nameAr} ${topRank.badge} | توبيخات: $totalReprimands",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onEvolveCollectiveIntelligence,
                                enabled = !isCommandRunning,
                                colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceElevated, contentColor = ElectricCyan),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.weight(1f).testTag("office_evolve_iq_btn")
                            ) {
                                Text("🧠 تطوير الذكاء", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = onRunStrictAudit,
                                enabled = !isCommandRunning,
                                colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceElevated, contentColor = CrimsonRisk),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.weight(1f).testTag("office_strict_audit_btn")
                            ) {
                                Text("⚖️ التفتيش الصارم", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Room 1: Executive Suite (CEO) + Room 8 & 9 & 10 Telemetry Strip
        item {
            OfficeRoomContainer(
                roomTitle = "1. مكتب الرئيس التنفيذي (Executive Suite)",
                accent = ChampagneGold,
                pulseAlpha = pulseAlpha
            ) {
                ceo?.let {
                    AgentCharacterCard(agent = it, accent = ChampagneGold, onClick = { selectedAgent = it })
                }
            }
        }

        // Architectural Hierarchy Connectors
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val midX = size.width / 2f
                    val leftX = size.width * 0.25f
                    val rightX = size.width * 0.75f
                    val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                    drawLine(ChampagneGold.copy(alpha = 0.6f), Offset(midX, 0f), Offset(midX, size.height / 2f), 3f)
                    drawLine(ElectricCyan.copy(alpha = 0.6f), Offset(leftX, size.height / 2f), Offset(rightX, size.height / 2f), 3f, pathEffect = dash)
                    drawLine(ElectricCyan.copy(alpha = 0.6f), Offset(leftX, size.height / 2f), Offset(leftX, size.height), 3f)
                    drawLine(EmeraldProfit.copy(alpha = 0.6f), Offset(rightX, size.height / 2f), Offset(rightX, size.height), 3f)
                }
            }
        }

        // Room 2 & 3: Market Intelligence Director + Forward Analysts Room
        item {
            OfficeRoomContainer(
                roomTitle = "2 & 3. إدارة التحليل المستقبلي الحي (15m • 1H • 4H)",
                accent = ElectricCyan,
                pulseAlpha = pulseAlpha
            ) {
                mid?.let {
                    AgentCharacterCard(agent = it, accent = ElectricCyan, onClick = { selectedAgent = it })
                    Spacer(modifier = Modifier.height(10.dp))
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    analysts.forEach { analyst ->
                        AgentCharacterCard(agent = analyst, accent = VioletAgent, onClick = { selectedAgent = analyst })
                    }
                }
            }
        }

        // Room 4 & 5: Head of Trading + Traders & القناص 🎯 Room
        item {
            OfficeRoomContainer(
                roomTitle = "4 & 5. إدارة التداول المباشر وغرفة المنفذين والقناص 🎯",
                accent = EmeraldProfit,
                pulseAlpha = pulseAlpha
            ) {
                hot?.let {
                    AgentCharacterCard(agent = it, accent = EmeraldProfit, onClick = { selectedAgent = it })
                    Spacer(modifier = Modifier.height(10.dp))
                }
                val sniperAgent = traders.firstOrNull { it.id == "sniper_01" }
                val regularTraders = traders.filter { it.id != "sniper_01" }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    sniperAgent?.let { sniper ->
                        AgentCharacterCard(agent = sniper, accent = ChampagneGold, onClick = { selectedAgent = sniper })
                    }
                    regularTraders.forEach { trader ->
                        AgentCharacterCard(agent = trader, accent = EmeraldProfit, onClick = { selectedAgent = trader })
                    }
                }
            }
        }

        // Room 6 & 7: Independent Risk Vault (CRO) & AI HR Talent Lab (responsive layout)
        item {
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                if (maxWidth >= 600.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            OfficeRoomContainer(
                                roomTitle = "6. مكتب المخاطر المستقل",
                                accent = CrimsonRisk,
                                pulseAlpha = pulseAlpha
                            ) {
                                cro?.let {
                                    AgentCharacterCard(agent = it, accent = CrimsonRisk, onClick = { selectedAgent = it })
                                }
                            }
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            OfficeRoomContainer(
                                roomTitle = "7. الموارد البشرية والانضباط ⚖️",
                                accent = AmberWarn,
                                pulseAlpha = pulseAlpha
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    hrStaff.forEach { member ->
                                        val tint = if (member.id == "enforcer_01") CrimsonRisk else AmberWarn
                                        AgentCharacterCard(agent = member, accent = tint, onClick = { selectedAgent = member })
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OfficeRoomContainer(
                            roomTitle = "6. مكتب المخاطر المستقل (CRO)",
                            accent = CrimsonRisk,
                            pulseAlpha = pulseAlpha
                        ) {
                            cro?.let {
                                AgentCharacterCard(agent = it, accent = CrimsonRisk, onClick = { selectedAgent = it })
                            }
                        }
                        OfficeRoomContainer(
                            roomTitle = "7. الموارد البشرية والانضباط الصارم (HR & ⚖️)",
                            accent = AmberWarn,
                            pulseAlpha = pulseAlpha
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                hrStaff.forEach { member ->
                                    val tint = if (member.id == "enforcer_01") CrimsonRisk else AmberWarn
                                    AgentCharacterCard(agent = member, accent = tint, onClick = { selectedAgent = member })
                                }
                            }
                        }
                    }
                }
            }
        }

        // Room 8, 9 & 10: War Room, Market Surveillance Hub & Profit Treasury
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(14.dp))
                        .clickable { showWarRoomSheet = true }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Filled.Groups, contentDescription = null, tint = ElectricCyan)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("8. غرفة الاجتماعات", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                        Text("${warRoomMessages.size} نقاش فعلي مرتبط بمهام", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Filled.MonitorHeart, contentDescription = null, tint = ChampagneGold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("9. مركز مراقبة الأسواق", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                        val lead = tickers.firstOrNull()
                        Text(
                            text = if (lead != null) "${lead.symbol}: $${"%.2f".format(lead.lastPrice)}" else "جاري الجلب...",
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldProfit
                        )
                    }
                }
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = EmeraldProfit)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("10. الأرباح وخزنة الأمان", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                        val liveTotalProfit = pnlSummary.netRealizedProfit + pnlSummary.unrealizedPnl
                        Text(
                            text = formatUsdCents(liveTotalProfit, signed = true),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (liveTotalProfit >= 0.0) EmeraldProfit else CrimsonRisk,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "خزنة 10%: ${formatUsdCents(config?.safetyVaultBalance ?: 0.0)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ChampagneGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        }
        }
    }

    // Agent Dossier Modal Sheet (shared cleanly between Organizational View and 3D Isometric Office)
    selectedAgent?.let { agent ->
        val freshAgent = agents.firstOrNull { it.id == agent.id } ?: agent
        val agentLogs = learningLogs.filter { it.agentId == freshAgent.id }
        val agentTasks = tasks.filter { it.assignedAgentId == freshAgent.id }
        val managerName = agents.firstOrNull { it.id == freshAgent.managerId }?.nameAr ?: freshAgent.managerId

        val rankInfo = AgentRankSystem.evaluateAgent(freshAgent)
        var directiveInput by remember(freshAgent.id) { mutableStateOf("") }

        ModalBottomSheet(
            onDismissRequest = { selectedAgent = null },
            containerColor = ObsidianSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${freshAgent.nameAr} ${rankInfo.badge}",
                            style = MaterialTheme.typography.headlineSmall,
                            color = ChampagneGold
                        )
                        Text("${freshAgent.roleAr} • المدير المباشر: $managerName", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    AgentStatusBadge(freshAgent.status)
                }

                // Rank & Promotion Progress Card
                Surface(
                    color = ObsidianSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ChampagneGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "الرتبة ${rankInfo.level}/10: ${rankInfo.badge} ${rankInfo.titleAr}",
                                style = MaterialTheme.typography.titleSmall,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${rankInfo.currentXp} XP",
                                style = MaterialTheme.typography.labelMedium,
                                color = ElectricCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        LinearProgressIndicator(
                            progress = { rankInfo.progressToNext },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = ChampagneGold,
                            trackColor = ObsidianBorder,
                            strokeCap = StrokeCap.Round
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (rankInfo.isMaxRank) {
                                    "وصل الموظف لأعلى رتبة: حوت السوق 🐋"
                                } else {
                                    "متبقي ${rankInfo.xpRemainingForNext} XP (بالربح فقط) ← ${rankInfo.nextBadge}"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "أرباح محققة: ${formatUsdCents(freshAgent.totalProfitGeneratedUsd, signed = true)} (${freshAgent.successfulWinsCount})",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldProfit
                            )
                        }
                    }
                }

                Text("المهمة الحالية: ${freshAgent.currentTask}", style = MaterialTheme.typography.bodyMedium, color = ElectricCyan)
                Text("الاختصاص: ${freshAgent.specialization}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (freshAgent.lastReprimandReason.isNotBlank() || freshAgent.reprimandsCount > 0L) {
                    Surface(
                        color = CrimsonRisk.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, CrimsonRisk.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                    ) {
                        Text(
                            text = "⚖️ سجل التفتيش الصارم (${freshAgent.reprimandsCount} توبيخ): ${freshAgent.lastReprimandReason.ifBlank { "مطلوب تسريع الأرباح" }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonRisk,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    DossierMetric("ذكاء IQ", "${"%.0f".format(freshAgent.intelligenceScore)}")
                    DossierMetric("الأداء", "${"%.1f".format(freshAgent.performanceScore)}%")
                    DossierMetric("النجاح", "${"%.1f".format(freshAgent.successRate)}%")
                    DossierMetric("المهام", "${freshAgent.tasksCompleted}")
                }

                HorizontalDivider(color = ObsidianBorder)

                Text("إرسال توجيه مباشر لهذا الموظف:", style = MaterialTheme.typography.titleSmall, color = ElectricCyan)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = directiveInput,
                        onValueChange = { directiveInput = it },
                        label = { Text("اكتب أمراً أو توجيهاً للموظف...") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ChampagneGold, unfocusedBorderColor = ObsidianBorder),
                        modifier = Modifier.weight(1f).testTag("agent_dossier_directive_input")
                    )
                    Button(
                        onClick = {
                            if (directiveInput.isNotBlank()) {
                                val cmd = "توجيه مباشر من المالك إلى (${freshAgent.nameAr}): ${directiveInput.trim()}"
                                directiveInput = ""
                                selectedAgent = null
                                onSendDirective(cmd)
                            }
                        },
                        enabled = directiveInput.isNotBlank() && !isCommandRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = ObsidianBg),
                        modifier = Modifier.height(52.dp).testTag("agent_dossier_send_directive_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال التوجيه")
                    }
                }

                HorizontalDivider(color = ObsidianBorder)

                Text("نموذج الذكاء الاصطناعي للموظف:", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InitialCompanyRoster.supportedModels.forEach { m ->
                        FilterChip(
                            selected = freshAgent.modelId == m,
                            onClick = { onChangeAgentModel(freshAgent.id, m) },
                            label = { Text(m, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Security, contentDescription = null, tint = CrimsonRisk, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إيقاف / منع الموظف بأمر المالك", style = MaterialTheme.typography.bodyMedium)
                    }
                    Switch(
                        checked = freshAgent.blockedByOwner,
                        onCheckedChange = { onToggleBlockAgent(freshAgent.id, it) }
                    )
                }

                if (agentLogs.isNotEmpty() || agentTasks.isNotEmpty()) {
                    HorizontalDivider(color = ObsidianBorder)
                    if (agentTasks.isNotEmpty()) {
                        Text("سجل مهام الموظف (${agentTasks.size}):", style = MaterialTheme.typography.titleSmall, color = ElectricCyan)
                        agentTasks.take(3).forEach { t ->
                            Text(
                                text = "• [${t.targetAsset}] ${t.outcomeSummary.ifBlank { t.ownerOrder }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    if (agentLogs.isNotEmpty()) {
                        Text("سجل التعلم والخبرة (${agentLogs.size}):", style = MaterialTheme.typography.titleSmall, color = ChampagneGold)
                        agentLogs.take(3).forEach { log ->
                            Text(
                                text = "• [${log.errorType}] ${log.decisionSummary} -> ${log.correctiveAction}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // War Room Debates Sheet
    if (showWarRoomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showWarRoomSheet = false },
            containerColor = ObsidianSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text("غرفة الاجتماعات والنقاشات الفعلية (War Room)", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                Text("كل محادثة هنا مرتبطة بمهمة سوق حقيقية وقرار تنفيذي موثق.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(10.dp))
                if (warRoomMessages.isEmpty()) {
                    Text(
                        text = "لا توجد اجتماعات مسجلة بعد. أرسل أمراً للرئيس التنفيذي لتفعيل النقاش بين الإدارات.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(420.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(warRoomMessages.reversed(), key = { it.id }) { msg ->
                            Surface(
                                color = ObsidianSurfaceElevated,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, ObsidianBorder, RoundedCornerShape(12.dp))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(msg.senderName, style = MaterialTheme.typography.titleSmall, color = ElectricCyan)
                                        Text(msg.channel, style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(msg.content, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                                    if (msg.decisionReached.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("القرار: ${msg.decisionReached}", style = MaterialTheme.typography.labelSmall, color = EmeraldProfit)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun OfficeRoomContainer(
    roomTitle: String,
    accent: Color,
    pulseAlpha: Float,
    content: @Composable () -> Unit
) {
    Surface(
        color = ObsidianSurface,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = pulseAlpha))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = roomTitle,
                    style = MaterialTheme.typography.titleSmall,
                    color = accent,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun AgentCharacterCard(
    agent: AgentProfile,
    accent: Color,
    onClick: () -> Unit
) {
    val rankInfo = remember(agent.rankXp, agent.rankLevel) {
        AgentRankSystem.evaluateAgent(agent)
    }
    val animatedProgress by animateFloatAsState(
        targetValue = rankInfo.progressToNext,
        animationSpec = tween(durationMillis = 500),
        label = "rankProgress_${agent.id}"
    )
    val isSniper = agent.id == "sniper_01"
    val isUncleSaab = agent.id == "uncle_saab"
    val isEnforcer = agent.id == "enforcer_01"
    val hasReprimandAlert = agent.currentTask.startsWith("⚠️") || agent.reprimandsCount > 0L
    Surface(
        color = ObsidianSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(
                if (isSniper || isUncleSaab || hasReprimandAlert) 1.5.dp else 1.dp,
                when {
                    agent.blockedByOwner -> CrimsonRisk
                    hasReprimandAlert -> CrimsonRisk.copy(alpha = 0.85f)
                    isSniper || isUncleSaab -> ChampagneGold.copy(alpha = 0.85f)
                    isEnforcer -> AmberWarn.copy(alpha = 0.8f)
                    else -> ObsidianBorder
                },
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .testTag("agent_card_${agent.id}")
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.18f))
                    .border(1.dp, accent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Filled.Person, contentDescription = agent.nameAr, tint = accent, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = agent.nameAr,
                        style = MaterialTheme.typography.titleSmall,
                        color = if (isSniper || isUncleSaab) ChampagneGold else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (isSniper || isUncleSaab) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Surface(
                        color = ElectricCyan.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.border(0.5.dp, ElectricCyan.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = "🧠${agent.intelligenceScore.toInt()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                    if (agent.reprimandsCount > 0L) {
                        Surface(
                            color = CrimsonRisk.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(0.5.dp, CrimsonRisk.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        ) {
                            Text(
                                text = "⚠️${agent.reprimandsCount}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrimsonRisk,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                    if (isSniper) {
                        Surface(
                            color = EmeraldProfit.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(0.5.dp, EmeraldProfit.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        ) {
                            Text(
                                text = "100%",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldProfit,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Surface(
                        color = ChampagneGold.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .border(0.5.dp, ChampagneGold.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                            .testTag("agent_rank_badge_${agent.id}")
                    ) {
                        Text(
                            text = rankInfo.badge,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
                Text(
                    text = agent.currentTask,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (agent.currentTask.startsWith("⚠️")) CrimsonRisk else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .weight(1f)
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .testTag("agent_rank_progress_${agent.id}"),
                        color = ChampagneGold,
                        trackColor = ObsidianBorder,
                        strokeCap = StrokeCap.Round
                    )
                    Text(
                        text = if (rankInfo.isMaxRank) {
                            "MAX 🐋"
                        } else if (agent.totalProfitGeneratedUsd > 0.0) {
                            "L${rankInfo.level} • ${formatUsdCents(agent.totalProfitGeneratedUsd, signed = true)}"
                        } else {
                            "L${rankInfo.level} • ${rankInfo.currentXp}XP"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (agent.totalProfitGeneratedUsd > 0.0) EmeraldProfit else ChampagneGold,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.End) {
                AgentStatusBadge(agent.status)
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = agent.modelId.replace("gemini-", "g-"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DossierMetric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, color = ChampagneGold, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
