package com.example.data.market

import com.example.model.CandleBar
import com.example.model.MarketTicker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Fetches real, live market tickers, OHLCV candlesticks, and orderbook depth
 * from public Binance Spot APIs (with CoinGecko fallback for spot price if geo-blocked).
 * Never fabricates or invents prices.
 */
class MarketDataService {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    data class AssetSpec(
        val symbol: String,
        val displayNameAr: String,
        val coingeckoId: String
    )

    val trackedAssets = listOf(
        AssetSpec("PAXGUSDT", "الذهب الفوري (PAXG/XAU)", "pax-gold"),
        AssetSpec("BTCUSDT", "بيتكوين (BTC/USDT)", "bitcoin"),
        AssetSpec("ETHUSDT", "إيثريوم (ETH/USDT)", "ethereum"),
        AssetSpec("SOLUSDT", "سولانا (SOL/USDT)", "solana"),
        AssetSpec("EURUSDT", "اليورو/دولار (EUR/USDT)", "euro-coin")
    )

    suspend fun fetchLiveTickers(): Result<List<MarketTicker>> = withContext(Dispatchers.IO) {
        val symbolsJson = JSONArray(trackedAssets.map { it.symbol }).toString()
        val endpoints = listOf(
            "https://api.binance.com/api/v3/ticker/24hr?symbols=$symbolsJson" to "Binance Spot Public API",
            "https://data-api.binance.vision/api/v3/ticker/24hr?symbols=$symbolsJson" to "Binance Vision Public Data"
        )
        for ((url, sourceLabel) in endpoints) {
            try {
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val list = parseBinanceTickers(resp.body?.string().orEmpty(), sourceLabel)
                        if (list.isNotEmpty()) return@withContext Result.success(list)
                    }
                }
            } catch (_: Exception) {
                // try next live provider mirror
            }
        }
        fetchCoinGeckoFallback()
    }

    private fun parseBinanceTickers(body: String, sourceLabel: String): List<MarketTicker> {
        if (body.isBlank()) return emptyList()
        val arr = JSONArray(body)
        val now = System.currentTimeMillis()
        val list = mutableListOf<MarketTicker>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val sym = obj.getString("symbol")
            val spec = trackedAssets.firstOrNull { it.symbol == sym }
            val last = obj.getString("lastPrice").toDoubleOrNull() ?: 0.0
            if (last <= 0.0) continue
            list.add(
                MarketTicker(
                    symbol = sym,
                    displayNameAr = spec?.displayNameAr ?: sym,
                    lastPrice = last,
                    change24hPct = obj.getString("priceChangePercent").toDoubleOrNull() ?: 0.0,
                    high24h = obj.getString("highPrice").toDoubleOrNull() ?: last,
                    low24h = obj.getString("lowPrice").toDoubleOrNull() ?: last,
                    volume24hQuote = obj.getString("quoteVolume").toDoubleOrNull() ?: 0.0,
                    source = sourceLabel,
                    fetchedAtMillis = now
                )
            )
        }
        return list
    }

    private fun fetchCoinGeckoFallback(): Result<List<MarketTicker>> {
        return try {
            val ids = trackedAssets.joinToString(",") { it.coingeckoId }
            val url = "https://api.coingecko.com/api/v3/simple/price?ids=$ids&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return Result.failure(IllegalStateException("Market data unavailable (HTTP ${resp.code})"))
                }
                val json = JSONObject(resp.body?.string().orEmpty())
                val now = System.currentTimeMillis()
                val tickers = trackedAssets.mapNotNull { spec ->
                    if (!json.has(spec.coingeckoId)) return@mapNotNull null
                    val obj = json.getJSONObject(spec.coingeckoId)
                    val price = obj.optDouble("usd", 0.0)
                    if (price <= 0.0) return@mapNotNull null
                    MarketTicker(
                        symbol = spec.symbol,
                        displayNameAr = spec.displayNameAr,
                        lastPrice = price,
                        change24hPct = obj.optDouble("usd_24h_change", 0.0),
                        high24h = price,
                        low24h = price,
                        volume24hQuote = obj.optDouble("usd_24h_vol", 0.0),
                        source = "CoinGecko Public API",
                        fetchedAtMillis = now
                    )
                }
                if (tickers.isEmpty()) {
                    Result.failure(IllegalStateException("No market prices returned from live providers."))
                } else {
                    Result.success(tickers)
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchCandles(
        symbol: String,
        interval: String = "1h",
        limit: Int = 180
    ): Result<Pair<List<CandleBar>, String>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.binance.com/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    val bars = mutableListOf<CandleBar>()
                    for (i in 0 until arr.length()) {
                        val row = arr.getJSONArray(i)
                        bars.add(
                            CandleBar(
                                openTimeMillis = row.getLong(0),
                                open = row.getString(1).toDouble(),
                                high = row.getString(2).toDouble(),
                                low = row.getString(3).toDouble(),
                                close = row.getString(4).toDouble(),
                                volume = row.getString(5).toDouble()
                            )
                        )
                    }
                    if (bars.isNotEmpty()) {
                        return@withContext Result.success(bars to "Binance Klines ($interval)")
                    }
                }
            }
            // Fallback to Binance Vision public data mirror if api.binance.com is unreachable
            val mirrorUrl = "https://data-api.binance.vision/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit"
            val mirrorReq = Request.Builder().url(mirrorUrl).get().build()
            client.newCall(mirrorReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Failed to fetch live OHLCV candles for $symbol (HTTP ${resp.code})")
                    )
                }
                val arr = JSONArray(resp.body?.string().orEmpty())
                val bars = mutableListOf<CandleBar>()
                for (i in 0 until arr.length()) {
                    val row = arr.getJSONArray(i)
                    bars.add(
                        CandleBar(
                            openTimeMillis = row.getLong(0),
                            open = row.getString(1).toDouble(),
                            high = row.getString(2).toDouble(),
                            low = row.getString(3).toDouble(),
                            close = row.getString(4).toDouble(),
                            volume = row.getString(5).toDouble()
                        )
                    )
                }
                Result.success(bars to "Binance Vision Public Data ($interval)")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Fetches real orderbook depth and computes bid/ask liquidity ratio (top 20 levels).
     */
    suspend fun fetchOrderbookBidAskRatio(symbol: String): Double = withContext(Dispatchers.IO) {
        val urls = listOf(
            "https://api.binance.com/api/v3/depth?symbol=$symbol&limit=20",
            "https://data-api.binance.vision/api/v3/depth?symbol=$symbol&limit=20"
        )
        for (url in urls) {
            try {
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val json = JSONObject(resp.body?.string().orEmpty())
                        val bids = json.getJSONArray("bids")
                        val asks = json.getJSONArray("asks")
                        var bidVol = 0.0
                        var askVol = 0.0
                        for (i in 0 until bids.length()) {
                            bidVol += bids.getJSONArray(i).getString(1).toDoubleOrNull() ?: 0.0
                        }
                        for (i in 0 until asks.length()) {
                            askVol += asks.getJSONArray(i).getString(1).toDoubleOrNull() ?: 0.0
                        }
                        if (askVol > 0.0) return@withContext (bidVol / askVol)
                    }
                }
            } catch (_: Exception) {
                // try mirror
            }
        }
        1.0
    }
}
