package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CompanyConfig
import com.example.model.CorporateMessage
import com.example.model.CorporateTask
import com.example.model.MarketTicker
import com.example.model.PnLSummary
import com.example.model.formatUsdCents
import com.example.ui.theme.AmberBg
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRisk
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldProfit
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated

@Composable
fun CeoCommandScreen(
    config: CompanyConfig? = null,
    pnlSummary: PnLSummary? = null,
    messages: List<CorporateMessage>,
    tasks: List<CorporateTask>,
    tickers: List<MarketTicker>,
    isCommandRunning: Boolean,
    commandStatusMessage: String? = null,
    queuedCommandCount: Int = 0,
    failedCommandText: String? = null,
    failedCommandError: String? = null,
    onRetryFailedCommand: () -> Unit = {},
    onDismissFailedCommand: () -> Unit = {},
    onSendCommand: (String) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    var showTasksDrawer by remember { mutableStateOf(false) }

    val ceoMessages = remember(messages) {
        messages.filter { it.channel == "CEO_OWNER" }
    }
    val listState = rememberLazyListState()

    LaunchedEffect(ceoMessages.size) {
        if (ceoMessages.isNotEmpty()) {
            listState.animateScrollToItem(ceoMessages.lastIndex)
        }
    }

    val quickCommands = listOf(
        "فعّل القناص للبحث عن صفقة بدلائل مكتملة 100%.",
        "أريد جني ٢٩٩٩ دولار، استنفر جميع الموظفين والأسواق لتحقيق هذا الربح.",
        "استدعِ العم صعب 🛡️ وافحص خبراته للتعيين.",
        "شغّل المفتش حازم لمحاسبة المتقاعسين وتوبيخهم فوراً.",
        "طوّر الذكاء الجماعي (IQ) لجميع الموظفين الآن.",
        "أريد دراسة سوق الذهب حالياً وتحديد أفضل الفرص المتاحة، وإذا ظهرت فرصة تستوفي شروط الاستراتيجية، جهز خطة التداول.",
        "ما وضع البيتكوين حالياً؟",
        "أوقف جميع عمليات التداول."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        // Live Market Ticker Tape
        if (tickers.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianSurface)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                tickers.forEach { t ->
                    val changeColor = if (t.change24hPct >= 0) EmeraldProfit else MaterialTheme.colorScheme.error
                    Surface(
                        color = ObsidianSurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.border(1.dp, ObsidianBorder, RoundedCornerShape(8.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = t.symbol.replace("USDT", ""),
                                style = MaterialTheme.typography.labelMedium,
                                color = ChampagneGold,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = formatUsdCents(t.lastPrice),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${"%+.2f".format(t.change24hPct)}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = changeColor
                            )
                        }
                    }
                }
            }
        }

        // Active Owner Profit Goal Progress Card
        if (config != null && config.profitTargetUsd > 0.0 && pnlSummary != null) {
            val totalLive = pnlSummary.netRealizedProfit + pnlSummary.unrealizedPnl
            val gainedTowardGoal = totalLive - config.profitTargetBaselinePnl
            val progress = (gainedTowardGoal / config.profitTargetUsd).toFloat().coerceIn(0f, 1f)
            val remaining = (config.profitTargetUsd - gainedTowardGoal).coerceAtLeast(0.0)
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .border(1.dp, EmeraldProfit.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                    .testTag("ceo_profit_target_card")
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🎯 هدف الربح المأمور: ${formatUsdCents(config.profitTargetUsd)}",
                            style = MaterialTheme.typography.labelLarge,
                            color = ChampagneGold,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = formatUsdCents(gainedTowardGoal, signed = true),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (gainedTowardGoal >= 0.0) EmeraldProfit else CrimsonRisk,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = EmeraldProfit,
                        trackColor = ObsidianBorder
                    )
                    Text(
                        text = if (remaining <= 0.0) "✅ تم تحقيق هدف الربح بالكامل!" else "متبقي لتحقيق الهدف: ${formatUsdCents(remaining)} • التقدم: ${"%.2f".format(progress * 100f)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Collapsible Owner Orders & Corporate Tasks Pipeline Bar
        Surface(
            color = ObsidianSurfaceElevated,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showTasksDrawer = !showTasksDrawer }
                .padding(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Assignment,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "سجل أوامر المالك وقرارات الشركة (${tasks.size})",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Icon(
                        imageVector = if (showTasksDrawer) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        contentDescription = "توسيع سجل المهام",
                        tint = ChampagneGold
                    )
                }

                AnimatedVisibility(visible = showTasksDrawer) {
                    Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (tasks.isEmpty()) {
                            Text(
                                text = "لا توجد أوامر تنفيذية سابقة بعد. أرسل أمراً للرئيس التنفيذي أدناه.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            tasks.take(5).forEach { task ->
                                Surface(
                                    color = ObsidianSurface,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${task.targetAsset} • ${task.stage}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = ChampagneGold
                                            )
                                            Text(
                                                text = task.status,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = ElectricCyan
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = task.ownerOrder,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        if (task.outcomeSummary.isNotBlank()) {
                                            Text(
                                                text = "النتيجة: ${task.outcomeSummary}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = EmeraldProfit
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (isCommandRunning) {
            val isRetrying = commandStatusMessage?.contains("الضغط المؤقت") == true ||
                commandStatusMessage?.contains("إعادة محاولة") == true ||
                commandStatusMessage?.contains("إعادة إرسال") == true ||
                commandStatusMessage?.contains("ضغط على الخادم") == true
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = if (isRetrying) AmberWarn else ChampagneGold,
                trackColor = ObsidianSurface
            )
            Surface(
                color = if (isRetrying) AmberBg else ObsidianSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .border(
                        1.dp,
                        if (isRetrying) AmberWarn.copy(alpha = 0.65f) else ObsidianBorder,
                        RoundedCornerShape(10.dp)
                    )
                    .testTag("ceo_command_status_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = if (isRetrying) AmberWarn else ElectricCyan,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = commandStatusMessage
                            ?: "جاري تشغيل الدورة المؤسسية: الرئيس التنفيذي ← إدارة التحليل ← مدير التداول ← قسم المخاطر المستقل...",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isRetrying) AmberWarn else ElectricCyan,
                        fontWeight = if (isRetrying) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }

        // Chat Stream between Owner and CEO Agent
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(ceoMessages, key = { it.id }) { msg ->
                val isOwner = msg.senderId == "OWNER"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isOwner) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isOwner) ObsidianSurfaceHighOrGold() else ObsidianSurface
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth(0.92f)
                            .border(
                                1.dp,
                                if (isOwner) ChampagneGold.copy(alpha = 0.4f) else ObsidianBorder,
                                RoundedCornerShape(16.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (!isOwner) {
                                        Icon(
                                            imageVector = Icons.Filled.AutoAwesome,
                                            contentDescription = null,
                                            tint = ChampagneGold,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Text(
                                        text = msg.senderName,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = if (isOwner) ChampagneGold else ElectricCyan
                                    )
                                }
                                if (msg.decisionReached.isNotBlank()) {
                                    Text(
                                        text = msg.decisionReached,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = msg.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (msg.evidenceCited.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "المصدر/الدليل: ${msg.evidenceCited}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Arabic Command Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickCommands.forEach { cmd ->
                Surface(
                    color = ObsidianSurfaceElevated,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .border(1.dp, ObsidianBorder, RoundedCornerShape(20.dp))
                        .clickable {
                            onSendCommand(cmd)
                        }
                ) {
                    Text(
                        text = if (cmd.length > 36) cmd.take(34) + "..." else cmd,
                        style = MaterialTheme.typography.bodySmall,
                        color = ChampagneGold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }

        // Failed command: never lose the owner's order, offer one-tap retry
        if (failedCommandText != null) {
            Surface(
                color = AmberBg,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .border(1.dp, AmberWarn, RoundedCornerShape(12.dp))
                    .testTag("ceo_failed_command_card")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "لم يكتمل أمرك — محفوظ ولن يضيع:",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberWarn,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (failedCommandText.length > 160) failedCommandText.take(158) + "…" else failedCommandText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (!failedCommandError.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = failedCommandError,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            color = ChampagneGold,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onRetryFailedCommand() }
                                .testTag("ceo_retry_failed_command")
                        ) {
                            Text(
                                text = "إعادة المحاولة الآن",
                                style = MaterialTheme.typography.labelMedium,
                                color = ObsidianBg,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                        Surface(
                            color = ObsidianSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, ObsidianBorder, RoundedCornerShape(10.dp))
                                .clickable { onDismissFailedCommand() }
                                .testTag("ceo_dismiss_failed_command")
                        ) {
                            Text(
                                text = "تجاهل",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        if (queuedCommandCount > 1) {
            Text(
                text = "في قائمة الانتظار: $queuedCommandCount أوامر (تُنفَّذ بالترتيب)",
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
            )
        }

        // Command Input Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ObsidianSurface)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = {
                    Text("أرسل أمراً للرئيس التنفيذي (عربي / English)...", style = MaterialTheme.typography.bodySmall)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ChampagneGold,
                    unfocusedBorderColor = ObsidianBorder,
                    focusedContainerColor = ObsidianBg,
                    unfocusedContainerColor = ObsidianBg
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("ceo_command_input"),
                maxLines = 3
            )
            Spacer(modifier = Modifier.width(8.dp))
            val sendEnabled = inputText.isNotBlank()
            IconButton(
                onClick = {
                    if (sendEnabled) {
                        val toSend = inputText
                        inputText = ""
                        onSendCommand(toSend)
                    }
                },
                enabled = sendEnabled,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (sendEnabled) ChampagneGold else ChampagneGold.copy(alpha = 0.35f))
                    .testTag("ceo_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "إرسال الأمر للرئيس التنفيذي",
                    tint = ObsidianBg
                )
            }
        }
    }
}

@Composable
private fun ObsidianSurfaceHighOrGold() = ObsidianSurfaceElevated.copy(alpha = 0.95f)
