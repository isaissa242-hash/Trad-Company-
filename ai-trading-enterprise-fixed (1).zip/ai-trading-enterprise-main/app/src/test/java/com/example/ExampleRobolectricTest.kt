package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.model.AuditLog
import com.example.model.BrokerAccountSnapshot
import com.example.model.BrokerCredentials
import com.example.model.CompanyConfig
import com.example.model.CorporateMessage
import com.example.model.CorporateTask
import com.example.model.InitialCompanyRoster
import com.example.model.LearningLog
import com.example.model.MarketTicker
import com.example.model.PnLSummary
import com.example.model.TradeRecord
import com.example.ui.auth.AuthScreen
import com.example.ui.screens.BrokerControlScreen
import com.example.ui.screens.CeoCommandScreen
import com.example.ui.screens.PnLDashboardScreen
import com.example.ui.screens.StrategyHrMemoryScreen
import com.example.ui.screens.VirtualOfficeScreen
import com.example.ui.theme.QuantCorpTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun sampleConfig() = CompanyConfig(
        userId = "test_owner",
        profitTargetUsd = 2999.0,
        safetyVaultBalance = 425.50,
        safetyVaultTotalDeposited = 425.50
    )

    private fun samplePnl() = PnLSummary(
        mode = "PAPER",
        totalRealizedProfit = 1450.0,
        totalRealizedLoss = 210.0,
        totalFeesAndSlippage = 35.0,
        netRealizedProfit = 1240.0,
        unrealizedPnl = 180.0,
        balance = 100_814.50,
        equity = 100_994.50,
        roiPct = 0.99,
        winRatePct = 75.0,
        winningTrades = 3,
        losingTrades = 1,
        avgWin = 483.33,
        avgLoss = 210.0,
        largestWin = 710.0,
        largestLoss = -210.0,
        maxDrawdownPct = 1.1,
        equityCurve = listOf(100_000.0, 100_450.0, 100_240.0, 100_994.50)
    )

    private fun sampleTickers() = listOf(
        MarketTicker("PAXGUSDT", "الذهب الفوري (PAXG/XAU)", 2720.50, 1.45, 2735.0, 2680.0, 18_500_000.0, "Binance", System.currentTimeMillis()),
        MarketTicker("BTCUSDT", "بيتكوين (BTC/USDT)", 94_200.0, 2.15, 95_000.0, 91_800.0, 950_000_000.0, "Binance", System.currentTimeMillis())
    )

    @Test
    fun readStringFromContext_matchesQuantCorpName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("QuantCorp AI", context.getString(R.string.app_name))
    }

    @Test
    fun authScreen_displaysSignInButtonAndPillars() {
        composeTestRule.setContent {
            QuantCorpTheme(darkTheme = true) {
                AuthScreen(onAuthSuccess = {})
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("QuantCorp AI").assertIsDisplayed()
        composeTestRule.onNodeWithTag("google_sign_in_button")
            .performScrollTo()
            .assertIsDisplayed()
            .assertIsEnabled()
    }

    @Test
    fun ceoCommandScreen_disablesSendWhenBlankAndSubmitsCommand() {
        var sentCommand = ""
        val msgs = listOf(
            CorporateMessage(
                id = "m1",
                senderId = "ceo_01",
                senderName = "د. طارق المنصور (CEO)",
                channel = "CEO_OWNER",
                content = "جاهز لأوامر المالك"
            )
        )
        composeTestRule.setContent {
            QuantCorpTheme(darkTheme = true) {
                CeoCommandScreen(
                    config = sampleConfig(),
                    pnlSummary = samplePnl(),
                    messages = msgs,
                    tasks = listOf(CorporateTask(id = "t1", ownerOrder = "فحص الذهب", stage = "DONE", status = "CLOSED")),
                    tickers = sampleTickers(),
                    isCommandRunning = false,
                    onSendCommand = { sentCommand = it }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("ceo_profit_target_card").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ceo_send_button").assertIsNotEnabled()

        composeTestRule.onNodeWithTag("ceo_command_input").performTextInput("حلل سوق الذهب الآن")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("ceo_send_button")
            .assertIsEnabled()
            .performClick()
        composeTestRule.waitForIdle()
        assertEquals("حلل سوق الذهب الآن", sentCommand)
    }

    @Test
    fun virtualOfficeScreen_rendersHierarchyAndSwitchesTo3DOffice() {
        val agents = InitialCompanyRoster.defaultAgents("test_owner").map { it.second }
        composeTestRule.setContent {
            QuantCorpTheme(darkTheme = true) {
                VirtualOfficeScreen(
                    config = sampleConfig(),
                    agents = agents,
                    messages = emptyList(),
                    tasks = emptyList(),
                    learningLogs = emptyList(),
                    strategies = InitialCompanyRoster.defaultStrategies("test_owner").map { it.second },
                    tickers = sampleTickers(),
                    pnlSummary = samplePnl(),
                    onToggleBlockAgent = { _, _ -> },
                    onChangeAgentModel = { _, _ -> }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("المقر الافتراضي لشركة QuantCorp AI").assertIsDisplayed()
        composeTestRule.onNodeWithTag("office_tab_3d").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("office_3d_active_tasks_count").assertIsDisplayed()
        composeTestRule.onNodeWithTag("office_3d_reset_camera").assertIsDisplayed()
    }

    @Test
    fun pnlDashboardScreen_togglesPaperLiveFilter() {
        var selectedFilter = "PAPER"
        val trades = listOf(
            TradeRecord(
                id = "tr1",
                symbol = "PAXGUSDT",
                side = "BUY",
                mode = "PAPER",
                status = "OPEN",
                entryPrice = 2700.0,
                quantity = 0.5,
                stopLoss = 2660.0,
                takeProfit = 2780.0
            )
        )
        composeTestRule.setContent {
            QuantCorpTheme(darkTheme = true) {
                PnLDashboardScreen(
                    config = sampleConfig(),
                    pnlSummary = samplePnl(),
                    pnlModeFilter = selectedFilter,
                    onModeFilterChange = { selectedFilter = it },
                    trades = trades,
                    strategies = InitialCompanyRoster.defaultStrategies("test_owner").map { it.second },
                    tickers = sampleTickers(),
                    selectedSymbol = "PAXGUSDT",
                    selectedCandles = emptyList(),
                    selectedTechSnapshot = null,
                    onSelectSymbol = {},
                    onCloseTrade = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("الحساب الحقيقي (LIVE)").performClick()
        composeTestRule.waitForIdle()
        assertEquals("LIVE", selectedFilter)
    }

    @Test
    fun strategyHrMemoryScreen_switchesTabsAndShowsAgents() {
        val agents = InitialCompanyRoster.defaultAgents("test_owner").map { it.second }
        val strategies = InitialCompanyRoster.defaultStrategies("test_owner").map { it.second }
        composeTestRule.setContent {
            QuantCorpTheme(darkTheme = true) {
                StrategyHrMemoryScreen(
                    strategies = strategies,
                    agents = agents,
                    learningLogs = listOf(
                        LearningLog(
                            id = "l1",
                            agentId = "trd_short_01",
                            agentName = "المتداول A",
                            errorType = "INSIGHT",
                            decisionSummary = "تنفيذ BUY PAXGUSDT",
                            actualOutcome = "نجاح +$140"
                        )
                    ),
                    isBacktesting = false,
                    lastBacktestReport = null,
                    onRunBacktest = { _, _ -> },
                    onApproveStrategyLive = { _, _ -> },
                    onRecruitCandidate = { _, _, _, _, _ -> },
                    onApproveCandidate = { _, _ -> }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("الموارد البشرية HR").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("run_strict_audit_btn").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("الذاكرة والأخطاء").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("تنفيذ BUY PAXGUSDT", substring = true).assertIsDisplayed()
    }

    @Test
    fun brokerControlScreen_togglesCloudEngineAndSniperSwitch() {
        var cloudToggledTo: Boolean? = null
        var sniperToggledTo: Boolean? = null
        composeTestRule.setContent {
            QuantCorpTheme(darkTheme = true) {
                BrokerControlScreen(
                    config = sampleConfig(),
                    isNetworkOnline = true,
                    brokerCreds = BrokerCredentials(),
                    brokerSnapshot = BrokerAccountSnapshot(connected = true, balance = 100_000.0, equity = 100_000.0),
                    auditLogs = listOf(AuditLog(id = "a1", actor = "OWNER", actionType = "INIT", details = "Ready")),
                    onToggleCloudEngine = { cloudToggledTo = it },
                    onSaveAndTestBroker = {},
                    onUpdateRiskSettings = { _, _, _, _ -> },
                    onSwitchMode = { _, _ -> },
                    onToggleKillSwitch = {},
                    onToggleTradingPause = {},
                    onToggleSniper = { sniperToggledTo = it },
                    onEmergencyCloseAll = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("cloud_engine_switch").performClick()
        composeTestRule.onNodeWithTag("broker_control_list").performScrollToNode(hasTestTag("admin_sniper_switch"))
        composeTestRule.onNodeWithTag("admin_sniper_switch").performClick()
        composeTestRule.waitForIdle()
        assertTrue(cloudToggledTo == true)
        assertTrue(sniperToggledTo == false)
    }
}
