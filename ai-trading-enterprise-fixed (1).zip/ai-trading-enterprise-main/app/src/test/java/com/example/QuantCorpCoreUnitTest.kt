package com.example

import com.example.data.ai.AI_RETRY_USER_MESSAGE
import com.example.data.ai.executeWithAiRetry
import com.example.data.ai.extractProfitTargetUsd
import com.example.data.ai.isTransientAiError
import com.example.data.ai.normalizeArabicNumerals
import com.example.data.ai.resolveFallbackChain
import com.example.data.ai.selectModelForAttempt
import com.example.data.market.BacktestEngine
import com.example.data.market.TechnicalIndicatorEngine
import com.example.data.risk.RiskEngine
import com.example.model.AgentProfile
import com.example.model.AgentRankSystem
import com.example.model.CandleBar
import com.example.model.CompanyConfig
import com.example.model.TradeRecord
import com.example.model.TradingStrategy
import com.example.model.formatUsdCents
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class QuantCorpCoreUnitTest {

    private fun sampleCandles(count: Int = 140): List<CandleBar> {
        var price = 2600.0
        return (0 until count).map { idx ->
            val drift = 2.0 + sin(idx * 0.25) * 14.0
            val open = price
            val close = (open + drift).coerceAtLeast(100.0)
            val high = maxOf(open, close) + 8.0
            val low = minOf(open, close) - 7.0
            price = close
            CandleBar(
                openTimeMillis = 1700000000000L + idx * 3_600_000L,
                open = open,
                high = high,
                low = low,
                close = close,
                volume = 1200.0 + (idx % 7) * 250.0
            )
        }
    }

    @Test
    fun riskEngine_vetoesWhenKillSwitchIsActive() {
        val cfg = CompanyConfig(killSwitchActive = true, tradingPaused = false)
        val trader = AgentProfile(id = "trd_short_01", approvedByOwner = true, blockedByOwner = false)
        val strat = TradingStrategy(id = "strat_ema_sweep", name = "Test", approvedForLive = false)

        val eval = RiskEngine.evaluateTradeProposal(
            config = cfg,
            strategy = strat,
            trader = trader,
            openTrades = emptyList(),
            closedTradesInMode = emptyList(),
            symbol = "PAXGUSDT",
            side = "BUY",
            entryPrice = 2700.0,
            stopLoss = 2650.0,
            takeProfit = 2800.0,
            marketDataTimestampMillis = System.currentTimeMillis()
        )
        assertFalse(eval.approved)
        assertTrue(eval.approvalId.startsWith("CRO-VETO"))
    }

    @Test
    fun riskEngine_vetoesLiveTradeWithoutOwnerApproval() {
        val cfg = CompanyConfig(tradingMode = "LIVE", liveTradingApprovedByOwner = false)
        val trader = AgentProfile(id = "trd_short_01", approvedByOwner = true)
        val strat = TradingStrategy(id = "strat_ema_sweep", name = "Test", approvedForLive = true)

        val eval = RiskEngine.evaluateTradeProposal(
            config = cfg,
            strategy = strat,
            trader = trader,
            openTrades = emptyList(),
            closedTradesInMode = emptyList(),
            symbol = "BTCUSDT",
            side = "BUY",
            entryPrice = 90000.0,
            stopLoss = 88500.0,
            takeProfit = 93000.0,
            marketDataTimestampMillis = System.currentTimeMillis()
        )
        assertFalse(eval.approved)
    }

    @Test
    fun riskEngine_approvesValidPaperTradeAndComputesBoundedPositionSize() {
        val cfg = CompanyConfig(
            tradingMode = "PAPER",
            allocatedCapital = 100_000.0,
            paperBalance = 100_000.0,
            maxRiskPerTradePct = 1.5,
            maxOpenPositions = 5
        )
        val trader = AgentProfile(id = "trd_short_01", approvedByOwner = true, blockedByOwner = false)
        val strat = TradingStrategy(id = "strat_ema_sweep", name = "Test", approvedForLive = false)

        val eval = RiskEngine.evaluateTradeProposal(
            config = cfg,
            strategy = strat,
            trader = trader,
            openTrades = listOf(TradeRecord(symbol = "ETHUSDT", mode = "PAPER", status = "OPEN")),
            closedTradesInMode = emptyList(),
            symbol = "PAXGUSDT",
            side = "BUY",
            entryPrice = 2700.0,
            stopLoss = 2670.0,
            takeProfit = 2760.0,
            marketDataTimestampMillis = System.currentTimeMillis()
        )
        assertTrue(eval.approved)
        assertTrue(eval.computedPositionQty > 0.0)
        assertEquals(1500.0, eval.computedRiskUsd, 0.01)
    }

    @Test
    fun technicalIndicatorsAndBacktester_computeDeterministicMetrics() {
        val bars = sampleCandles(150)
        val snap = TechnicalIndicatorEngine.analyze("PAXGUSDT", "1h", bars, 1.15, "UnitTest")
        assertTrue(snap.rsi14 in 0.0..100.0)
        assertTrue(snap.atr14 > 0.0)
        assertTrue(snap.resistanceLevel >= snap.supportLevel)

        val strat = TradingStrategy(id = "strat_ema_sweep", name = "EMA Trend")
        val report = BacktestEngine.runWalkForwardBacktest(strat, "PAXGUSDT", bars)
        assertEquals(150, report.barsTested)
        assertTrue(report.feesAndSlippagePct > 0.0)
    }

    @Test
    fun aiRetryPolicy_detectsTransientServerErrorsAndRetriesUpTo3Times() = runTest {
        assertTrue(isTransientAiError(RuntimeException("HTTP 503 Service Unavailable due to high demand")))
        assertTrue(isTransientAiError(RuntimeException("429 Rate Limit exceeded")))
        assertFalse(isTransientAiError(IllegalArgumentException("Invalid schema definition")))

        var calls = 0
        val statuses = mutableListOf<String>()
        val result = executeWithAiRetry(
            maxRetries = 3,
            baseDelayMs = 10L,
            onRetryStatus = { statuses.add(it) }
        ) {
            calls++
            if (calls <= 3) {
                throw RuntimeException("503 Service Unavailable - high demand")
            }
            "SUCCESS_ON_FINAL_RETRY"
        }

        assertEquals("SUCCESS_ON_FINAL_RETRY", result)
        assertEquals(4, calls)
        assertEquals(3, statuses.size)
        assertTrue(statuses.all { it.contains(AI_RETRY_USER_MESSAGE) })
    }

    @Test
    fun aiRetryPolicy_stopsAfterMax3Retries() = runTest {
        var calls = 0
        var thrown: Throwable? = null
        try {
            executeWithAiRetry(
                maxRetries = 3,
                baseDelayMs = 5L
            ) {
                calls++
                throw RuntimeException("429 Rate Limit")
            }
        } catch (t: Throwable) {
            thrown = t
        }
        assertEquals(4, calls)
        assertTrue(thrown.message?.contains("429") == true)
    }

    @Test
    fun smartModelFallback_escalatesDownLadderOnOverloadAndRecovers() = runTest {
        assertEquals(
            listOf("gemini-4-argon", "gemini-3.8-flash", "gemini-3.5-flash-lite"),
            resolveFallbackChain("gemini-4-argon")
        )
        assertEquals("gemini-4-argon", selectModelForAttempt("gemini-4-argon", 0))
        assertEquals("gemini-3.8-flash", selectModelForAttempt("gemini-4-argon", 1))
        assertEquals("gemini-3.5-flash-lite", selectModelForAttempt("gemini-4-argon", 2))
        assertEquals("gemini-3.5-flash-lite", selectModelForAttempt("gemini-4-argon", 3))

        val attemptedModels = mutableListOf<String>()
        val statusMessages = mutableListOf<String>()
        val output = executeWithAiRetry(
            maxRetries = 3,
            baseDelayMs = 5L,
            onRetryStatus = { statusMessages.add(it) },
            nextModelForAttempt = { attempt -> selectModelForAttempt("gemini-4-argon", attempt) }
        ) { attempt ->
            val model = selectModelForAttempt("gemini-4-argon", attempt)
            attemptedModels.add(model)
            if (attempt < 2) {
                throw RuntimeException("503 high demand on $model")
            }
            "DONE_ON_$model"
        }

        assertEquals("DONE_ON_gemini-3.5-flash-lite", output)
        assertEquals(
            listOf("gemini-4-argon", "gemini-3.8-flash", "gemini-3.5-flash-lite"),
            attemptedModels
        )
        assertTrue(statusMessages[0].contains("gemini-3.8-flash"))
        assertTrue(statusMessages[1].contains("gemini-3.5-flash-lite"))
    }

    @Test
    fun agentRankSystem_mapsAll10TiersCorrectlyFromStarToWhale() {
        val expectedBadges = listOf(
            0L to "⭐",
            50L to "⭐⭐",
            120L to "⭐⭐⭐",
            220L to "🦅",
            350L to "🦅🦅",
            520L to "🦅🦅🦅",
            740L to "⚔️",
            1000L to "⚔️⚔️",
            1350L to "⚔️⚔️⚔️",
            1800L to "🐋"
        )
        expectedBadges.forEachIndexed { idx, (xp, badge) ->
            val info = AgentRankSystem.evaluate(xp)
            assertEquals(idx + 1, info.level)
            assertEquals(badge, info.badge)
        }
        val maxInfo = AgentRankSystem.evaluate(2500L)
        assertTrue(maxInfo.isMaxRank)
        assertEquals(1f, maxInfo.progressToNext)
        assertEquals(0L, AgentRankSystem.applyXpDelta(5L, -50L).first)
    }

    @Test
    fun profitTargetParser_normalizesArabicNumeralsAndIgnoresPercentages() {
        assertEquals("2999", normalizeArabicNumerals("٢٩٩٩"))
        assertEquals(2999.0, extractProfitTargetUsd("اريد جني ٢٩٩٩ دولار") ?: 0.0, 0.001)
        assertEquals(1500.50, extractProfitTargetUsd("هدفي تحقيق ربح 1,500.50 USD") ?: 0.0, 0.001)
        assertNull(extractProfitTargetUsd("مخاطرة 2%"))
        assertNull(extractProfitTargetUsd("درس سوق الذهب فقط"))
    }

    @Test
    fun profitOnlyRankXp_awardsZeroOnNonProfitAndScalesOnPositiveProfit() {
        assertEquals(0L, AgentRankSystem.calculateProfitXp(0.0, 1.0))
        assertEquals(0L, AgentRankSystem.calculateProfitXp(-125.45, 1.0))
        assertEquals(0L, AgentRankSystem.calculateProfitXp(500.0, 0.0))

        val traderXp = AgentRankSystem.calculateProfitXp(400.0, 1.0)
        val ceoXp = AgentRankSystem.calculateProfitXp(400.0, 0.60)
        val analystXp = AgentRankSystem.calculateProfitXp(400.0, 0.40)
        assertEquals(120L, traderXp)
        assertEquals(72L, ceoXp)
        assertEquals(48L, analystXp)
        assertTrue(AgentRankSystem.calculateProfitXp(0.05, 1.0) >= 5L)
    }

    @Test
    fun formatUsdCents_displaysExactCentsWithSignInUsNumerals() {
        assertEquals("+$2,999.00", formatUsdCents(2999.0, signed = true))
        assertEquals("+$0.01", formatUsdCents(0.01, signed = true))
        assertEquals("-$0.05", formatUsdCents(-0.05, signed = true))
        assertEquals("$0.00", formatUsdCents(0.0, signed = true))
        assertEquals("-$12.34", formatUsdCents(-12.34, signed = false))
    }

    @Test
    fun safetyVault_calculatesTenPercentAndProtectsAgainstBankruptcy() {
        assertEquals(30.00, TechnicalIndicatorEngine.calculateVaultDepositUsd(299.95, 10.0), 0.001)
        assertEquals(10.00, TechnicalIndicatorEngine.calculateVaultDepositUsd(100.0, 10.0), 0.001)
        assertEquals(0.0, TechnicalIndicatorEngine.calculateVaultDepositUsd(0.0, 10.0), 0.001)
        assertEquals(0.0, TechnicalIndicatorEngine.calculateVaultDepositUsd(-120.50, 10.0), 0.001)

        // RiskEngine must veto trading when operational paperBalance is depleted, leaving Safety Vault untouched
        val depletedConfig = CompanyConfig(
            tradingMode = "PAPER",
            paperBalance = 0.0,
            safetyVaultBalance = 5_000.0
        )
        val sniper = AgentProfile(id = "sniper_01", approvedByOwner = true, blockedByOwner = false)
        val strat = TradingStrategy(id = "strat_ema_sweep", name = "Sniper", approvedForLive = false)
        val eval = RiskEngine.evaluateTradeProposal(
            config = depletedConfig,
            strategy = strat,
            trader = sniper,
            openTrades = emptyList(),
            closedTradesInMode = emptyList(),
            symbol = "PAXGUSDT",
            side = "BUY",
            entryPrice = 2700.0,
            stopLoss = 2670.0,
            takeProfit = 2770.0,
            marketDataTimestampMillis = System.currentTimeMillis()
        )
        assertFalse(eval.approved)
        assertTrue(eval.approvalId.startsWith("CRO-VETO"))
    }

    @Test
    fun forwardSniperConfluence_requires100PercentAllFiveEvidences() {
        fun strongBullishBars(count: Int, step: Double, surgeLast: Boolean): List<CandleBar> {
            var price = 2500.0
            return (0 until count).map { idx ->
                val isPullback = idx < count - 3 && idx % 2 == 1
                val delta = when {
                    surgeLast && idx >= count - 3 -> step * 0.8
                    isPullback -> -step * 1.25
                    else -> step * 1.35
                }
                val open = price
                val close = open + delta
                val high = maxOf(open, close) + step * 0.4
                val low = minOf(open, close) - step * 0.3
                price = close
                val vol = if (surgeLast && idx >= count - 3) 4200.0 else 1000.0
                CandleBar(
                    openTimeMillis = 1700000000000L + idx * 900_000L,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = vol
                )
            }
        }

        val m15 = strongBullishBars(80, step = 1.5, surgeLast = true)
        val h1 = strongBullishBars(80, step = 2.0, surgeLast = true)
        val h4 = strongBullishBars(80, step = 3.0, surgeLast = true)

        val fullReport = TechnicalIndicatorEngine.evaluateForwardSniperConfluence(
            symbol = "PAXGUSDT",
            m15Bars = m15,
            h1Bars = h1,
            h4Bars = h4,
            orderbookBidAskRatio = 1.38,
            source = "UnitTest"
        )
        assertEquals(
            "Expected 5/5 checks to pass, got: ${fullReport.checks.joinToString { "${it.titleAr}=${it.passed}(${it.metricSummary})" }}",
            5,
            fullReport.matchedCount
        )
        assertEquals(100.0, fullReport.evidenceScorePct, 0.01)
        assertTrue(fullReport.isFullSniperMatch)
        assertEquals("BUY", fullReport.preferredSide)
        assertTrue(fullReport.takeProfit > fullReport.entryPrice)

        // When Bid/Ask orderbook liquidity disagrees, Sniper MUST refuse (< 100%)
        val partialReport = TechnicalIndicatorEngine.evaluateForwardSniperConfluence(
            symbol = "PAXGUSDT",
            m15Bars = m15,
            h1Bars = h1,
            h4Bars = h4,
            orderbookBidAskRatio = 0.95,
            source = "UnitTest"
        )
        assertTrue(partialReport.matchedCount < 5)
        assertTrue(partialReport.evidenceScorePct < 100.0)
        assertFalse(partialReport.isFullSniperMatch)
    }

    @Test
    fun sniperAgentRole_isConfiguredInTradingDepartmentWithAdminToggle() {
        val cfg = CompanyConfig()
        assertTrue(cfg.sniperEnabled)
        assertFalse(cfg.copy(sniperEnabled = false).sniperEnabled)

        val roster = com.example.model.InitialCompanyRoster.defaultAgents("owner_1").toMap()
        val sniper = roster["sniper_01"]
        assertTrue(sniper != null)
        assertEquals(com.example.model.Department.LIVE_TRADING.name, sniper?.department)
        assertEquals("gemini-4-argon", sniper?.modelId)
        assertTrue(sniper?.specialization?.contains("100%") == true)
    }

    @Test
    fun strictDisciplineOfficerAndUncleSaabDossier_areConfiguredWithIntelligenceMetrics() {
        val roster = com.example.model.InitialCompanyRoster.defaultAgents("owner_1").toMap()
        val enforcer = roster["enforcer_01"]
        assertTrue(enforcer != null)
        assertEquals(com.example.model.Department.HR.name, enforcer?.department)
        assertEquals("gemini-4-argon", enforcer?.modelId)
        assertTrue((enforcer?.intelligenceScore ?: 0.0) >= 130.0)

        val saab = com.example.model.InitialCompanyRoster.uncleSaabPreset("owner_1")
        assertEquals("uncle_saab", saab.id)
        assertTrue(saab.candidatePending)
        assertFalse(saab.approvedByOwner)
        assertTrue(saab.candidateExpertise.isNotBlank())
        assertTrue(saab.candidateCompanyBenefit.isNotBlank())
        assertTrue(saab.backtestPassRate >= 70.0)
        assertTrue(saab.intelligenceScore >= 150.0)

        // Verify strict reprimand XP penalty floors cleanly at 0 and preserves profit-only rank rules
        val (penalizedXp, levelAfter) = AgentRankSystem.applyXpDelta(40L, -15L)
        assertEquals(25L, penalizedXp)
        assertEquals(1L, levelAfter)

        val payload = saab.toCreateMap("owner_1")
        assertTrue(payload.containsKey("intelligenceScore"))
        assertTrue(payload.containsKey("candidateExpertise"))
        assertTrue(payload.containsKey("candidateCompanyBenefit"))
        assertTrue(payload.containsKey("reprimandsCount"))
        assertTrue(payload.containsKey("lastReprimandReason"))
    }

    @Test
    fun riskEngine_vetoesBadStopLossTakeProfitDuplicateSymbolAndStaleData() {
        val cfg = CompanyConfig(tradingMode = "PAPER", paperBalance = 100_000.0, maxOpenPositions = 5)
        val trader = AgentProfile(id = "trd_short_01", approvedByOwner = true)
        val strat = TradingStrategy(id = "strat_ema_sweep", name = "Test")

        // 1. Duplicate open symbol
        val dupEval = RiskEngine.evaluateTradeProposal(
            config = cfg,
            strategy = strat,
            trader = trader,
            openTrades = listOf(TradeRecord(symbol = "PAXGUSDT", mode = "PAPER", status = "OPEN")),
            closedTradesInMode = emptyList(),
            symbol = "PAXGUSDT",
            side = "BUY",
            entryPrice = 2700.0,
            stopLoss = 2670.0,
            takeProfit = 2760.0,
            marketDataTimestampMillis = System.currentTimeMillis()
        )
        assertFalse(dupEval.approved)

        // 2. Inverted BUY stopLoss (>= entry) and takeProfit (<= entry)
        val invertedEval = RiskEngine.evaluateTradeProposal(
            config = cfg,
            strategy = strat,
            trader = trader,
            openTrades = emptyList(),
            closedTradesInMode = emptyList(),
            symbol = "PAXGUSDT",
            side = "BUY",
            entryPrice = 2700.0,
            stopLoss = 2710.0,
            takeProfit = 2690.0,
            marketDataTimestampMillis = System.currentTimeMillis()
        )
        assertFalse(invertedEval.approved)

        // 3. Stale market data (> 3 minutes old)
        val staleEval = RiskEngine.evaluateTradeProposal(
            config = cfg,
            strategy = strat,
            trader = trader,
            openTrades = emptyList(),
            closedTradesInMode = emptyList(),
            symbol = "PAXGUSDT",
            side = "BUY",
            entryPrice = 2700.0,
            stopLoss = 2670.0,
            takeProfit = 2760.0,
            marketDataTimestampMillis = System.currentTimeMillis() - 300_000L
        )
        assertFalse(staleEval.approved)
    }

    @Test
    fun brokerConnector_validatesMt5EndpointSchemeAndPaperMode() = runTest {
        val connector = com.example.data.broker.BrokerConnector()

        // Paper mode succeeds immediately with generated order ID
        val paperRes = connector.submitOrder(
            creds = com.example.model.BrokerCredentials(platform = com.example.model.BrokerPlatform.QUANTCORP_PAPER),
            symbol = "PAXGUSDT",
            side = "BUY",
            quantity = 0.5,
            isLiveMode = false
        )
        assertTrue(paperRes.isSuccess)
        assertTrue(paperRes.getOrNull()?.startsWith("PAPER-") == true)

        // Invalid non-HTTP MT5 bridge URL fails fast cleanly without network call
        val mt5Invalid = connector.submitMt5BridgeOrder(
            creds = com.example.model.BrokerCredentials(
                platform = com.example.model.BrokerPlatform.METATRADER_5,
                apiKey = "tok_123",
                customEndpoint = "ftp://invalid-bridge.local"
            ),
            symbol = "XAUUSD",
            side = "BUY",
            quantity = 0.1
        )
        assertTrue(mt5Invalid.isFailure)
        assertTrue(mt5Invalid.exceptionOrNull()?.message?.contains("http") == true)
    }

    @Test
    fun authDiagnostics_formatsDeveloperError28444AndNetworkErrors() {
        val devMsg = com.example.ui.auth.formatAuthDiagnosticError(RuntimeException("[28444] Developer error"))
        assertTrue(devMsg.contains("28444"))
        assertTrue(devMsg.contains("DEBUG_KEYSTORE_BASE64"))

        val netMsg = com.example.ui.auth.formatAuthDiagnosticError(RuntimeException("network timeout"))
        assertTrue(netMsg.contains("الإنترنت"))
    }
}
