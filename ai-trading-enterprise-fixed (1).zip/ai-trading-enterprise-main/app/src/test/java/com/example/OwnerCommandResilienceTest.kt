package com.example

import com.example.data.ai.OwnerCommandException
import com.example.data.ai.detectSymbolFromCommand
import com.example.data.ai.extractRiskPctFromCommand
import com.example.data.ai.isExplicitStopTradingCommand
import com.example.data.ai.isTransientAiError
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OwnerCommandResilienceTest {

    @Test
    fun stopTrading_isRecognisedLocallyWithoutAi() {
        assertTrue(isExplicitStopTradingCommand("أوقف جميع عمليات التداول."))
        assertTrue(isExplicitStopTradingCommand("أوقف التداول فوراً"))
        assertTrue(isExplicitStopTradingCommand("Stop trading now"))
    }

    @Test
    fun stopTrading_ignoresQuestionsNegationsAndUnrelatedOrders() {
        assertFalse(isExplicitStopTradingCommand("ما وضع البيتكوين حالياً؟"))
        assertFalse(isExplicitStopTradingCommand("why did trading stop?"))
        assertFalse(isExplicitStopTradingCommand("do not stop trading"))
        assertFalse(isExplicitStopTradingCommand("don't stop trading"))
        assertFalse(isExplicitStopTradingCommand("أوقف المتقاعسين"))
        assertFalse(isExplicitStopTradingCommand("أريد دراسة سوق الذهب حالياً وتحديد أفضل الفرص المتاحة، وإذا ظهرت فرصة جهز خطة التداول."))
        assertFalse(isExplicitStopTradingCommand(""))
    }

    @Test
    fun riskPct_isExtractedOnlyFromRiskOrdersInSaneRange() {
        assertEquals(2.0, extractRiskPctFromCommand("اجعل المخاطرة 2%") ?: 0.0, 0.001)
        assertEquals(3.5, extractRiskPctFromCommand("خفض المخاطرة إلى ٣٫٥") ?: 0.0, 0.001)
        assertNull(extractRiskPctFromCommand("أريد جني 2999 دولار"))
        assertNull(extractRiskPctFromCommand("المخاطرة 50"))
    }

    @Test
    fun symbolDetection_mapsCommonNames() {
        assertEquals("BTCUSDT", detectSymbolFromCommand("ما وضع البيتكوين حالياً؟"))
        assertEquals("ETHUSDT", detectSymbolFromCommand("analyze eth"))
        assertEquals("PAXGUSDT", detectSymbolFromCommand("حلل الذهب"))
    }

    @Test
    fun retiredModelErrors_areTreatedAsTransientSoFallbackLadderAdvances() {
        assertTrue(isTransientAiError(RuntimeException("model gemini-x was not found (404)")))
        assertFalse(isTransientAiError(IllegalArgumentException("Invalid schema definition")))
    }

    @Test
    fun ownerCommandException_carriesRetryFlag() {
        assertTrue(OwnerCommandException("busy", retryable = true).retryable)
        assertFalse(OwnerCommandException("done wrong", retryable = false).retryable)
    }
}
