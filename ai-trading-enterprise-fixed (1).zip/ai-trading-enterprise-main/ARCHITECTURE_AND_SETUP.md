# QuantCorp AI — Autonomous Multi-Agent AI Trading Company (Android)

## 1. Architecture Overview
- **Runtime & UI**: Native Android application built with Kotlin, Jetpack Compose, Material 3 (Obsidian & Champagne Gold institutional dark UI), bundled `Cairo`, `IBM Plex Sans Arabic`, and `JetBrains Mono` typography, and adaptive `NavigationBar` / `NavigationRail` layouts.
- **Multi-Agent AI Engine (`AgentOrchestrator`)**: Powered by **Firebase AI Logic (`Firebase.ai`)** with Firebase App Check attestation. Supports per-agent Gemini model selection (`gemini-3.8-flash`, `gemini-3.5-flash-lite`, `gemini-4-argon`).
- **Corporate Hierarchy (11+ Agents)**:
  - **CEO Agent (`ceo_01`)**: Interprets Arabic/English owner commands via structured JSON routing (`Schema.obj`), creates execution plans, delegates, and reports outcomes.
  - **Market Intelligence (`mid_01` + `ana_fund_01`, `ana_tech_01`, `ana_liq_01`)**: Fetches real live market prices, OHLCV candles, and orderbook depth from Binance Spot / CoinGecko public APIs (`MarketDataService` + `TechnicalIndicatorEngine`), runs parallel independent analyses distinguishing Confirmed Fact vs Forecast vs Hypothesis, and produces a Unified Intelligence Report.
  - **Live Trading (`hot_01` + `trd_short_01`, `trd_mid_01`, `trd_multi_01`)**: Debates Unified Report in the War Room, selects an approved strategy, computes ATR-based Stop-Loss/Take-Profit from real live prices, and routes to Risk.
  - **Independent Risk (`cro_01` + `RiskEngine`)**: Technologically independent hard-coded gate enforcing Kill Switch, data freshness, max risk %, daily/weekly loss limits, max open positions, leverage cap, and Live Mode owner authorization.
  - **AI Human Resources (`hr_01`)**: Evaluates and recruits specialist agents, running mandatory Out-of-Sample Walk-Forward simulations before submitting candidates for Owner approval.
- **Continuous Learning & Long-Term Memory (`CompanyRepository` + Cloud Firestore)**:
  - Stores company config, agents, tasks, War Room debates, strategies, trades, audit logs, and learning logs isolated under `/users/{userId}/...` with zero-trust `firestore.rules`.
  - Classifies outcomes into `INSIGHT`, `NORMAL_STRATEGY_LOSS`, `ANALYSIS_ERROR`, and `EXECUTION_ERROR` without overfitting to single losses.
- **Security & Broker Integration (`EncryptedVault` + `BrokerConnector`)**:
  - Broker API keys and secrets are encrypted locally via **Android Keystore AES-256-GCM** (`EncryptedVault`) and never stored in Firestore or code.
  - Supports **QuantCorp Paper Engine**, **Binance Spot/Testnet (HMAC-SHA256)**, **Alpaca Paper/Live**, **Bybit V5 (HMAC-SHA256)**, and **MetaTrader 5 via User-Hosted REST Bridge** (transparently documenting that MT5 does not expose a native cloud REST API directly to Android without a bridge server like MetaAPI or Python MT5 Gateway).

## 2. Running & Testing
- Firestore security rules unit tests:
  `FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js`
- Android compilation & JVM unit tests:
  `gradle :app:compileDebugKotlin :app:testDebugUnitTest`
