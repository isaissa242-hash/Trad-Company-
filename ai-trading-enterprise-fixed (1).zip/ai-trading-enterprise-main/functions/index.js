const { onSchedule } = require("firebase-functions/v2/scheduler");
const { defineSecret } = require("firebase-functions/params");
const { logger } = require("firebase-functions");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { GoogleGenAI } = require("@google/genai");

initializeApp();

const DATABASE_ID = "ai-studio-android-quantcor-e4d6eb18-8cbf-44ef-a74e-1cc142fa1e0d";
const db = getFirestore(DATABASE_ID);
const GEMINI_API_KEY = defineSecret("GEMINI_API_KEY");

const MODEL_FALLBACK_LADDER = [
  "gemini-4-argon",
  "gemini-3.8-flash",
  "gemini-3.5-flash-lite",
];

const RANK_TIERS = [
  { level: 1, badge: "⭐", minXp: 0 },
  { level: 2, badge: "⭐⭐", minXp: 50 },
  { level: 3, badge: "⭐⭐⭐", minXp: 120 },
  { level: 4, badge: "🦅", minXp: 220 },
  { level: 5, badge: "🦅🦅", minXp: 350 },
  { level: 6, badge: "🦅🦅🦅", minXp: 520 },
  { level: 7, badge: "⚔️", minXp: 740 },
  { level: 8, badge: "⚔️⚔️", minXp: 1000 },
  { level: 9, badge: "⚔️⚔️⚔️", minXp: 1350 },
  { level: 10, badge: "🐋", minXp: 1800 },
];

function evaluateRankLevel(xp) {
  const safeXp = Math.max(0, Number(xp) || 0);
  let level = 1;
  for (const tier of RANK_TIERS) {
    if (safeXp >= tier.minXp) level = tier.level;
  }
  return level;
}

function calculateProfitXp(netProfitUsd, roleShare = 1.0) {
  if (!(netProfitUsd > 0) || !(roleShare > 0)) return 0;
  const raw = Math.max(15, Math.min(300, Math.floor(netProfitUsd * 0.30)));
  return Math.max(5, Math.floor(raw * roleShare));
}

function isTransientAiError(err) {
  const msg = String(err?.message || err || "").toLowerCase();
  return (
    msg.includes("503") ||
    msg.includes("429") ||
    msg.includes("high demand") ||
    msg.includes("rate limit") ||
    msg.includes("resource_exhausted") ||
    msg.includes("quota") ||
    msg.includes("unavailable") ||
    msg.includes("timeout")
  );
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Smart Model Fallback + Exponential Backoff (3s -> 6s -> 12s)
 */
async function generateWithFallbackAndRetry(aiClient, primaryModel, prompt) {
  const startIdx = Math.max(0, MODEL_FALLBACK_LADDER.indexOf(primaryModel));
  const chain = MODEL_FALLBACK_LADDER.slice(startIdx);
  let lastErr;

  for (let attempt = 0; attempt <= 3; attempt++) {
    const model = chain[Math.min(attempt, chain.length - 1)];
    try {
      const response = await aiClient.models.generateContent({
        model,
        contents: prompt,
        config: {
          temperature: 0.2,
          responseMimeType: "application/json",
        },
      });
      if (response && response.text) {
        return { text: response.text, modelUsed: model };
      }
      throw new Error("503 Empty Gemini response");
    } catch (err) {
      lastErr = err;
      if (attempt < 3 && isTransientAiError(err)) {
        const waitMs = 3000 * (1 << attempt);
        logger.warn(`Transient AI error on ${model}; backing off ${waitMs}ms`, { error: err.message });
        await sleep(waitMs);
      } else {
        throw err;
      }
    }
  }
  throw lastErr;
}

async function fetchLiveKlines(symbol) {
  const urls = [
    `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=1h&limit=80`,
    `https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=1h&limit=80`,
  ];
  let lastStatus = "unknown";
  for (const url of urls) {
    try {
      const resp = await fetch(url, { signal: AbortSignal.timeout(10000) });
      if (resp.ok) {
        const rows = await resp.json();
        return rows.map((r) => ({
          open: Number(r[1]),
          high: Number(r[2]),
          low: Number(r[3]),
          close: Number(r[4]),
          volume: Number(r[5]),
        }));
      }
      lastStatus = `HTTP ${resp.status}`;
    } catch (err) {
      lastStatus = err?.message || "fetch error";
    }
  }
  throw new Error(`Market unavailable (${lastStatus})`);
}

function computeIndicators(bars) {
  const closes = bars.map((b) => b.close);
  const ema = (vals, period) => {
    const k = 2 / (period + 1);
    let cur = vals.slice(0, period).reduce((a, b) => a + b, 0) / period;
    for (let i = period; i < vals.length; i++) cur = vals[i] * k + cur * (1 - k);
    return cur;
  };
  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);

  let gains = 0;
  let losses = 0;
  for (let i = closes.length - 14; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  const rs = losses === 0 ? 100 : gains / losses;
  const rsi14 = 100 - 100 / (1 + rs);

  let trSum = 0;
  for (let i = bars.length - 14; i < bars.length; i++) {
    const h = bars[i].high;
    const l = bars[i].low;
    const pc = bars[i - 1].close;
    trSum += Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc));
  }
  const atr14 = trSum / 14;
  const currentPrice = closes[closes.length - 1];
  const emaGapPct = ema50 > 0 ? ((ema20 - ema50) / ema50) * 100 : 0;
  const setupScore = Math.abs(emaGapPct) * 25 + (rsi14 >= 40 && rsi14 <= 66 ? 30 : 0);
  return { currentPrice, ema20, ema50, rsi14, atr14, emaGapPct, setupScore };
}

/**
 * Updates only operational task counters & status — ZERO XP or badge changes.
 */
async function recordAgentTaskOnly(userRef, agentId, currentTask, status = "Completed") {
  const ref = userRef.collection("agents").doc(agentId);
  const snap = await ref.get();
  if (!snap.exists) return;
  const data = snap.data() || {};
  await ref.update({
    tasksCompleted: (Number(data.tasksCompleted) || 0) + 1,
    status,
    currentTask: String(currentTask || data.currentTask || "").slice(0, 500),
    updatedAt: FieldValue.serverTimestamp(),
  });
}

/**
 * Strictly Profit-Gated Promotion:
 * Badges & XP are granted ONLY when realized netPnl > 0.
 */
async function awardProfitPromotion(userRef, agentId, realizedProfitUsd, roleShare, currentTask) {
  if (!(realizedProfitUsd > 0)) return;
  const xpDelta = calculateProfitXp(realizedProfitUsd, roleShare);
  if (xpDelta <= 0) return;

  const ref = userRef.collection("agents").doc(agentId);
  const snap = await ref.get();
  if (!snap.exists) return;
  const data = snap.data() || {};
  const nextXp = Math.max(0, (Number(data.rankXp) || 0) + xpDelta);
  const nextLevel = evaluateRankLevel(nextXp);
  const nextProfit = (Number(data.totalProfitGeneratedUsd) || 0) + realizedProfitUsd * roleShare;
  await ref.update({
    rankXp: nextXp,
    rankLevel: nextLevel,
    successfulWinsCount: (Number(data.successfulWinsCount) || 0) + 1,
    totalProfitGeneratedUsd: Number(nextProfit.toFixed(2)),
    status: "Completed",
    currentTask: String(currentTask || data.currentTask || "").slice(0, 500),
    updatedAt: FieldValue.serverTimestamp(),
  });
}

async function monitorOpenPaperTrades(userRef, config, tickersBySymbol) {
  const openSnap = await userRef
    .collection("trades")
    .where("status", "==", "OPEN")
    .where("mode", "==", "PAPER")
    .get();

  let balanceDelta = 0;
  let vaultDepositTotal = 0;
  let closedCount = 0;
  const allocPct = Math.max(0, Math.min(50, Number(config.safetyVaultAllocationPct ?? 10)));

  for (const doc of openSnap.docs) {
    const t = doc.data();
    const mark = tickersBySymbol[t.symbol]?.currentPrice;
    if (!mark) continue;

    const hitTp = t.side === "BUY" ? mark >= t.takeProfit : mark <= t.takeProfit;
    const hitSl = t.side === "BUY" ? mark <= t.stopLoss : mark >= t.stopLoss;
    if (!hitTp && !hitSl) continue;

    const fee = mark * t.quantity * 0.001;
    const slip = mark * t.quantity * 0.0005;
    const gross = t.side === "BUY" ? (mark - t.entryPrice) * t.quantity : (t.entryPrice - mark) * t.quantity;
    const netPnl = gross - (t.feesPaid || 0) - (t.slippageCost || 0) - fee - slip;

    const closedNow = await db.runTransaction(async (tx) => {
      const freshSnap = await tx.get(doc.ref);
      if (!freshSnap.exists || freshSnap.get("status") !== "OPEN") {
        return false;
      }
      tx.update(doc.ref, {
        status: "CLOSED",
        exitPrice: mark,
        feesPaid: (t.feesPaid || 0) + fee,
        slippageCost: (t.slippageCost || 0) + slip,
        realizedPnl: netPnl,
        updatedAt: FieldValue.serverTimestamp(),
      });
      return true;
    });

    if (!closedNow) continue;

    const lockedVault = netPnl > 0 && allocPct > 0
      ? Math.min(netPnl, Math.round(netPnl * (allocPct / 100) * 100) / 100)
      : 0;
    vaultDepositTotal += lockedVault;
    balanceDelta += netPnl - lockedVault;
    closedCount++;

    if (netPnl > 0 && t.traderId) {
      const winNote = `ربح محقق +$${netPnl.toFixed(2)} على ${t.symbol}`;
      await awardProfitPromotion(userRef, t.traderId, netPnl, 1.0, winNote);
      await awardProfitPromotion(userRef, "ceo_01", netPnl, 0.60, `إدارة ربح +$${netPnl.toFixed(2)}`);
      await awardProfitPromotion(userRef, "hot_01", netPnl, 0.60, `إشراف تنفيذ رابح (${t.symbol})`);
      await awardProfitPromotion(userRef, "mid_01", netPnl, 0.50, `توصية ناجحة على ${t.symbol}`);
      await awardProfitPromotion(userRef, "cro_01", netPnl, 0.50, `اعتماد مخاطرة آمن (+$${netPnl.toFixed(2)})`);
    }
  }

  if (balanceDelta !== 0 || vaultDepositTotal > 0) {
    const cfgRef = userRef.collection("company_state").doc("config");
    await db.runTransaction(async (tx) => {
      const cfgSnap = await tx.get(cfgRef);
      const data = cfgSnap.data() || {};
      const curBal = Math.max(0, Number(data.paperBalance ?? config.paperBalance ?? 100000));
      const curVault = Math.max(0, Number(data.safetyVaultBalance ?? 0));
      const curDeposited = Math.max(0, Number(data.safetyVaultTotalDeposited ?? 0));
      tx.update(cfgRef, {
        paperBalance: Math.max(0, curBal + balanceDelta),
        safetyVaultBalance: curVault + vaultDepositTotal,
        safetyVaultTotalDeposited: curDeposited + vaultDepositTotal,
        updatedAt: FieldValue.serverTimestamp(),
      });
    });
  }
  return closedCount;
}

/**
 * 24/7 Cloud Scheduler Cycle (runs every 5 minutes even when Owner device is offline/off)
 */
exports.quantcorpAutonomousCycle = onSchedule(
  {
    schedule: "every 5 minutes",
    region: "us-central1",
    timeoutSeconds: 180,
    memory: "512MiB",
    secrets: [GEMINI_API_KEY],
  },
  async () => {
    const activeConfigsSnap = await db
      .collectionGroup("company_state")
      .where("cloudEngineEnabled", "==", true)
      .get();

    if (activeConfigsSnap.empty) {
      logger.info("No QuantCorp companies have 24/7 Cloud Engine enabled.");
      return;
    }

    const symbols = ["PAXGUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT"];
    const marketBySymbol = {};
    for (const sym of symbols) {
      try {
        const bars = await fetchLiveKlines(sym);
        if (bars.length >= 55) {
          marketBySymbol[sym] = computeIndicators(bars);
        }
      } catch (err) {
        logger.warn(`Failed cloud fetch for ${sym}`, { error: err.message });
      }
    }

    const apiKey = GEMINI_API_KEY.value() || process.env.GEMINI_API_KEY || "";
    const aiClient = apiKey ? new GoogleGenAI({ apiKey }) : null;

    for (const cfgDoc of activeConfigsSnap.docs) {
      const config = cfgDoc.data();
      const userRef = cfgDoc.ref.parent.parent;
      if (!userRef) continue;
      const uid = userRef.id;

      if (config.killSwitchActive || config.tradingPaused) {
        await cfgDoc.ref.update({
          cloudEngineStatus: "PAUSED_BY_SAFETY",
          cloudLastHeartbeatMillis: Date.now(),
          cloudLastSummary: "متوقف احترازياً (Kill Switch أو Trading Pause مفعل)",
          updatedAt: FieldValue.serverTimestamp(),
        });
        continue;
      }

      try {
        const closedAuto = await monitorOpenPaperTrades(userRef, config, marketBySymbol);

        const rankedCandidates = Object.entries(marketBySymbol)
          .sort((a, b) => b[1].setupScore - a[1].setupScore);

        if (rankedCandidates.length === 0) {
          await cfgDoc.ref.update({
            cloudEngineStatus: "DATA_RETRY",
            cloudLastHeartbeatMillis: Date.now(),
            cloudLastSummary: "تعذر جلب شموع السوق الحية في هذه الدورة",
            updatedAt: FieldValue.serverTimestamp(),
          });
          continue;
        }

        const [targetSym, ind] = rankedCandidates[0];
        const targetHint = Number(config.profitTargetUsd) > 0
          ? ` | هدف المالك النشط: $${Number(config.profitTargetUsd).toFixed(2)}`
          : "";

        let decision = {
          shouldTrade: ind.ema20 > ind.ema50 && ind.rsi14 >= 38 && ind.rsi14 <= 68,
          side: ind.ema20 >= ind.ema50 ? "BUY" : "SELL",
          rationaleAr: `رصد سحابي متعدد الأسواق: ${targetSym} EMA20=${ind.ema20.toFixed(2)}، RSI=${ind.rsi14.toFixed(1)}`,
        };
        let modelUsed = "quant-rule-guard";

        if (aiClient) {
          const prompt = `أنت فريق التداول السحابي في QuantCorp AI. أعلى فرصة مرصودة الآن: ${targetSym}: السعر ${ind.currentPrice.toFixed(2)}, EMA20=${ind.ema20.toFixed(2)}, EMA50=${ind.ema50.toFixed(2)}, RSI14=${ind.rsi14.toFixed(1)}, ATR14=${ind.atr14.toFixed(2)}${targetHint}. أرجع JSON بالحقول: {"shouldTrade": boolean, "side": "BUY"|"SELL", "rationaleAr": string}.`;
          const aiRes = await generateWithFallbackAndRetry(aiClient, "gemini-4-argon", prompt);
          modelUsed = aiRes.modelUsed;
          decision = JSON.parse(aiRes.text);
        }

        const openSnap = await userRef.collection("trades").where("status", "==", "OPEN").get();
        const maxOpen = Number(config.maxOpenPositions) || 5;
        const alreadyOpenOnTarget = openSnap.docs.some((d) => d.data()?.symbol === targetSym);
        let actionSummary = `مراقبة ${targetSym} @ $${ind.currentPrice.toFixed(2)} (${modelUsed}) | مغلق آلياً: ${closedAuto}${targetHint}`;

        if (decision.shouldTrade && !alreadyOpenOnTarget && openSnap.size < maxOpen && config.tradingMode === "PAPER") {
          const riskUsd = ((Number(config.paperBalance) || 100000) * (Number(config.maxRiskPerTradePct) || 1.5)) / 100;
          const stopDist = Math.max(ind.atr14 * 1.5, ind.currentPrice * 0.004);
          const qty = Number((riskUsd / stopDist).toFixed(4));
          const stopLoss = decision.side === "BUY" ? ind.currentPrice - stopDist : ind.currentPrice + stopDist;
          const takeProfit = decision.side === "BUY" ? ind.currentPrice + stopDist * 1.8 : ind.currentPrice - stopDist * 1.8;

          const tradeId = `trd_cloud_${Date.now()}`;
          await userRef.collection("trades").doc(tradeId).set({
            userId: uid,
            symbol: targetSym,
            side: decision.side === "SELL" ? "SELL" : "BUY",
            mode: "PAPER",
            status: "OPEN",
            strategyId: "strat_ema_sweep",
            strategyName: "Cloud 24/7 Autonomous Institutional Strategy",
            traderId: "trd_short_01",
            traderName: "المتداول A (سحابي 24/7)",
            entryPrice: ind.currentPrice,
            exitPrice: 0,
            quantity: qty,
            stopLoss,
            takeProfit,
            feesPaid: ind.currentPrice * qty * 0.001,
            slippageCost: ind.currentPrice * qty * 0.0005,
            realizedPnl: 0,
            rationale: (decision.rationaleAr || "").slice(0, 1900),
            riskApprovalId: `CRO-CLOUD-${Date.now()}`,
            brokerOrderId: `CLOUD-${Date.now()}`,
            createdAt: FieldValue.serverTimestamp(),
            updatedAt: FieldValue.serverTimestamp(),
          });

          // Operational update only — NO badges or XP until trade closes with positive profit
          await recordAgentTaskOnly(userRef, "trd_short_01", `تنفيذ سحابي ${decision.side} ${targetSym} (بانتظار إغلاق رابح للترقية)`);
          await recordAgentTaskOnly(userRef, "ceo_01", `متابعة سحابية لصفقة ${targetSym}${targetHint}`);
          actionSummary = `صفقة سحابية ${decision.side} ${targetSym} @ $${ind.currentPrice.toFixed(2)} (${modelUsed})${targetHint}`;
        } else {
          await recordAgentTaskOnly(userRef, "mid_01", `رصد مستمر لـ ${rankedCandidates.length} أسواق${targetHint}`);
        }

        const sniperState = config.sniperEnabled === false ? " | القناص: معطّل إدارياً" : " | القناص: متأهب 100%";
        await cfgDoc.ref.update({
          cloudEngineStatus: "RUNNING",
          cloudLastHeartbeatMillis: Date.now(),
          cloudLastSummary: `${actionSummary}${sniperState}`.slice(0, 950),
          updatedAt: FieldValue.serverTimestamp(),
        });
      } catch (err) {
        logger.error(`Cloud cycle failed for user ${uid}`, { error: err.message });
        await cfgDoc.ref.update({
          cloudEngineStatus: "RETRY_QUEUED",
          cloudLastHeartbeatMillis: Date.now(),
          cloudLastSummary: `إعادة جدولة سحابية بعد خطأ عابر: ${String(err.message).slice(0, 200)}`,
          updatedAt: FieldValue.serverTimestamp(),
        });
      }
    }
  }
);
